/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa solicita al usuario las proporciones de cuya matriz quiere
introducir datos y dichos datos (el programa obliga a que la matriz tenga
de dimensi�n m�nima 1x1 y de dimensi�n m�xima 10x10). Una vez se ha 
introducido la matriz, se halla el m�nimo de cada fila y finalmente se 
halla el m�ximo de entre los m�nimos calculados. Los datos de salida del
programa ser�n el m�ximo de los m�nimos y la posici�n en la que se encuentra
dentro de la matriz.

El resto est� explicado en los comentarios intercalados.
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recursos de E/S

using namespace std;

// Creaci�n del struct punto 2D

struct Punto2D {
	
	int x;
	int y;
};

/*****************************************************************************/

int LeeEntero(string titulo){
	
	string entrada;
	string salida;
	bool es_entero;
	
	// El bucle no termina hasta que el valor introducido sea entero
	
	do{
		
		salida = "";
		
		cout << titulo;
		getline(cin,entrada);
		
		es_entero = true;
		
		int i = 0;
		
		// Se comprueban las posiciones de la cadena introducida hasta que 
		// llega al final 
		
		while (i < entrada.length()){
			
			// En caso de que el caracter en la posici�n i no sea ni un 
			// numero ni un espacio
			
			if (!isdigit(entrada.at(i)) && !isspace(entrada.at(i))) {
				
				//En caso de que el numero sea negativo
				
				if (((entrada.at(i) == '-') || (entrada.at(i) == '+')) && 
				(salida.length() == 0) && isdigit(entrada.at(i+1))){
					
					salida.push_back(entrada.at(i));
					
				}
				
				else{
					
					es_entero = false;
					i = entrada.length();
						 
				}
				
			}
			
			// En caso de que el caracter en la posici�n i sea un n�mero
			
			else{	
					salida.push_back(entrada.at(i));
					
			}
			
			i++;	
		}
		
		//Si la cadena de salida est� vacia, se vuelve a pedir un entero
		
		if (salida.length() == 0){
		
			es_entero = false;
				
		}
		
		cout << endl;
		
	}while (!es_entero);
	
	//Se devuelve un valor entero
	
	return (stoi(salida));
}

/*****************************************************************************/

int LeeEnteroEnRango (string titulo, int menor, int mayor){
	
	int numero;
	
	do{
		numero = LeeEntero (titulo);
	}
	while ((numero < menor) || (numero > mayor));
	
	return (numero);
}

int main () // Programa principal
{
	// Declaraci�n de datos
	
	int filas;
	int columnas;
	const int MAX_FILAS = 10;
	const int MAX_COLUMNAS = 10;
	
	double matriz[MAX_FILAS][MAX_COLUMNAS];
	
	// Entrada de datos
	
	filas = LeeEnteroEnRango ("Introduza el n�filas: ", 1, MAX_FILAS);
	columnas = LeeEnteroEnRango ("Introduzca el n�columnas: ", 1, MAX_COLUMNAS);

	// Se pide al usuario que introduzca el valor de cada casilla de la matriz
	
	cout << "Introduzca los valores de la matriz: ";
	cout << endl;
	
	for(int i = 0; i < filas; i++){
		
		for(int j = 0; j < columnas; j++){
			
			cout << "Casilla (" << i << "," << j << "): ";
			cin >> matriz[i][j];
		}
	}
	
	// Ahora creamos el vector "minimos" en el que iremos almacenando el 
	// m�nimo de cada fila, de manera que tendr� tanta capacidad como
	// filas se hayan indicado
	
	double minimos[filas];
	
	for(int i = 0; i < filas; i++){
		
		// Se inicializa el m�nimo de la fila i con el primer elemento de la
		// fila y lo empezamos a comparar con el resto de los de su fila. Si
		// es mayor que alguno de ellos, el m�nimo de la fila i tomar� el valor
		// de ese elemento que es menor que el del �ltimo m�nimo registrado.
		// As� sucesivamente hasta llegar al final de la fila
		
		minimos[i] = matriz[i][0];
		
		for(int j = 1; j < columnas; j++){
			
			if(minimos[i] > matriz[i][j]){
				
				minimos[i] = matriz[i][j];
			}
		}
	}
	
	// Una vez tenemos los m�nimos hallados, buscamos el m�ximo de ellos. Para
	// ello, declaramos "max_min" y lo inicializamos con el valor del m�nimo
	// de la primera fila, el cual iremos comparando con los dem�s. Si se
	// encuentra un m�nimo mayor que el max_min, max_min pasar� a valer el
	// m�nimo de dicha fila, el cual se ir� comparando con los que queden, as�
	// hasta haber recorrido todos los m�nimos
	
	double max_min = minimos[0];
	Punto2D pos_max_min;
	
	for(int i = 1; i < filas; i++){
		
		if(max_min < minimos[i]){
			
			max_min = minimos[i];
		}
	}
	
	// Por �ltimo, necesitamos saber en qu� posici�n est� el m�ximo de los 
	// m�nimos. Para ello, estableceremos un bucle for que guardar� en 
	// pos_max_min las coordenadas de aquella casilla de la matriz en la que
	// encontremos max_min (es decir, vamos a recorrer toda la matriz en
	// b�squeda de max_min
	
	for(int i = 0; i < filas; i++){
		
		for(int j = 0; j < columnas; j++){
			
			if (max_min == matriz[i][j]){
				
				pos_max_min.x = i;
				pos_max_min.y = j;
			}
		}
	}
	
	// Salida de datos
	
	cout << endl;
	cout << "El m�ximo m�nimo de su matriz es " << max_min << " y se"
	<< " encuentra en la posici�n (" << pos_max_min.x << "," << pos_max_min.y
	<< ")";
	
	return 0;
	
}
