/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa nos permite saber el m�nimo de a�os necesarios para que un capital
determinado sea el doble o mayor que el inicial tras aplicarle un inter�s 
determinado cada a�o al capital del a�o anterior. En el a�o 0 el inter�s ser�
aplicado sobre el capital inicial. 

Para poder resolver lo propuesto, he hecho uso de tres bucles pre-test. Dos de
ellos han sido usados como filtro para asegurarme de que el usuario introduce
un capital y un inter�s correctos. Tras esto, he declarado el dato de tipo bool
es_doble como verdadero, pues es la condici�n de mi bucle y necesito que entre
a este al menos una vez, ya que la primera vez el capital inicial no puede
ser el doble que �l mismo. Antes de desarrollar el bucle, he tenido que asignar
a la variable capital_final el valor de capital_inicial para poder escribir en
el bucle el c�lculo:

           capital_final = capital_final*factor_subida
           
Si hubiese hecho capital_inicial*factor_subida, el programa estar�a eternamente
en el bucle porque solo calcular�a el valor del capital final el primer a�o, 
siendo la condici�n del bucle verdadera siempre. Es por esto que he tenido que 
realizar la asignaci�n mencionada antes del bucle.
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recursos de E/S

using namespace std;

int main() // Programa principal
{
	// Declaraci�n de datos de entrada y salida
	
	double capital_inicial;
	double capital_final;
	double interes;
	double factor_subida;
	int anios = 0; // La variable acumuladora se inicializa con el 0
	
	// Entrada del dato "capital" y filtro
	
	do {
		cout << "Introduzca su capital: ";
		cin >> capital_inicial;
	}
	while (capital_inicial <= 0);
	
	// Entrada del dato inter�s y filtro
	
	do {
		cout << "Introduzca el inter�s que va a ser aplicado a su capital: ";
		cin >> interes;
	}
	while ((interes <= 0) || (interes > 10));
	
	// C�lculo del factor de subida a partir del inter�s introducido
	
	factor_subida = 1 + (interes/100.0);
	                                 
	// Declaraci�n y asignaci�n del dato de tipo bool que determina la condici�n
	
	bool no_es_doble = true; // Condici�n necesaria para que entre al bucle
	
	// C�lculos
	
	capital_final = capital_inicial; // Es necesario hacer esto para no entrar
	                                 // en un bucle infinito
	                                 
	while (no_es_doble){
		
		// C�lculo del capital tras el aumento
		
		capital_final = capital_final*factor_subida;
		
		// Actualizaci�n de la condici�n
		
		no_es_doble = capital_final < 2*capital_inicial;
		
		// Sumo 1 a mi variable acumuladora
		
		anios = anios + 1;
	}
		
	// Salida de datos
	
	cout << endl;
	cout << "Los a�os m�nimos para que su capital sea el doble o mayor "
	<< "que el inicial son " << anios << " a�os";
	
	return 0;
	
}
		
		
		
		
		
	
	
	
	
	
