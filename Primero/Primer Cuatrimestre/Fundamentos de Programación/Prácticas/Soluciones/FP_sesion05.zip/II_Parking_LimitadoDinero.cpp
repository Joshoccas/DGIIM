/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa pide las horas y minutos de llegada al p�rking al usuario y el
presupuesto del que dispone. Su funci�n principal es informar al usuario de
hasta cu�ndo puede estar con la cantidad de dinero indicada en el p�rking,
dando tambi�n el dato del total de minutos que puede permanecer en el p�rking.

Seg�n el intervalo de tiempo que se permanece, el precio por minuto de la 
estancia va cambiando de acuerdo con la siguiente clasificaci�n:

1. De 0 a 30 minutos se cobra a 0.0412 euros cada minuto
2. De 31 a 90 minutos se cobra a 0.0370 euros cada minuto
3. De 91 a 120 minutos se cobra a 0.0311 euros cada minuto
4. De 121 a 660 minutos se cobra a 0.0305 euros cada minuto
5. De 661 a 900 minutos se cobra a 0.0270 euros cada minuto
6. De 900 minutos en adelante es necesario pagar 35 euros en total

Para resolver lo pedido he empezado usando bucles para filtrar los datos de
horas, minutos y presupuesto. Tras esto, para hacer los c�lculos de los 
minutos permitidos en el p�rking he usado bucles que restan continuamente la
misma cantidad a mi presupuesto hasta llegar a un m�ximo de minutos por 
intervalo o hasta que el presupuesto se agote (de ah� la doble condici�n de mis 
bucles). As�, si en el primer intervalo ya se han superado los 30 minutos,
se pasa al siguiente bucle que va de 30 a 90 minutos y en el que se va restando
el precio pertinente. Finalmente habr� un bucle en el que el dinero se agote
y ya se hayan contado los minutos posibles.

Finalmente, una vez se tienen los minutos permitidos en el p�rking, hay que
considerar tres casos posibles, los cuales he tenido en cuenta mediante
estructuras condicionales:

1. El usuario puede estar hasta al dia siguiente, en ese caso se deben reajustar
algunos c�lculos para imprimir bien en pantalla la hora y minutos de salida
2. El usuario puede estar hasta un momento de ese mismo d�a, por lo que se
usan los datos ya obtenidos sin problema
3. El usuario puede estar hasta justo el inicio del nuevo d�a, en ese caso
solo se imprime en pantalla la hora "0 h 0 min"
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recursos de E/S

using namespace std;

int main() // Programa principal
{
	// Declaraci�n de datos
	
	int horas1;
	int minutos1;
	double presupuesto_inicial;
	const double PRECIO_0_A_30 = 0.0412;
	const double PRECIO_31_A_90 = 0.0370;
	const double PRECIO_91_A_120 = 0.0311;
	const double PRECIO_121_A_660 = 0.0305;
	const double PRECIO_661_A_900 = 0.0270;
	const int PRECIO_900_A_1440 = 35;
	const int ESTANCIA_MAXIMA = 1440;
	int estancia_en_minutos = 0; // Contador de minutos
	int horas2; // Horas de salida
	int minutos2; // Minutos de salida
	
	// Entrada de datos
	
	// Filtro para las horas
	
	bool horas_mal = true;
	
	do{
		cout << "Introduzca las horas actuales: ";
		cin >> horas1;
		
		// Condici�n del bucle
		
		horas_mal = ((horas1 < 0) || (horas1 > 23));
	}
	while (horas_mal);
	
	// Filtro para los minutos
	
	bool minutos_mal = true;
	
	do{
		cout << "Introduzca los minutos actuales: ";
		cin >> minutos1;
		
		// Condici�n del bucle
		
		minutos_mal = ((minutos1 < 0) || (minutos1 > 59));
	}
	while (minutos_mal);
	
	// Filtro para el presupuesto
	
	bool presupuesto_mal = true;
	
	do{
		cout << "Introduzca su presupuesto: ";
		cin >> presupuesto_inicial;
		
		// Condici�n del bucle
		
		presupuesto_mal = presupuesto_inicial <= 0;
	}
	while (presupuesto_mal);
	
	// Asiganaci�n de la variable auxiliar para poder realizar c�lculos
	
	double presupuesto = presupuesto_inicial;
	
	// Consideraci�n de dos casos posibles
	
	// 1. El dinero no es igual ni superior a 35 euros
	
	if (presupuesto < PRECIO_900_A_1440){
		
		// Se sustrae dinero de 0 a 30 min
		
		while ((presupuesto >= PRECIO_0_A_30)&&(estancia_en_minutos <= 30)){
			
			// Restamos el precio por cada minuto al presupuesto
			
			presupuesto = presupuesto - PRECIO_0_A_30;
			
			// Sumamos 1 minuto al contador estancia_en_minutos
			
			estancia_en_minutos = estancia_en_minutos + 1;
		}
		
		// Se sustrae dinero de 31 a 90 min
		
		while ((presupuesto >= PRECIO_31_A_90)&&(estancia_en_minutos <= 90)){
			
			presupuesto = presupuesto - PRECIO_31_A_90;
			estancia_en_minutos = estancia_en_minutos + 1;
		}
		
		// Se sustrae dinero de 91 a 120 min
		
		while ((presupuesto >= PRECIO_91_A_120)&&(estancia_en_minutos <= 120)){
			
			presupuesto = presupuesto - PRECIO_91_A_120;
			estancia_en_minutos = estancia_en_minutos + 1;
		}
		
		// Se sustrae dinero de 121 a 660 min
		
		while ((presupuesto >= PRECIO_121_A_660)&&(estancia_en_minutos <= 660)){
			
			presupuesto = presupuesto - PRECIO_121_A_660;
			estancia_en_minutos = estancia_en_minutos + 1;
		}
		
		// Se sustrae dinero de 661 a 900 min
		
		while ((presupuesto >= PRECIO_661_A_900)&&(estancia_en_minutos <= 900)){
			
			presupuesto = presupuesto - PRECIO_661_A_900;
			estancia_en_minutos = estancia_en_minutos + 1;
		}
	}
	
	// 2. El dinero es igual o superior a 35 euros
	
	else{
		estancia_en_minutos = ESTANCIA_MAXIMA;
	}
	
	
	// Se muestra en pantalla los minutos de estancia y en horas y minutos
	
	cout << endl;
	cout << "Los minutos que puede permanecer en el p�rking con la "
	<< "cantidad introducida son " << estancia_en_minutos;
	cout << endl;
	horas2 = estancia_en_minutos/60;
	minutos2 = estancia_en_minutos%60;
	cout << "Puede permanecer en el p�rking " << horas2 << " horas "
	<< minutos2 << " minutos";
	
	// C�lculo de los minutos totales del instante de salida
	
	int minutos_totales = horas1*60 + minutos1 + estancia_en_minutos;
	
	// Consideraci�n de tres posibilidades
	
	// 1. El instante de salida tiene menos minutos que un d�a (entra y sale
	// el mismo d�a)
	
	if (minutos_totales < 1440){
		
		// C�lculos
		
		horas2 = horas1 + horas2 + (minutos1 + minutos2)/60;
		minutos2 = (minutos1 + minutos2)%60;
		
		// Salida de datos
		
		cout << endl;
		cout << "Puede permanecer hasta las " << horas2 << " h "
		<< minutos2 << " min";
	}
	
	// El instante de salida tiene m�s minutos que un d�a (entra y sale
	// en d�as distintos
	
	if (minutos_totales > 1440){
		
		// C�lculos
		
		minutos_totales = minutos_totales - 1440;
		horas2 = minutos_totales/60;
		minutos2 = minutos_totales%60;
		
		// Salida de datos
		
		cout << endl;
		cout << "Puede permanecer hasta las " << horas2 << " h "
		<< minutos2 << " min" << " del d�a siguiente";
	}
	
	// 3. El instante de salida tiene justo los minutos de un d�a (sale a las
	// 12 de la noche)
	
	if (minutos_totales == 1440){
		
		cout << endl;
		cout << "Puede permanecer hasta las 0 h 0 min";
	}
	
	return 0;
}
	
