/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa tiene como funci�n principal informarnos, tras haber introducido
nosotros una serie de temperaturas consecutivas, sobre de qu� d�a a qu� otro 
d�a se produjo la secuencia de temperaturas crecientes m�s larga, adem�s de
imprimir en pantalla la longitud de dicha secuencia.

En mi caso, el rango de las temperaturas que se pueden introducir son entre 
-50 y 50, de manera que cuando el usuario introduzca una temperatura fuera de 
ese rango, se interpretar� como que ha acabado de introducir temperaturas
y se muestran los resultados. Para pedir temperaturas de d�as consecutivos
he hecho uso de bucles, mientras que para evaluar si distintas secuencias de 
temperaturas son mayores que otras he hecho uso de condicionales. El resto
est� explicado detalladamente en los comentarios intercalados.
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recursos de E/S

using namespace std;

int main() // Programa principal
{
	// Declaraci�n de datos
	
	const double MIN_RANGO = -50;
	const double MAX_RANGO = 50;
	double temperatura_anterior;
	double temperatura;
	int longitud_secuencia;
	int inicio_secuencia; 
	int final_secuencia;
	int inicio_secuencia_maxima;
	int final_secuencia_maxima;
	int contador_dias;
	
	// Inicializaci�n de variables
	
	contador_dias = 1;   // Los tres primeros datos se inicializan con el 1 ante 
	inicio_secuencia_maxima = 1; // la posibilidad de que haya una secuencia de
	final_secuencia_maxima = 1; // un �nico d�a
	temperatura_anterior = MIN_RANGO; // Condici�n necesario para que el bucle
	                                  // de despu�s se ejecute al menos una vez
	final_secuencia = 0;
	
	// Entrada de datos
	
	// Entrada del dato temperatura y filtro
	
	cout << "Introduzca la temperatura del primer d�a: ";
	cin >> temperatura;
	
	bool temperatura_bien = (temperatura > MIN_RANGO) && 
	(temperatura < MAX_RANGO);
	
	while (temperatura_bien){
		
		bool racha_empieza_o_sigue = temperatura > temperatura_anterior;
		
		if (racha_empieza_o_sigue){
			
			if (final_secuencia == 0){
				
				inicio_secuencia = 1;
			}
		}
		
		else{
			
			// En caso de que la racha se rompe, el final de la �ltima secuencia
			// ser� el el anterior del d�a reci�n introducido, es decir, dia - 1
			
			final_secuencia = contador_dias - 1;
			
			// Se comprueba si la �ltima secuencia introducida es la m�s larga
			// Si ocurre, se actualizan el inicio y el final de la secuencia
			
			if ((final_secuencia_maxima - inicio_secuencia_maxima)
			< (final_secuencia - inicio_secuencia)){
				
				final_secuencia_maxima = final_secuencia;
				inicio_secuencia_maxima = inicio_secuencia;
			}
			
			// Como se ha roto la secuencia creciente, debemos actualizar el 
			// inicio de la ��tima secuencia al nuevo, es decir, al d�a actual
			
			inicio_secuencia = contador_dias;
		}
		
		// Se van contando los d�as de uno en uno
		
		contador_dias++;
		
		// Actualizamos el valor de la temperatura por una nueva que introducir�
		// el usuario, la cual ser� sometida a la condici�n del bucle while
		
		temperatura_anterior = temperatura;
		
		cout << endl;
		cout << "Introduzca la temperatura del d�a siguiente: ";
		cin >> temperatura;
		
		// Actualizamos la condici�n del bucle para una nueva evaluaci�n
		
		temperatura_bien = (temperatura > MIN_RANGO) && 
		(temperatura < MAX_RANGO);
	}
	
	final_secuencia = contador_dias - 1;
	
	// Se debe considerar el caso de que se hayan introducido distintas
	// secuencias y justo al salirse del bucle, la �ltima introducida es
	// mayor que la �ltima secuencia m�s grande
	
	if ((final_secuencia_maxima - inicio_secuencia_maxima)
			< (final_secuencia - inicio_secuencia)){
				
				final_secuencia_maxima = final_secuencia;
				inicio_secuencia_maxima = inicio_secuencia;
	}
	
	// Finalmente se calcula la longitud de la secuencia m�xima
	
	longitud_secuencia = final_secuencia_maxima - inicio_secuencia_maxima + 1;
	
	// Salida de datos
	
	cout << endl;
	cout << "La longitud de la secuencia es " << longitud_secuencia;
	cout << endl;
	cout << "La secuencia m�xima comenz� el d�a " << inicio_secuencia_maxima
	<< " y termin� el d�a " << final_secuencia_maxima;
	
	return 0;
}
				
				

			
			
