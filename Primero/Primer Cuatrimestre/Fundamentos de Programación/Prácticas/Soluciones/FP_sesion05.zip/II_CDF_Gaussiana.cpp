/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa lee tres datos: abscisa, esperanza y desviaci�n t�pica. Una vez
le�dos, nos calcula el valor del �rea que hay bajo la curva de la funci�n
gaussiana desde el valor de abscisa introducido hasta menos infinito. 

He hecho uso de bucles para filtrar el dato de la desviaci�n t�pica (el cual
no puede ser menor o igual que 0) y he usado un bucle for para que el �rea que
se desea calcular la suma de rect�ngulos de �rea m�nima que cubren dicho 
�rea total, siendo la condici�n de parada de mi bucle la llegada al valor de
abscisa que se hab�a introducido.
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recursos de E/S
#include <cmath> // Inclusi�n de los recursos matem�ticos

using namespace std;

int main() // Programa principal
{
	// Declaraci�n de datos
	
	double abscisa;
	double esperanza;
	double desviacion_tipica;
	double resultado_gaussiana;
	
	// Entrada de datos
	
	cout << "Introduzca el valor de abscisa desde el que quiere calcular "
	<< "el �rea bajo la curva de la funci�n gaussiana: ";
	cin >> abscisa;
	
	
	cout << "Introduzca el valor de la esperanza: ";
	cin >> esperanza;
	
	// Filtro del dato desviaci�n t�pica
	
	do{
		cout << "Introduzca la desviaci�n t�pica: ";
		cin >> desviacion_tipica;
	}
	while (desviacion_tipica <= 0);
	
	// El c�lculo del �rea lo voy a realizar como la suma de los rect�ngulos
	// de base muy peque�a (que ser� mi dato SALTO que voy a declarar) y de
	// altura el valor de la funci�n gaussiana. Tambi�n me hace falta declarar
	// PI porque lo necesito para el c�lculo de la funci�n gaussiana para cada
	// valor de abscisa
	
	const double SALTO = 0.000001;
	const double PI = 3.14159265358979323846;
	
	// Declaro e inicializo el �rea que se quiere calcular junto con la zona
	// desde que se va a empezar a calcular el �rea hasta llegar a la abscisa
	// introducida
	
	double cdf_de_x = 0;
	double x_inicial = esperanza - 3*(desviacion_tipica);
	
	for (double i = x_inicial; i <= abscisa; i = i + SALTO){
		
		// Calculamos el valor que toma la funci�n gaussiana para i
		// Separamos la expresi�n de la funci�n separando en dos 
		// t�rminos que vamos a declarar
		
		double termino1 = (1/(desviacion_tipica*sqrt(PI)));
		double termino2 = -0.5*(pow((i-esperanza)/desviacion_tipica,2));
		
		resultado_gaussiana = termino1 * exp(termino2);
		
		// Ahora se calcula el �rea del diminuto rect�ngulo tal y como
		// he dicho antes
		
		double rectangulo = resultado_gaussiana*SALTO;
		
		// Actualizamos el valor del �rea que se quiere calcular sum�ndole
		// el �rea del nuevo rect�ngulo
		
		cdf_de_x = cdf_de_x + rectangulo;
	}
	
	// Salida de datos
	
	cout << endl;
	cout << "El �rea bajo la curva de la funci�n gaussiana hasta el valor de "
	<< " abscisa que ha introducido es " << cdf_de_x;
	
	return 0;
}
	
	
	

	
