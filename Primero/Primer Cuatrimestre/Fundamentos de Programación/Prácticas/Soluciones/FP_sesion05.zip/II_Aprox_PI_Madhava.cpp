/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa calcula de forma aproximada el n�mero irracional pi mediante la
arcotangente de 1/sqrt(3), la cual se calcula mediante un desarrollo de Taylor,
tal y como hizo el matem�tico indio Madhava de Sangamagrama. Este programa
tiene dos partes:

1. Se lee un valor llamado tope que debe estar entre 1 y 100000 (indica cu�ntos
t�rminos de la serie de Taylor se quieren sumar) y se imprime en pantalla la
aproximaci�n de pi a partir de ese tope.

2. Se lee un valor llamado precision que indica hasta qu� cifra decimal de
precisi�n se quiere truncar la aproximaci�n de pi calculada mediante el 
desarrollo de Taylor. Finalmente se imprimen en pantalla el n�mero de 
iteraciones que han sido necesarias para que la aproximaci�n de pi truncada
coincida con el valor real de pi truncado hasta la misma cifra de precisi�n.
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recursos de E/S
#include <cmath> // Inclusi�n de los recursos matem�ticos

using namespace std;

int main() // Programa principal
{
	// PROGRAMA A
	
	// Declaraci�n de datos
	
	int tope;
	
	double suma_pares = 0; // Separo la suma de los t�rminos de la sucesi�n de 
	double suma_impares = 0; // Taylor para cuando i es par o impar
	
	const double base_potencia = 1/sqrt(3);
	
	double suma_total; // Es la suma de la suma de los t�rminos pares con la 
	                   // suma de los t�rminos impares
	                
	double aproximacion_pi; // Es el dato de salida
	
	// Entrada de datos
	
	// Entrada del dato tope y filtro
	
	do{
		cout << "Introduzca el tope (n�mero de sumas a realizar con el "
		<< "desarrollo de Taylor): ";
		cin >> tope;
	}
	while ((tope < 1) || (tope > 100000));
	
	// C�lculo de la suma de los t�rminos cuando i es par e impar por separado
	
	for (int i = 0; i <= tope; i = i + 2){
		
		double potencias_pares = 1; // Estos dos datos me permiten realizar la
	    double potencias_impares = 1; // potencia con exponente 2i+1 sin pow
		
		for (int j = 0; j < 2*i + 1; j++){
			potencias_pares = potencias_pares*base_potencia;
		}
		
		for (int j = 0; j < (2*(i+1)) + 1; j++){
			potencias_impares = potencias_impares*base_potencia;
		}
		
		suma_pares = suma_pares + (potencias_pares/(2*i + 1));
		suma_impares = suma_impares - (potencias_impares/(2*(i + 1) + 1));
	}
	
	// Como ya tenemos la sumas de todos los t�rminos para cuando i es par 
	// e impar, sumamos ambos datos y tenemos la suma total del desarrollo
	// de Taylor
	
	suma_total = suma_pares + suma_impares;
	
	// Dicho desarrollo es igual a pi/6, por lo que para hallar el dato
	// aproximacion_pi habr� que multiplicar suma_total por 6
	
	aproximacion_pi = 6*suma_total;
	
	// Salida de datos
	
	cout << endl;
	cout << "La aproximaci�n de pi es " << aproximacion_pi << " con "
	<< tope << " sumas de t�rminos del desarrollo de Taylor";
	
	/*************************************************************************/
	
	// PROGRAMA B
	
	// Declaraci�n de datos
	
	const double PI = 3.14159265358979323846;
	int precision; // Cifra decimal hasta la que se quiere truncar;
	
	double pi_truncado;
	double truncamiento_potencia_10 = 1;
	
	// Entrada de datos
	
	// Entrada del dato precision y filtro
	
	do{
		cout << endl;
		cout << endl;
		cout << "Introduzca los decimales de precisi�n que desea en la "
		<< "aproximaci�n: ";
		cin >> precision;
	}
	while (precision < 0);
	
	// Aproximaci�n de pi mediante truncamiento con la precisi�n indicada
	
	for(int i = 0; i < precision; i++)
	    truncamiento_potencia_10 = truncamiento_potencia_10 * 10;
	
	pi_truncado = int(PI*truncamiento_potencia_10)/truncamiento_potencia_10;
	
	// Introducimos la variable aproximacion_truncada y la variable
	// contador, que en este caso viene a ser lo que era "i" en el programa
	// anterior
	
	double aproximacion_truncada = 0;
	int numero_sumas = 0; // Contador de sumas
	double aproximacion = 0; 
	suma_pares = 0;
	suma_impares = 0;
	suma_total = 0;
	
	while (aproximacion_truncada!=pi_truncado){
		
		// Estas variables se usan para poder realizar la potencia de exponente 
		// 2i + 1 sin necesidad de usar pow
		
		double potencias_pares = 1;
		double potencias_impares = 1;
		
		// Los c�lculos que siguen son los mismos que los del programa A, solo
		// que con la variable contador en vez de con i
		
		for(int i = 0; i < 2*numero_sumas + 1; i++){
			potencias_pares = potencias_pares*base_potencia;
		}
		
		for(int i = 0; i < 2*(numero_sumas + 1) + 1; i++){
			potencias_impares = potencias_impares*base_potencia;
		}
		
		suma_pares = suma_pares + (potencias_pares/(2*numero_sumas + 1));
		suma_impares = suma_impares - 
		(potencias_impares/(2*(numero_sumas + 1) + 1));
		
		suma_total = suma_pares + suma_impares;
		
		aproximacion = 6*suma_total;
		
		// Como ya tenemos la aproximaci�n de pi, truncamos dicho n�mero de
		// igual forma que hemos hecho con el valor real de pi
		
		double truncamiento2 = 1;
		
		for(int i = 0; i<precision; i++)
		    truncamiento2 = truncamiento2*10;
		    
		aproximacion_truncada = 
		int(aproximacion*truncamiento2)/truncamiento2;
		
		numero_sumas = numero_sumas + 2; // Se le suma 2 en cada iteraci�n ya
		// que hab�amos dividido el desarrollo de Taylor en sumas cuando i es
		// par y cuando i es impar
	}
	
	// Salida de datos
	
	cout << endl;
	cout << numero_sumas << " sumas han sido necesarias para aproximar a "
	<< precision << " decimales";
	
	return 0;
}
		                                
	
	
	  
	  
	
		
	
	
	
	
	
	
	
