/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa consiste en un juego de adivinar un n�mero. El programa genera un
n�mero aleatorio entre el 1 y el 100 y el usuario introduce un n�mero 
cualquiera. Entonces, caben 4 posibilidades:

1. El usuario no quiere jugar y por ello introduce -1, que es nuestro 
terminador. En este caso, el bucle no se ejecuta y se avisa de que se ha
abandonado el juego.
2. El usuario introduce un n�mero v�lido, y caben tres posibilidades:

2.1. Que haya acertado, por lo que no entra al bucle y directamente se
imprime el mensaje de acierto, en el que se descubre el n�mero adivinado.
2.2. Que el n�mero sea menor que la inc�gnita, se informe al usuario e 
introduzca un nuevo n�mero, que ser� sometido al mismo proceso que el �ltimo
n�mero introducido.
2.3. Que el n�mero sea mayor que la inc�gnita, se informe al usuario e 
introduzca un nuevo n�mero, que ser� sometido al mismo proceso que el �ltimo
n�mero introducido.
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recursos de E/S
#include <ctime>
#include <cstdlib>

using namespace std;

int main() // Programa principal
{
	// Declaraci�n de datos
	
	int numero;
	int incognita; // N�mero aleatorio a generar
	const int MIN = 1;
	const int MAX = 100;
	const int NUM_VALORES = MAX - MIN + 1;
	const int TERMINADOR = -1;
	int intentos = 0;
	
	// Entrada de datos
	
	time_t t;
	srand(time(&t)); // Inicializa el generador de n�ms.aleatorios
	                 // con el reloj del sistema (hora actual)
	
	// Generaci�n de la inc�gnita (MIN <= incognita <= MAX)
	
	incognita = (rand() % NUM_VALORES) + MIN;
	
	// Entrada del dato n�mero
	
	cout << "Introduzca un n�mero cualquiera: ";
	cin >> numero;
	
	// Establezco la condici�n de mi bucle
	
	bool continua_juego = ((numero !=incognita)&&(numero !=TERMINADOR));
	
	// C�lculos
	
	while (continua_juego){
		
		if (numero < incognita){
			cout << "Su n�mero es menor que el que debe adivinar "
			<< ", pruebe otra vez";
		}
		
		else{
			cout << "Su n�mero es mayor que el que debe adivinar "
			<< ", pruebe otra vez";
		}
		
		// Actualizaci�n del n�mero de intentos
		
		intentos = intentos + 1;
		
		// Nuevo intento
		
		cout << endl;
		cout << "Introduzca un n�mero nuevo: ";
		cin >> numero;
		
		// Actualizaci�n de la condici�n
		
		continua_juego = ((numero !=incognita)&&(numero !=TERMINADOR));
	}
	
	// Salida de resultados
	
	if (numero == TERMINADOR){
		cout << endl;
		cout << "Usted ha abandonado el juego";
	}
	
	else{
		cout << endl;
		cout << "Lo ha logrado en " << intentos << " intentos";
		cout << endl;
		cout << "Ha acertado el n�mero a adivinar";
		cout << endl;
		cout << "Ese n�mero es " << incognita;
	}
	
	return 0;
	
}	
