/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa nos calcula el n�mero de d�gitos que componen un n�mero
introducido por el usuario. Adem�s, nos da tambi�n como resultado las cifras
del n�mero introducido separadas por barras.

Para resolver lo pedido, he hecho uso de dos bucles. Uno consiste en un filtro
que no deja pasar los enteros negativos. El segundo es el n�cleo del programa.
En el segundo bucle encontramos los c�lculos principales. El �ltimo d�gito
de la cifra se calculo como el resto del n�mero introducido al dividirlo por 
10, y dicho resto se convierte a string y se le suma al dato string resultado,
el cual se va actualizando en cada iteraci�n. Tras el c�lculo del �ltimo
d�gito, este se elimina del n�mero (el cual hay que seguir dividiendo por
10) dividi�ndolo por 10, debido a que el n�mero es de tipo int y se le queda
asignada la parte entera del cociente.Tambi�n se actualiza el contador (que
estaba a 0 y se le va sumando 1 por cada iteraci�n) y el dato de tipo bool
que determina la condici�n de mi bucle, ya que necesito que se eval�e la 
condici�n para saber si llevar a cabo otra iteraci�n o no.

Finalmente, como falta un d�gito por contar (es la cifra m�s significativa del
n�mero introducido, la cual no se divide por 10 al ser menor que 10), se le 
suma 1 m�s al contador (esto tambi�n cubre el caso de que el n�mero introducido
sea de una cifra, pues no se habr�a ejecutado el bucle, el contador estar�a a 
0 y ser�a necesario sumarle 1). Tambi�n se suma ese mismo d�gito que no se
ha recontado a la cadena resultado y ya est�n los datos listos para imprimirse
en pantalla.
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recursos de E/S
#include <string>

using namespace std;

int main() // Programa principal
{
	// Declaraci�n de datos
	
	int numero;
	int numero_digitos = 0 ; // Contador del n� de d�gitos (a partir del 0)
	int resto;
	bool varios_digitos;
	string resultado = "|";
	
	// Entrada de datos
	
	do{
		cout << "Introduzca un n�mero entero: ";
		cin >> numero;
	}
	while (numero < 0);
	
	// C�lculos
	
	varios_digitos = numero >= 10;
	
	while (varios_digitos){
		
		// C�lculo del �ltimo d�gito
		
		resto = numero%10;
		
		// Suma del d�gito a la cadena de resultados
		
		resultado = "|" + to_string(resto) + resultado;
		
		// Recuento del n�mero de d�gitos
		
		numero_digitos = numero_digitos + 1;
		
		// Actualizaci�n del n�mero tras obtener su �ltimo digito
		
		numero = numero/10;
		
		// Actualizaci�n de la condici�n del bucle para nueva evaluaci�n
		
		varios_digitos = numero >= 10;
	}
	
	// Suma de la cifra m�s significativa a la cadena de resultados
	
	resultado = "|" + to_string(numero) + resultado;
	
	// Sumamos 1 al contador ya que el d�gito menor que 10 no se ha considerado
	
	numero_digitos = numero_digitos + 1;
	
	// Salida de datos 
	
	cout << endl;
	cout << "El n�mero introducido tiene " << numero_digitos << " d�gito(s)";
	cout << endl;
	cout << resultado;
	
	return 0;
	
}
