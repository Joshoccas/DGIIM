/***************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/*
Programa que trabaja sobre un objeto la clase DepositoBancario (recordar que 
viene caracterizada por un capital y un inter�s) y realiza dos tareas:

		1. Dado un n�mero de a�os, modifica el capital del dep�sito tantas
		veces como los a�os indicados aplicando el inter�s de dicho dep�sito
		a cada a�o.
		
		2. Calcula el total de a�os necesarios para doblar la cantidad
		inicial de un dep�sito al aplicarle el inter�s que lo caracteriza
		a cada a�o.
		
Para la primera tarea he implementado el m�todo CapitalEnAnios y para la 
segunda he implementado el m�todo AniosParaDoblar, que vienen explicados
m�s abajo en el c�digo.
*/ 
/***************************************************************************/

#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

/////////////////////////////////////////////////////////////////////////////
// La clase "Dinero" representa cantidades monetarias expresadas en dos
// unidades enteras: euros y c�ntimos

class Dinero
{

private:

	// PRE: 0 <= euros
	int euros;  // Num. de euros

	// PRE: 0 <= centimos < 100
	int centimos; // Num. de c�ntimos
	
public:

	/***********************************************************************/
	// Constructor sin argumentos.
	
	Dinero (void) : euros(0), centimos(0)
	{ }
	
	/***********************************************************************/
	// Constructor con un argumento.
	// Recibe: cantidad, n�mero de euros (double). 
	// 		   Si es un valor con decimales indica que tiene c�ntimos. 
	//         Por ejemplo: 7.45 indicar� 7 euros y 45 c�ntimos. 
	//
	// PRE:  0 <= cantidad

	Dinero (double cantidad) 
	{	
		euros = (cantidad*100) / 100; 
		centimos = ((int) (cantidad*100)) % 100;
	}		
			
	/***********************************************************************/
	// Constructor con dos argumentos.
	// Recibe: los_euros, n�m. de euros
	//		   los_centimos, el n�m. de c�ntimos. Si "los_centimos" es mayor 
	//				o igual que 100 ajusta su valor para garantizar la validez 
	//				del campo "centimos" (entre 0 y 99) y actualiza el valor 
	//				del campo "euros" coherentemente. 
	// PRE:  0 <= los_euros
	// PRE:  0 <= los_centimos
	// POST: 0 <= centimos < 100

	Dinero (int los_euros, int los_centimos)
	{
		centimos = los_centimos%100;
		euros    = los_euros + (los_centimos/100);
	}

	/***********************************************************************/
	// M�todos Get

	// Devuelve el n�mero de euros completos
	
	int GetEuros (void)
	{
		return (euros);
	}

	// Devuelve el n�mero de c�ntimos
	
	int GetCentimos (void)
	{
		return (centimos);
	}

	// Devuelve el valor num�rico del dato "Dinero". 
	// Por ejemplo, Si el estado del objeto es {euros=7, centimos=45} 
	// devuelve 7.45 
	
	double GetValor (void)
	{
		return (euros+(centimos/100.0));
	}
	
	/***********************************************************************/
	// M�todos que modifican el objeto

	// Modifica el valor de los dos campos, sumando los valores dados en 
	// los par�metros "euros_suman" y "centimos_suman".  

	void Incrementa (int euros_suman, int centimos_suman) {
		IncrementaCentimos (centimos_suman);
		IncrementaEuros (euros_suman);
	}
	
	// Modifica el valor guardado en el objeto, sumando la cantidad dada 
	// en el valor num�rico "cantidad_suma"

	void Incrementa (double cantidad_suma) 
	{	
		int los_euros = (cantidad_suma*100) / 100; 
		int los_centimos = (cantidad_suma - los_euros)*100;
		
		Incrementa (los_euros, los_centimos); 
	}
	
	/***********************************************************************/
	// Representar en forma de cadena el valor de un dato "Dinero" 
	// Devuelve: un string con la representaci�n textual de un dato Dinero.  

	string ToString (void)
	{
		string cad;
			
		cad = to_string(euros) + " euros y " + to_string(centimos) + 
		" c�ntimos";
			
		return(cad);
	}

	/***********************************************************************/
	
private: 

	/***********************************************************************/
	// Modifica �nicamente el valor del campo "euros" 

	void IncrementaEuros (int euros_suman) {
		euros = euros + euros_suman;
	}

	// Modifica el valor del campo "centimos". Si "centimos_suman" es mayor 
	// o igual que 100 ajusta su valor para garantizar la validez del campo 
	// "centimos" (entre 0 y 99) y actualiza el valor del campo "euros".
	 
	void IncrementaCentimos (int centimos_suman) {
		int total_centimos = centimos + centimos_suman;
		centimos = total_centimos % 100;
		euros    = euros + (total_centimos / 100);
	}
	
	/***********************************************************************/
	// Calcula y devuelve en n�mero de d�gitos de "num"
	
	int NumDigitos (int num) 
	{	
		int	num_digitos = 1; 
		 
		while (num/10 > 0) {
			num /= 10; 
			num_digitos++;
		}
		return (num_digitos); 
	}
	
	/***********************************************************************/
	
};

/////////////////////////////////////////////////////////////////////////////

class DepositoBancario
{
	private:
		
		Dinero capital;
		double interes;
	
	public:
		
		// OBSERVACI�N: No he creado un constructor sin argumentos ya que no
		// tendr�a sentido tener un capital de 1 c�ntimo ni un inter�s de 
		// 0.01%. (Esto se debe a que el capital y el inter�s no pueden ser
		// mutuamente 0
		
		// Constructor con argumentos
		// PRE: euros y c�ntimos de "cantidad" deben ser mayores o iguales que
		// 		0 y no pueden ser simult�neamente 0.
		//		0 < a_incrementar <= 10
		
		DepositoBancario (Dinero cantidad, double a_incrementar) :
				capital (cantidad), interes(a_incrementar)
		{}
		
		
	
	public:
		
		/*********************************************************************/
		// M�todo que incrementa el capital de un dep�sito bancario en funci�n
		// de su inter�s y los a�os especificados por el usuario
		// PRE: 1 <= anios <= 20
		// Recibe: int a�os
		// Devuelve: Nada. Solo modifica el capital del dato DepositoBancario 
		// sobre el que se est� trabajando
		
		void CapitalEnAnios (int anios)
		{
			
			// PORCENTAJE NO, HAY VARIABLES QUE PUEDEN TENER VALOR QUE NO 
			// VAR�A
			
			double porcentaje = interes/100;
			double a_incrementar;
			
			for(int i = 0; i < anios; i++){
				
				a_incrementar = capital.GetValor()*porcentaje;
				
				capital.Incrementa(a_incrementar);
			}
		}
		
		/*********************************************************************/
		// M�todo que calcula los a�os necesarios para que el capital de un 
		// dato DepositoBancario se doble con el inter�s que lo caracteriza
		// Recibe: Nada
		// Devuelve : int --> los a�os necesarios para doblar el capital
		
		int AniosParaDoblar (void)
		{
			// Inicializamos los a�os a contar a 0
			
			int anios = 0;
			
			// El bucle parar� de ejecutarse cuando capital.GetValor() sea
			// mayor o igual que el doble de su valor inicial
			
			double parada = 2*capital.GetValor();
			double porcentaje = interes/100;
			double a_incrementar;
			
			// ESTO SE DEBER�A HACER CON UN WHILE Y NO CON UN FOR (CORRECCI�N
			// DEL PROFE)
			
			for(int i = 0; capital.GetValor() < parada; i++){
				
				a_incrementar = capital.GetValor()*porcentaje;
				capital.Incrementa(a_incrementar);
				
				// Una vez hecho el incremento, actualizamos los a�os
				
				anios++;
			}
			
			return(anios);
		}
		
		/*********************************************************************/
		// Representa en forma de cadena el valor de un dato "DepositoBancario" 
		// Devuelve: un string con la representaci�n textual de dicho dato 
		// (es decir, el capital del dep�sito en euros y c�ntimos y el inter�s
		// caracter�stico de dicho dep�sito) 
		
		string ToString (void)
		{
			string cad;
			
			cad = to_string(capital.GetEuros()) + " euros y " + 
			to_string(capital.GetCentimos()) + " c�ntimos " + "(inter�s del " +
			to_string(interes) + "%)";
			
			return(cad);
		}
		
};

//////////////////////////////////////////////////////////////////////////////

class Lector
{
	private:
		
		string titulo;
	
	public:
		
		// Constructor sin argumentos
		
		Lector (void) : titulo ("")
		{ }
		
		// Constructor con argumentos
		
		Lector (string cad) : titulo (cad)
		{ }
		
		// M�todo Set para fijar el campo "titulo"
		
		void SetTitulo (string cad)
		{
			titulo = cad;
		}
		
		/*********************************************************************/
		// Lee un dato int.
		// La lectura est� etiquetada con "titulo"
		// La lectura se efect�a repetidamente hasta que se introduce un valor
		// int correcto.
		
		int LeeEntero (void)
		{
			string cadena;
			
			do{
				cout << titulo;
				getline(cin, cadena);
			}
			while (!EsEntero(cadena));
			
			return (stoi(cadena));
		}
		
		/*********************************************************************/
		// Lee un dato int.
		// La lectura est� etiquetada con "titulo"
		// PRE: menor <= mayor
		// POST: menor <= valor devuelto <= mayor
		
		int LeeEnteroEnRango (int menor, int mayor)
		{
			int numero;
			
			do{
				
				numero = LeeEntero ();
			}
			while ((numero<menor) || (numero>mayor));
			
			return (numero);
		}
		
		/*********************************************************************/
		// Lee un dato int que debe ser mayor o igual que "menor" y lo devuelve.
		// La lectura est� etiquetada con "titulo"
		
		int LeeEnteroMayorOIgual (int menor)
		{
			int numero;
			
			do{
				numero = LeeEntero ();
			}
			while (numero < menor);
			
			return (numero);
		}
		
		/*********************************************************************/
		// Lee un dato double.
		// La lectura est� etiquetada con "titulo"
		// La lectura se efect�a repetidamente hasta que se introduce un valor
		// double correcto.
		
		double LeeReal (void)
		{
			string cadena;
			
			do{
				cout << titulo;
				getline(cin, cadena);
			}
			while (!EsReal(cadena));
			
			return (stod(cadena));
		}
		
		/*********************************************************************/
		// Lee un dato double.
		// La lectura est� etiquetada con "titulo"
		// PRE: menor <= mayor
		// POST: menor <= valor devuelto <= mayor
		
		double LeeRealEnRango (int menor, int mayor)
		{
			double numero;
			
			do{
				
				numero = LeeReal ();
			}
			while ((numero<menor) || (numero>mayor));
			
			return (numero);
		}

		/*********************************************************************/
		// Lee un dato double que debe ser mayor o igual que "menor" y lo 
		// devuelve. 
		// La lectura est� etiquetada con "titulo"
		
		double LeeRealMayorOIgual (int menor)
		{
			double numero;
			
			do{
				numero = LeeReal ();
			}
			while (numero < menor);
			
			return (numero);
		}

		/*********************************************************************/
		
		double LeeRealEnRango2 (int menor, int mayor)
		{
			double numero;
			
			do{
				
				numero = LeeReal ();
			}
			while ((numero <= menor) || (numero > mayor));
			
			return (numero);
		}

	
	private:
		
		/*********************************************************************/
		// Devuelve una NUEVA cadena, resultante de eliminar los �ltimos
		// caracteres separadores de "cadena". Los caracteres separadores son
		// el espacio en blanco, el tabulador y el salto de l�nea.
		// Usaremos la funci�n isspace() para simplificar el c�lculo.
		//
		// Recibe: cadena, string sobre la que se va a trabajar.
		// Devuelve: el resultado de eliminar los �ltimos separadores de 
		// "cadena"
		/*********************************************************************/
		
		string EliminaUltimosSeparadores (string cadena)
		{
			while (cadena.length()>0 && isspace(cadena.back()))
				cadena.pop_back();
			
			return (cadena);
		}
		
		/*********************************************************************/
		// Devuelve una NUEVA cadena, resultante de eliminar los primeros
		// caracteres separadores de "cadena". Los caracteres separadores son
		// el espacio en blanco, el tabulador y el salto de l�nea.
		// Usaremos la funci�n isspace() para simplificar el c�lculo.
		//
		// Recibe: cadena, string sobre la que se va a trabajar.
		// Devuelve: el resultado de eliminar los �ltimos separadores de 
		// "cadena"
		/*********************************************************************/
		string EliminaPrimerosSeparadores (string cadena)
		{
			// Buscar el primer car�cter no espacio
			unsigned int pos = 0;
			while (pos < cadena.length() && isspace(cadena.at(pos))) pos++;
			
			string local;
			
			// Copiar todos los que quedan
			while (pos < cadena.length()) {
				local.push_back(cadena.at(pos));
				pos++;
			}
			
			return (local);
		}
		
		/*********************************************************************/
		// Devuelve una NUEVA cadena, resultante de eliminar los primeros 
		// �ltimos caracteres separadores de "cadena". Los caracteres 
		// separadores son el espacio en blanco, el tabulador y el salto de
		// l�nea
		//
		// Recibe: cadena, string sobre la que se va a trabajar.
		// Devuelve: el resultado de eliminar los primeros y los �ltimos
		//           separadores de "cadena".
		/*********************************************************************/
		
		string EliminaPrimerosYUltimosSeparadores (string cadena)
		{
			string cadena_podada = EliminaPrimerosSeparadores (cadena);
			cadena_podada = EliminaUltimosSeparadores (cadena_podada);
			
			return (cadena_podada);
		}
		
		/*********************************************************************/
		// Devuelve "true" si "cadena" es la representaci�n textual de un
		// entero
		//
		// Recibe: cadena, string sobre la que se va a trabajar.
		// Devuelve: "true" si "cadena" es la representaci�n textual de un int
		
		bool EsEntero (string cadena)
		{
			bool es_entero = true;
			
			cadena = EliminaPrimerosSeparadores (cadena);
			cadena = EliminaUltimosSeparadores (cadena);
			
			unsigned int long_cadena = cadena.length();
			
			if (long_cadena == 0) es_entero = false;
			else {
				
				// Si el primer car�cter es '+' � '-', perfecto. En ese caso
				// se pasa al siguiente car�cter (posici�n 19.
				
				unsigned int pos;
				if (cadena.at(0)=='-' || cadena.at(0) == '+') pos = 1;
				else pos = 0;
				
				while ((pos < long_cadena) && es_entero) {
					if(!isdigit(cadena.at(pos))) es_entero = false;
					else pos++;
				}
			}
			
			return (es_entero);
		}
		
		/*********************************************************************/

		bool EsReal (string cadena)
		{
			bool es_real = true;
			
			cadena = EliminaPrimerosSeparadores (cadena);
			cadena = EliminaUltimosSeparadores (cadena);
			
			unsigned int long_cadena = cadena.length();
			
			if (long_cadena == 0) es_real = false;
			else {
				
				// Si el primer car�cter es '+' � '-', perfecto. En ese caso
				// se pasa al siguiente car�cter (posici�n 19.
				
				unsigned int pos;
				if (cadena.at(0)=='-' || cadena.at(0) == '+') pos = 1;
				else pos = 0;
				
				// Bandera que se activa al encontrar un punto
				bool encontrado_un_punto = false;
				
				while ((pos < long_cadena) && es_real) {
					
					char c = cadena.at(pos);
					
					if (!isdigit(c)) {
						
						// Solo puede haber un punto.
						// Si se ha encontrado un punto y ya se hab�a
						// encontrado otro, error. Si no, activar la bandera
						// "encontrado_un_punto" (ya no puede haber m�s).
						
						if (c == '.') {
							if (encontrado_un_punto) es_real = false;
							else encontrado_un_punto = true;
						}
						
					    // Si no es un punto ni un d�gito --> error
						else es_real = false;
					}
					
					pos++;
					
				}  // while ((pos < long_cadena) && es_real)
				
			}  // else de if (long_cadena == 0)
			
			return (es_real);
		}
};

int main() // Programa principal
{
	// Declaraci�n de datos
	
	int euros;
	int centimos;
	double interes;
	int anios;
	
	// Entrada de datos
	
	Lector lector;
	
	lector.SetTitulo("Introduzca los euros de los que dispone: ");
	euros = lector.LeeEnteroMayorOIgual(0);
	
	lector.SetTitulo("Introduzca los c�ntimos de los que dispone: ");
	
	if (euros == 0)
		centimos = lector.LeeEnteroMayorOIgual(1);
	
	else
		centimos = lector.LeeEnteroMayorOIgual(0);
	
	lector.SetTitulo("Introduzca el inter�s a aplicar: ");
	interes = lector.LeeRealEnRango2(0, 10);
	
	lector.SetTitulo("Introduzca el n�mero de a�os a aplicar el inter�s: ");
	anios = lector.LeeRealEnRango(1, 20);
	
	cout << endl << endl;
	
	// Creaci�n del objeto de la clase Dinero
	
	Dinero capital (euros, centimos);
	
	// Creaci�n del objeto de la clase DepositoBancario y su copia (para poder
	// (conservar el valor del capital inicial para el segundo apartado)
	
	DepositoBancario deposito (capital, interes);
	DepositoBancario copia (deposito);
	
	// Operaciones
	
	cout << "VALOR DEL CAPITAL TRAS APLICAR EL INTER�S " << anios << " A�OS";
	cout << endl << endl;
	
	deposito.CapitalEnAnios(anios);
	
	// Salida de resultados
	
	cout << deposito.ToString() << endl << endl;
	
	/*************************************************************************/
	// 2� APARTADO: C�LCULO DE LOS A�OS NECESARIOS PARA DOBLAR EL CAPITAL 
	
	// Operaciones
	
	cout << "A�OS QUE SE TARDAN EN DOBLAR EL CAPITAL INICIAL";
	cout << endl << endl;
	
	int anios_para_doblar;
	
	deposito = copia;
	
	anios_para_doblar = deposito.AniosParaDoblar();
	
	// Salida de resultados
	
	cout << "Para doblar el capital inicial con el inter�s introducido se "
	<< "requieren " << anios_para_doblar << " a�os";
	
	return 0;
}
