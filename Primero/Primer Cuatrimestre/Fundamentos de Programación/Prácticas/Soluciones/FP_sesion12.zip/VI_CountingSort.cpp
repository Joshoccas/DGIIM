/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/*
Programa que trabaja sobre una secuencia de caracteres inicial con el fin de
crear una secuencia de caracteres que consta de los mismos caracteres que
la inicial pero ordenados alfab�ticamente. Finalmente se muestra el estado
de la cadena ordenada en pantalla.

Para ello he creado los dos m�todos que se piden:

			1. SecuenciaCaracteres CountingSortEntre (char min, char max)
			2. SecuenciaCaracteres CountingSort(void)

Dichos m�todos est�n comentados en el propio c�digo de m�s abajo, en los 
comentarios intercalados.
*/
/***************************************************************************/

#include <iostream>
#include <string>

using namespace std;

/////////////////////////////////////////////////////////////////////////////

class SecuenciaCaracteres {

private:

    static const int TAMANIO = 50; // N�m.casillas disponibles
    char vector_privado[TAMANIO];

    // PRE: 0<=total_utilizados<TAMANIO

    int total_utilizados; // N�m.casillas ocupadas

public:

    /***********************************************************************/
    // Constructor sin argumentos

    SecuenciaCaracteres (void) : total_utilizados (0)
    {}
    
    /***********************************************************************/
    // Constructor con argumentos
    	
    SecuenciaCaracteres (string cadena) : total_utilizados (0)
    {
    	StringACaracteres (cadena);
    }

    /***********************************************************************/
    // Devuelve el n�mero de casillas ocupadas

    int TotalUtilizados (void)
    {
        return (total_utilizados);
    }

    /***********************************************************************/
    // Devuelve el n�mero de casillas disponibles

    int Capacidad (void)
    {
        return (TAMANIO);
    }

    /***********************************************************************/
    // "Vac�a" completamente la secuencia

	void EliminaTodos()
	{
		total_utilizados = 0;
	}

    /***********************************************************************/
    // A�ade un elemento ("nuevo") al vector.
    // PRE: total_utilizados < TAMANIO
    // 		La adici�n se realiza si hay alguna casilla disponible.
    // 		El nuevo elemento se coloca al final del vector.
    // 		Si no hay espacio, no se hace nada.

    void Aniade (char nuevo)
    {
        if (total_utilizados < TAMANIO){
            vector_privado[total_utilizados] = nuevo;
            total_utilizados++;
        }
    }

    /***********************************************************************/
    // Devuelve el elemento de la casilla "indice"
    // PRE: 0 <= indice < total_utilizados

    char Elemento (int indice)
    {
        return (vector_privado[indice]);
    }

    /***********************************************************************/
    // Cambia el contenido de la casilla "indice" por el valor "nuevo"
    // PRE: 0 <= indice < total_utilizados

   void Modifica (int indice, char nuevo)
   {
		if ((indice >= 0) && (indice < total_utilizados))
			vector_privado[indice] = nuevo;
   }

    /***********************************************************************/
    // Eliminar el car�cter de la posici�n dada por "indice".
    // Realiza un borrado f�sico (desplazamiento y sustituci�n).
    // PRE: 0 <= indice < total_utilizados

    void Elimina (int indice)
    {
        if ((indice >= 0) && (indice < total_utilizados)) {

            int tope = total_utilizados-1; // posic. del �ltimo

            for (int i = indice ; i < tope ; i++)
                vector_privado[i] = vector_privado[i+1];

            total_utilizados--;
        }
    }
    
    /***********************************************************************/
    // Inserta el car�cter "nuevo" en la posici�n dada por "indice".
    // Desplaza todos los caracteres una posici�n a la derecha antes de 
	// copiar en "indice" en valor "nuevo".
	// PRE: 0 <= pos_insercion < total_utilizados
    // PRE: total_utilizados < TAMANIO
    // 		La inserci�n se realiza si hay alguna casilla disponible.
    // 		Si no hay espacio, no se hace nada.
    
	void Inserta (int pos_insercion, char valor_nuevo)
	{
        if ((pos_insercion >= 0) && (pos_insercion < total_utilizados) 
		    && (total_utilizados < TAMANIO)) {
		
			for (int i = total_utilizados; i > pos_insercion; i--)
				vector_privado[i] = vector_privado[i-1];
			
			vector_privado[pos_insercion] = valor_nuevo;
			total_utilizados++;		
		}
	}
    /***********************************************************************/
    
    SecuenciaCaracteres CountingSortEntre (char min, char max)
    {
    	
    	// Se crea el vector de frecuencias que tendr� una capacidad de 
    	// NUM_FREC = max - min + 1, pues todas las letras encontradas en
    	// la secuencia de caracteres est�n entre min y max. De partida,
    	// las apariciones de cada letra son 0
    	
    	const int NUM_FREC = 300;
    	int frecuencias[NUM_FREC] = {0};
    	
    	// Recorremos cada uno de los caracteres de la secuencia
    	
    	for(int i = 0; i < total_utilizados; i++){
    		
    		// Recorremos el vector de frecuencias para sumar 1 al contador
    		// de apariciones del car�cter que se est� evaluando
    		
    		for(int j = 0; j < max; j++){
    			
    			if (vector_privado[i] == min + j)
    				frecuencias[j]++;
    		}
    	}
		
		// Creaci�n de la secuencia de salida
		
		SecuenciaCaracteres resultado;
		
		// Recorremos nuevamente el vector de frecuencias
		
		for (int i = 0; i < NUM_FREC; i++){
			
			// Si el contador de apariciones de una letra no es 0, se a�ade 
			// a la secuencia de salida dicha letra tantas veces como 
			// apariciones haya tenido
			
			if (frecuencias[i] != 0){
			
				for(int j = 0; j < frecuencias[i]; j++)
					resultado.Aniade(min + i);
			}
		}
		
		return(resultado);
    }
    
    /***********************************************************************/
    // M�todo que devuelve un objeto de la clase SecuenciaCaracteres cuyo vector 
	// privado dato miembro es el vector privado dato miembro del objeto sobre 
	// el que se ejecuta el m�todo pero ordenado alfab�ticamente.
	
    SecuenciaCaracteres CountingSort(void)
    {
    	// Inicializamos minimo y maximo como el primer caracter del vector
    	// del objeto sobre el que se ejecuta el m�todo ya que podr�a 
    	// introducirse una secuencia de solo un car�cter
    	
    	// B�squeda del m�nimo
    	
    	char minimo = vector_privado[0]; 
    	
    	for (int i = 1; i < total_utilizados; i++){
    		
    		if (vector_privado[i] < minimo)
    			minimo = vector_privado[i];
    	}
    	
    	// B�squeda del m�ximo
    	
    	char maximo = vector_privado[0];
    	
    	for (int i = 1; i < total_utilizados; i++){
    		
    		if (vector_privado[i] > maximo)
    			maximo = vector_privado[i];
    	}
    	
    	// Llamada al m�todo CountingSortEntre y creaci�n del objeto resultado
    	
    	SecuenciaCaracteres resultado (CountingSortEntre(minimo, maximo));
    	
    	return (resultado);
    }
    
    /***********************************************************************/
    // Compone un string con todos los caracteres que est�n
    // almacenados en la secuencia y lo devuelve.

    string ToString()
    {
        string cadena;

        for (int i=0; i<total_utilizados; i++)
            cadena = cadena + vector_privado[i];

        return (cadena);
    }

	/*****************************************************************/
private:
	
	// M�todo que rellena el vector privado del objeto a partir de un
	// dato string
		
	void StringACaracteres (string cadena)
	{
		for(unsigned int i = 0; i < cadena.length(); i++){
			
			Aniade(cadena.at(i));
		}
	}
};

//////////////////////////////////////////////////////////////////////////////

int main() // Programa principal
{
	// Declaraci�n de datos
	
	string a_ordenar;
	
	// Entrada de datos
	
	cout << "Introduzca una secuencia de caracteres en min�scula: ";
	getline(cin, a_ordenar);
	
	// Creaci�n del objeto
	
	SecuenciaCaracteres sin_ordenar(a_ordenar);
	
	// Operaciones
	
	SecuenciaCaracteres ordenada(sin_ordenar.CountingSort());
	
	// Salida de datos
	
	cout << "La secuencia ordenada es: " << ordenada.ToString();
	
	return 0;
}
