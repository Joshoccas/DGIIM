/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
	En este programa se presenta una versi�n simple de la clase "Dinero"
	que ser� �til para trabajar de forma precisa con datos monetarios.

	La clase tiene dos datos miembro: "euros" y "centimos".
	Cuando se modifiquen �stos, la clase debe permitir que se introduzca
	un n�mero de c�ntimos mayor de 100 y reajustar las cantidades
	adecuadamente.
		Por ejemplo, si asignamos 20 euros y 115 c�ntimos, el objeto debe
		almacenar 21 en "euros" y 15 en "centimos".
	
	Est programa calcula el precio final de un producto a partir de su 
	precio inicial, de un incremento fijo mensual y de un n�mero de 
	meses. El programa muestra, mes a mes, el precio del producto. 
	
	Adem�s, se ha ampliado esta clase con respecto a la versi�n anterior
	incluyendo 12 nuevos m�todos que vienen explicados m�s abajo.
*/ 
/***************************************************************************/

#include <iostream>
#include <iomanip>
#include <string>
#include <cmath>
using namespace std;

/////////////////////////////////////////////////////////////////////////////
// La clase "Dinero" representa cantidades monetarias expresadas en dos
// unidades enteras: euros y c�ntimos

class Dinero
{

private:

	// PRE: 0 <= euros
	int euros;  // Num. de euros

	// PRE: 0 <= centimos < 100
	int centimos; // Num. de c�ntimos
	
public:

	/***********************************************************************/
	// Constructor sin argumentos.
	
	Dinero (void) : euros(0), centimos(0)
	{ }
	
	/***********************************************************************/
	// Constructor con un argumento.
	// Recibe: cantidad, n�mero de euros (double). 
	// 		   Si es un valor con decimales indica que tiene c�ntimos. 
	//         Por ejemplo: 7.45 indicar� 7 euros y 45 c�ntimos. 
	//
	// PRE:  0 <= cantidad

	Dinero (double cantidad) 
	{	
		euros = (cantidad*100) / 100; 
		centimos = ((int) (cantidad*100)) % 100;
	}		
			
	/***********************************************************************/
	// Constructor con dos argumentos.
	// Recibe: los_euros, n�m. de euros
	//		   los_centimos, el n�m. de c�ntimos. Si "los_centimos" es mayor 
	//				o igual que 100 ajusta su valor para garantizar la validez 
	//				del campo "centimos" (entre 0 y 99) y actualiza el valor 
	//				del campo "euros" coherentemente. 
	// PRE:  0 <= los_euros
	// PRE:  0 <= los_centimos
	// POST: 0 <= centimos < 100

	Dinero (int los_euros, int los_centimos)
	{
		centimos = los_centimos%100;
		euros    = los_euros + (los_centimos/100);
	}

	/***********************************************************************/
	// M�todos Get

	// Devuelve el n�mero de euros completos
	
	int GetEuros (void)
	{
		return (euros);
	}

	// Devuelve el n�mero de c�ntimos
	
	int GetCentimos (void)
	{
		return (centimos);
	}

	// Devuelve el valor num�rico del dato "Dinero". 
	// Por ejemplo, Si el estado del objeto es {euros=7, centimos=45} 
	// devuelve 7.45 
	
	double GetValor (void)
	{
		return (euros+(centimos/100.0));
	}
	
	/***********************************************************************/
	// M�todos que modifican el objeto

	// Modifica el valor de los dos campos, sumando los valores dados en 
	// los par�metros "euros_suman" y "centimos_suman".  

	void Incrementa (int euros_suman, int centimos_suman) {
		IncrementaCentimos (centimos_suman);
		IncrementaEuros (euros_suman);
	}
	
	// Modifica el valor guardado en el objeto, sumando la cantidad dada 
	// en el valor num�rico "cantidad_suma"

	void Incrementa (double cantidad_suma) 
	{	
		int los_euros = (cantidad_suma*100) / 100; 
		int los_centimos = (cantidad_suma - los_euros)*100;
		
		Incrementa (los_euros, los_centimos); 
	}
	
	/***********************************************************************/
	// Representa en forma de cadena el valor de un dato "Dinero"
	// Devuelve: un string con la representaci�n textual de un dato Dinero.  

	string ToString (void)
	{
		string cad;
			
		cad = to_string(euros) + " euros y " + to_string(centimos) + 
		" c�ntimos";
			
		return(cad);
	}

	/***********************************************************************/
	// M�todo que devuelve un objeto de la clase Dinero cuyos datos miembro
	// son la suma de los datos miembro del objeto sobre el que se ejecuta
	// y el objeto par�metro
	
	Dinero Incrementa (Dinero cantidad)
	{
		
		int los_euros = euros + cantidad.euros;
		int los_centimos = centimos + cantidad.centimos;
		 
		Dinero resultado (los_euros, los_centimos);
		
		return (resultado);
	}
		
	/***********************************************************************/
	// M�todo que devuelve un objeto de la clase Dinero cuyos datos miembro
	// son la resta de los datos miembro del objeto sobre el que se ejecuta
	// y el objeto par�metro. Si el objeto par�metro es mayor que sobre el
	// que se ejecuta el m�todo, no se hace ning�n decremento
	
	Dinero Decrementa (Dinero cantidad)
	{
		int los_euros;
		int los_centimos;
		
		
		if (euros < cantidad.euros){
			
			los_euros = euros;
			los_centimos = centimos;
		}
			
		else{
			
			if (euros > cantidad.euros){
				
				if (centimos >= cantidad.centimos){
					
					los_euros = euros - cantidad.euros;
					los_centimos = centimos - cantidad.centimos;
				}
				
				else{
					
					const int diferencia = 100;
					
					los_euros = euros - cantidad.euros - 1;
					los_centimos = diferencia + 
					                   (centimos - cantidad.centimos);
				}
			}
			
			if (euros == cantidad.euros){
				
				if (centimos < cantidad.centimos){
					
					los_euros = euros;
					los_centimos = centimos;
				}
				
				else{
					
					los_euros = euros - cantidad.euros;
					los_centimos = centimos - cantidad.centimos;
				}
			}
		}
		
		Dinero resultado (los_euros, los_centimos);
		
		return (resultado);
	}
	
	/***********************************************************************/
	// PRE: El dato introducido debe ser double
	// M�todo que devuelve un objeto de la clase Dinero cuyos datos miembro
	// son la resta de los datos miembro del objeto sobre el que se ejecuta
	// y el objeto par�metro que se crea a partir del double introducido. 
	
	// Si el objeto par�metro es mayor que sobre el que se ejecuta el m�todo, 
	// no se hace ning�n decremento
	
	Dinero Decrementa (double cantidad)
	{
		int los_euros;
		int los_centimos;
		
		Dinero otro (cantidad);
		
		if (euros < otro.euros){
			
			los_euros = euros;
			los_centimos = centimos;
		}
			
		else{
			
			if (euros > otro.euros){
				
				if (centimos >= otro.centimos){
					
					los_euros = euros - otro.euros;
					los_centimos = centimos - otro.centimos;
				}
				
				else{
					
					const int diferencia = 100;
					
					los_euros = euros - otro.euros - 1;
					los_centimos = diferencia + 
					                   (centimos - otro.centimos);
				}
			}
			
			if (euros == otro.euros){
				
				if (centimos < otro.centimos){
					
					los_euros = euros;
					los_centimos = centimos;
				}
				
				else{
					
					los_euros = euros - otro.euros;
					los_centimos = centimos - otro.centimos;
				}
			}
		}
		
		Dinero resultado (los_euros, los_centimos);
		
		return (resultado);
	}
	
	/***********************************************************************/
	// PRE: El dato introducido debe ser double
	// M�todo que devuelve un objeto de la clase Dinero cuyos datos miembro
	// son la suma de los datos miembros del objeto sobre el que se ejecuta el
	// m�todo y los datos del objeto par�metro que se crea a partir del double
	// introducido (en caso de que el double sea 0 o positivo), o son la resta
	// si el double introducido es negativo
	
	Dinero Modifica (double cantidad)
	{
		int los_euros;
		int los_centimos;
		
		if (cantidad >= 0){
			
			Dinero a_sumar (cantidad);
			los_euros = euros + a_sumar.GetEuros();
			los_centimos = centimos + a_sumar.GetCentimos();
		}
		
		else{
			
			cantidad = abs(cantidad);
			Dinero a_restar (cantidad);
			
			bool es_mayor_o_igual = EsMayor(a_restar) || EsIgual (a_restar);
			
			if (!es_mayor_o_igual){
				
				los_euros = euros;
				los_centimos = centimos;
			}
			
			else{
				
				Dinero resultado (Diferencia (a_restar));
				
				los_euros = resultado.GetEuros();
				los_centimos = resultado.GetCentimos();
			}
		}
		
		Dinero modificado (los_euros, los_centimos);
		
		return (modificado);
	}
				
	/***********************************************************************/
	// M�todo que determina si el objeto sobre el que se ejecuta es mayor que
	// el objeto par�metro
	
	bool EsMayor (Dinero otro)
	{
		bool es_mayor;
		
		if (euros > otro.euros)
			es_mayor = true;
		
		else{
			
			if (euros < otro.euros)
				es_mayor = false;
			
			else{
				
				if (centimos < otro.centimos)
					es_mayor = false;
				
				if (centimos > otro.centimos)
					es_mayor = true;
				
				if (centimos == otro.centimos)
					es_mayor = false;
			}
		}
		
		return (es_mayor);
	}
	
	/***********************************************************************/
	// PRE: El dato introducido debe ser un double mayor o igual que 0
	// M�todo que determina si el objeto sobre el que se ejecuta es mayor que
	// el objeto par�metro creado a partir del double introducido
	
	bool EsMayor (double cantidad)
	{
		Dinero otro (cantidad);
		
		bool es_mayor;
		
		if (euros > otro.euros)
			es_mayor = true;
		
		else{
			
			if (euros < otro.euros)
				es_mayor = false;
			
			else{
				
				if (centimos < otro.centimos)
					es_mayor = false;
				
				if (centimos > otro.centimos)
					es_mayor = true;
				
				if (centimos == otro.centimos)
					es_mayor = false;
			}
		}
		
		return (es_mayor);
	}
	
	/***********************************************************************/
	// M�todo que determina si el objeto sobre el que se ejecuta es menor que
	// el objeto par�metro
	
	bool EsMenor (Dinero otro)
	{
		bool es_menor;
		
		if (euros > otro.euros)
			es_menor = false;
		
		else{
			
			if (euros < otro.euros)
				es_menor = true;
			
			else{
				
				if (centimos < otro.centimos)
					es_menor = true;
				
				if (centimos > otro.centimos)
					es_menor = false;
				
				if (centimos == otro.centimos)
					es_menor = false;
			}
		}
		
		return (es_menor);
	}
	
	/***********************************************************************/
	// PRE: El dato introducido debe ser un double mayor o igual que 0
	// M�todo que determina si el objeto sobre el que se ejecuta es menor que
	// el objeto par�metro creado a partir del double introducido
	
	bool EsMenor (double cantidad)
	{
		Dinero otro (cantidad);
		
		bool es_menor;
		
		if (euros > otro.euros)
			es_menor = false;
		
		else{
			
			if (euros < otro.euros)
				es_menor = true;
			
			else{
				
				if (centimos < otro.centimos)
					es_menor = true;
				
				if (centimos > otro.centimos)
					es_menor = false;
				
				if (centimos == otro.centimos)
					es_menor = false;
			}
		}
		
		return (es_menor);
	}
	
	/***********************************************************************/
	// M�todo que determina si el objeto sobre el que se ejecuta es igual que
	// el objeto par�metro
	
	bool EsIgual (Dinero otro)
	{
		bool es_igual;
		
		if ((euros == otro.euros) && (centimos == otro.centimos))
			es_igual = true;
		
		else
			es_igual = false;
		
		return (es_igual);
	}
	
	/***********************************************************************/
	// PRE: El dato introducido debe ser un double mayor o igual que 0
	// M�todo que determina si el objeto sobre el que se ejecuta es igual que
	// el objeto par�metro creado a partir del double introducido
	
	bool EsIgual (double cantidad)
	{
		Dinero otro (cantidad);
		
		bool es_igual;
		
		if ((euros == otro.euros) && (centimos == otro.centimos))
			es_igual = true;
		
		else
			es_igual = false;
		
		return (es_igual);
	}
	
	/***********************************************************************/
	// PRE: El objeto de la clase que se introduce debe ser menor o igual que 
	// el objeto de la clase sobre el que se ejecuta el m�todo
	
	Dinero Diferencia (Dinero otro)
	{
		int los_euros;
		int los_centimos;
		const int AJUSTE = 100;
		
		if (centimos >= otro.centimos){
			
			los_euros = euros - otro.euros;
			los_centimos = centimos - otro.centimos;
		}
		
		else{
			
			los_centimos = AJUSTE + (centimos - otro.centimos);
			los_euros = euros - otro.euros - 1;
		}
		
		Dinero diferencia (los_euros, los_centimos);
		
		return (diferencia);
	}
		
	/***********************************************************************/
	// PRE: La cantidad double que se introduce debe ser menor o igual que 
	// el objeto de la clase sobre el que se ejecuta el m�todo
	
	Dinero Diferencia (double otro)
	{
		Dinero cantidad (otro);
		
		int los_euros;
		int los_centimos;
		const int AJUSTE = 100;
		
		if (centimos >= cantidad.centimos){
		
			los_euros = euros - cantidad.euros;
			los_centimos = centimos - cantidad.centimos;
		}
		
		else{
			
			los_centimos = AJUSTE + (centimos - cantidad.centimos);
			los_euros = euros - cantidad.euros - 1;
		}
		
		Dinero diferencia (los_euros, los_centimos);
		
		return (diferencia);
	}
		
private: 

	/***********************************************************************/
	// Modifica �nicamente el valor del campo "euros" 

	void IncrementaEuros (int euros_suman) {
		euros = euros + euros_suman;
	}

	// Modifica el valor del campo "centimos". Si "centimos_suman" es mayor 
	// o igual que 100 ajusta su valor para garantizar la validez del campo 
	// "centimos" (entre 0 y 99) y actualiza el valor del campo "euros".
	 
	void IncrementaCentimos (int centimos_suman) {
		int total_centimos = centimos + centimos_suman;
		centimos = total_centimos % 100;
		euros    = euros + (total_centimos / 100);
	}
	
	/***********************************************************************/
	// Calcula y devuelve en n�mero de d�gitos de "num"
	
	int NumDigitos (int num) 
	{	
		int	num_digitos = 1; 
		 
		while (num/10 > 0) {
			num /= 10; 
			num_digitos++;
		}
		return (num_digitos); 
	}
	
	/***********************************************************************/
	
};

/////////////////////////////////////////////////////////////////////////////

class Lector
{
	private:
		
		string titulo;
	
	public:
		
		// Constructor sin argumentos
		
		Lector (void) : titulo ("")
		{ }
		
		// Constructor con argumentos
		
		Lector (string cad) : titulo (cad)
		{ }
		
		// M�todo Set para fijar el campo "titulo"
		
		void SetTitulo (string cad)
		{
			titulo = cad;
		}
		
		/*********************************************************************/
		// Lee un dato int.
		// La lectura est� etiquetada con "titulo"
		// La lectura se efect�a repetidamente hasta que se introduce un valor
		// int correcto.
		
		int LeeEntero (void)
		{
			string cadena;
			
			do{
				cout << titulo;
				getline(cin, cadena);
			}
			while (!EsEntero(cadena));
			
			return (stoi(cadena));
		}
		
		/*********************************************************************/
		// Lee un dato int.
		// La lectura est� etiquetada con "titulo"
		// PRE: menor <= mayor
		// POST: menor <= valor devuelto <= mayor
		
		int LeeEnteroEnRango (int menor, int mayor)
		{
			int numero;
			
			do{
				
				numero = LeeEntero ();
			}
			while ((numero<menor) || (numero>mayor));
			
			return (numero);
		}
		
		/*********************************************************************/
		// Lee un dato int que debe ser mayor o igual que "menor" y lo devuelve.
		// La lectura est� etiquetada con "titulo"
		
		int LeeEnteroMayorOIgual (int menor)
		{
			int numero;
			
			do{
				numero = LeeEntero ();
			}
			while (numero < menor);
			
			return (numero);
		}
		
		/*********************************************************************/
		// Lee un dato double.
		// La lectura est� etiquetada con "titulo"
		// La lectura se efect�a repetidamente hasta que se introduce un valor
		// double correcto.
		
		double LeeReal (void)
		{
			string cadena;
			
			do{
				cout << titulo;
				getline(cin, cadena);
			}
			while (!EsReal(cadena));
			
			return (stod(cadena));
		}
		
		/*********************************************************************/
		// Lee un dato double.
		// La lectura est� etiquetada con "titulo"
		// PRE: menor <= mayor
		// POST: menor <= valor devuelto <= mayor
		
		double LeeRealEnRango (int menor, int mayor)
		{
			double numero;
			
			do{
				
				numero = LeeReal ();
			}
			while ((numero<menor) || (numero>mayor));
			
			return (numero);
		}

		/*********************************************************************/
		// Lee un dato double que debe ser mayor o igual que "menor" y lo 
		// devuelve. 
		// La lectura est� etiquetada con "titulo"
		
		double LeeRealMayorOIgual (int menor)
		{
			double numero;
			
			do{
				numero = LeeReal ();
			}
			while (numero < menor);
			
			return (numero);
		}

		/*********************************************************************/
	
	private:
		
		/*********************************************************************/
		// Devuelve una NUEVA cadena, resultante de eliminar los �ltimos
		// caracteres separadores de "cadena". Los caracteres separadores son
		// el espacio en blanco, el tabulador y el salto de l�nea.
		// Usaremos la funci�n isspace() para simplificar el c�lculo.
		//
		// Recibe: cadena, string sobre la que se va a trabajar.
		// Devuelve: el resultado de eliminar los �ltimos separadores de 
		// "cadena"
		/*********************************************************************/
		
		string EliminaUltimosSeparadores (string cadena)
		{
			while (cadena.length()>0 && isspace(cadena.back()))
				cadena.pop_back();
			
			return (cadena);
		}
		
		/*********************************************************************/
		// Devuelve una NUEVA cadena, resultante de eliminar los primeros
		// caracteres separadores de "cadena". Los caracteres separadores son
		// el espacio en blanco, el tabulador y el salto de l�nea.
		// Usaremos la funci�n isspace() para simplificar el c�lculo.
		//
		// Recibe: cadena, string sobre la que se va a trabajar.
		// Devuelve: el resultado de eliminar los �ltimos separadores de 
		// "cadena"
		/*********************************************************************/
		string EliminaPrimerosSeparadores (string cadena)
		{
			// Buscar el primer car�cter no espacio
			unsigned int pos = 0;
			while (pos < cadena.length() && isspace(cadena.at(pos))) pos++;
			
			string local;
			
			// Copiar todos los que quedan
			while (pos < cadena.length()) {
				local.push_back(cadena.at(pos));
				pos++;
			}
			
			return (local);
		}
		
		/*********************************************************************/
		// Devuelve una NUEVA cadena, resultante de eliminar los primeros 
		// �ltimos caracteres separadores de "cadena". Los caracteres 
		// separadores son el espacio en blanco, el tabulador y el salto de
		// l�nea
		//
		// Recibe: cadena, string sobre la que se va a trabajar.
		// Devuelve: el resultado de eliminar los primeros y los �ltimos
		//           separadores de "cadena".
		/*********************************************************************/
		
		string EliminaPrimerosYUltimosSeparadores (string cadena)
		{
			string cadena_podada = EliminaPrimerosSeparadores (cadena);
			cadena_podada = EliminaUltimosSeparadores (cadena_podada);
			
			return (cadena_podada);
		}
		
		/*********************************************************************/
		// Devuelve "true" si "cadena" es la representaci�n textual de un
		// entero
		//
		// Recibe: cadena, string sobre la que se va a trabajar.
		// Devuelve: "true" si "cadena" es la representaci�n textual de un int
		
		bool EsEntero (string cadena)
		{
			bool es_entero = true;
			
			cadena = EliminaPrimerosSeparadores (cadena);
			cadena = EliminaUltimosSeparadores (cadena);
			
			unsigned int long_cadena = cadena.length();
			
			if (long_cadena == 0) es_entero = false;
			else {
				
				// Si el primer car�cter es '+' � '-', perfecto. En ese caso
				// se pasa al siguiente car�cter (posici�n 19.
				
				unsigned int pos;
				if (cadena.at(0)=='-' || cadena.at(0) == '+') pos = 1;
				else pos = 0;
				
				while ((pos < long_cadena) && es_entero) {
					if(!isdigit(cadena.at(pos))) es_entero = false;
					else pos++;
				}
			}
			
			return (es_entero);
		}
		
		/*********************************************************************/

		bool EsReal (string cadena)
		{
			bool es_real = true;
			
			cadena = EliminaPrimerosSeparadores (cadena);
			cadena = EliminaUltimosSeparadores (cadena);
			
			unsigned int long_cadena = cadena.length();
			
			if (long_cadena == 0) es_real = false;
			else {
				
				// Si el primer car�cter es '+' � '-', perfecto. En ese caso
				// se pasa al siguiente car�cter (posici�n 19.
				
				unsigned int pos;
				if (cadena.at(0)=='-' || cadena.at(0) == '+') pos = 1;
				else pos = 0;
				
				// Bandera que se activa al encontrar un punto
				bool encontrado_un_punto = false;
				
				while ((pos < long_cadena) && es_real) {
					
					char c = cadena.at(pos);
					
					if (!isdigit(c)) {
						
						// Solo puede haber un punto.
						// Si se ha encontrado un punto y ya se hab�a
						// encontrado otro, error. Si no, activar la bandera
						// "encontrado_un_punto" (ya no puede haber m�s).
						
						if (c == '.') {
							if (encontrado_un_punto) es_real = false;
							else encontrado_un_punto = true;
						}
						
					    // Si no es un punto ni un d�gito --> error
						else es_real = false;
					}
					
					pos++;
					
				}  // while ((pos < long_cadena) && es_real)
				
			}  // else de if (long_cadena == 0)
			
			return (es_real);
		}
};

/////////////////////////////////////////////////////////////////////////////

/***************************************************************************/
/*
	Una sencilla aplicaci�n: programa que solicita un precio ("Dinero") y a
	continuaci�n un incremento mensual ("Dinero").
	Muestra una tabla indicando c�mo aumenta el precio inicial durante un 
	n�mero de meses dado de acuerdo al incremento indicado.
*/

int main()
{	
	cout.setf(ios::fixed);		// Notaci�n de punto fijo para los reales
	cout.setf(ios::showpoint);	// Mostrar siempre decimales 
	
	Lector lector;
	int euros, euros1;
	int centimos, centimos1;
	double cantidad;

	cout << "M�TODO 1: Incrementa (Dinero cantidad)" << endl << endl;
	
	
	lector.SetTitulo("Introduzca los euros: ");
	euros = lector.LeeEnteroMayorOIgual(0);
	lector.SetTitulo("Introduzca los c�ntimos: ");
	centimos = lector.LeeEnteroMayorOIgual(0);
	
	lector.SetTitulo("Introduzca los euros a incrementar: ");
	euros1 = lector.LeeEnteroMayorOIgual(0);
	lector.SetTitulo("Introduzca los c�ntimos a incrementar: ");
	centimos1 = lector.LeeRealMayorOIgual(0);
	
	Dinero a_trabajar (euros, centimos); // Este ser� el objeto sobre el que 
	                                     // ejecutaremos todos los m�todos
	                                     
	Dinero a_incrementar (euros1, centimos1);
	                   
	Dinero resultado (a_trabajar.Incrementa (a_incrementar));
	
	// Salida de resultados
	
	cout << "El resultado final tras incrementar es: " << resultado.ToString() 
	<< endl << endl;
	
	/***********************************************************************/
	
	cout << "M�TODO 2: Decrementa (Dinero cantidad)" << endl << endl;
	
	lector.SetTitulo("Introduzca los euros a decrementar: ");
	euros1 = lector.LeeEnteroMayorOIgual(0);
	lector.SetTitulo("Introduzca los c�ntimos a decrementar: ");
	centimos1 = lector.LeeRealMayorOIgual(0);
	
	Dinero a_decrementar (euros1, centimos1);
	
	Dinero resultado1 (a_trabajar.Decrementa (a_decrementar));
	
	// Salida de resultados
	
	cout << "El resultado final tras decrementar es: " << resultado1.ToString() 
	<< endl << endl;
	
	/***********************************************************************/
	
	cout << "M�TODO 3: Decrementa (double cantidad)" << endl << endl;
	
	lector.SetTitulo("Introduzca la cantidad a decrementar: ");
	cantidad = lector.LeeRealMayorOIgual(0);
	
	Dinero resultado2 (a_trabajar.Decrementa (cantidad));
	
	// Salida de resultados
	
	cout << "El resultado final tras decrementar es: " << resultado2.ToString() 
	<< endl << endl;
	
	/***********************************************************************/
	
	cout << "M�TODO 4: Modifica (double cantidad)" << endl << endl;
	
	cout << "Si introduce una cantidad real positiva, se sumar� dicha "
	<< "cantidad. Si es negativa, se sustraer�" << endl;
	
	lector.SetTitulo("Introduzca la cantidad: ");
	cantidad = lector.LeeReal();
	
	Dinero resultado3 (a_trabajar.Modifica (cantidad));
	
	// Salida de resultados
	
	cout << resultado3.ToString() << endl << endl;
	
	/***********************************************************************/
	
	cout << "M�TODO 5: EsMayor (Dinero otro)" << endl << endl;
	
	lector.SetTitulo("Introduzca los euros a comparar: ");
	euros1 = lector.LeeEnteroMayorOIgual(0);
	lector.SetTitulo("Introduzca los c�ntimos a comparar: ");
	centimos1 = lector.LeeEnteroMayorOIgual(0);
	
	Dinero a_comparar (euros1, centimos1);
	
	bool es_mayor = a_trabajar.EsMayor(a_comparar);
	
	if (es_mayor)
		cout << "La cantidad inicial es mayor que la introducida";
		
	else
		cout << "La cantidad inicial no es mayor que la introducida";
	
	cout << endl << endl;
	
	/***********************************************************************/
	
	cout << "M�TODO 6: EsMayor (double cantidad)" << endl << endl;
	
	lector.SetTitulo("Introduzca la cantidad a comparar: ");
	cantidad = lector.LeeRealMayorOIgual(0);
	
	bool es_mayor1 = a_trabajar.EsMayor(cantidad);
	
	if (es_mayor1)
		cout << "La cantidad inicial es mayor que la introducida";
		
	else
		cout << "La cantidad inicial no es mayor que la introducida";
		
	cout << endl << endl;
	
	/***********************************************************************/
		
	cout << "M�TODO 7: EsMenor (Dinero otro)" << endl << endl;
	
	lector.SetTitulo("Introduzca los euros a comparar: ");
	euros1 = lector.LeeEnteroMayorOIgual(0);
	lector.SetTitulo("Introduzca los c�ntimos a comparar: ");
	centimos1 = lector.LeeEnteroMayorOIgual(0);
	
	Dinero a_comparar1 (euros1, centimos1);
	
	bool es_menor = a_trabajar.EsMenor(a_comparar1);
	
	if (es_menor)
		cout << "La cantidad inicial es menor que la introducida";
		
	else
		cout << "La cantidad inicial no es menor que la introducida";
	
	cout << endl << endl;
	
	/***********************************************************************/
	
	cout << "M�TODO 8: EsMenor (double cantidad)" << endl << endl;
	
	lector.SetTitulo("Introduzca la cantidad a comparar: ");
	cantidad = lector.LeeRealMayorOIgual(0);
	
	bool es_menor1 = a_trabajar.EsMenor(cantidad);
	
	if (es_menor1)
		cout << "La cantidad inicial es menor que la introducida";
		
	else
		cout << "La cantidad inicial no es menor que la introducida";
		
	cout << endl << endl;
	
	/***********************************************************************/
	
	cout << "M�TODO 9: EsIgual (Dinero otro)" << endl << endl;
	
	lector.SetTitulo("Introduzca los euros a comparar: ");
	euros1 = lector.LeeEnteroMayorOIgual(0);
	lector.SetTitulo("Introduzca los c�ntimos a comparar: ");
	centimos1 = lector.LeeEnteroMayorOIgual(0);
	
	Dinero a_comparar2 (euros1, centimos1);
	
	bool es_igual = a_trabajar.EsIgual(a_comparar2);
	
	if (es_igual)
		cout << "La cantidad inicial es igual a la introducida";
		
	else
		cout << "La cantidad inicial no es igual a la introducida";
	
	cout << endl << endl;
	
	/***********************************************************************/
	
	cout << "M�TODO 10: EsIgual (double cantidad)" << endl << endl;
	
	lector.SetTitulo("Introduzca la cantidad a comparar: ");
	cantidad = lector.LeeRealMayorOIgual(0);
	
	bool es_igual1 = a_trabajar.EsIgual(cantidad);
	
	if (es_igual1)
		cout << "La cantidad inicial es igual a la introducida";
		
	else
		cout << "La cantidad inicial no es igual a la introducida";
		
	cout << endl << endl;
	
	/***********************************************************************/
	
	cout << "M�TODO 11: Diferencia (Dinero otro)" << endl << endl;
	
	cout << "La diferencia solo ser� efectuada cuando la cantidad introducida "
	<< "sea menor o igual que la inicial" << endl;
	
	lector.SetTitulo("Introduzca los euros: ");
	euros1 = lector.LeeEnteroMayorOIgual(0);
	lector.SetTitulo("Introduzca los c�ntimos: ");
	centimos1 = lector.LeeEnteroMayorOIgual(0);
	
	Dinero a_comparar3 (euros1, centimos1);
	
	bool es_mayor_o_igual = (a_trabajar.EsMayor(a_comparar3) || 
	                         a_trabajar.EsIgual(a_comparar3));
	                         
	Dinero diferencia;
	                         
	if (es_mayor_o_igual){
		
		diferencia = a_trabajar.Diferencia(a_comparar3);
		
		cout << "La diferencia entre la cantidad inicial y la introducida es "
		<< "de: " << diferencia.ToString();
	}
	
	else{
		
		cout << "La cantidad introducida es mayor que la inicial, por lo que"
		<< " la diferencia no puede ser efectuada";
	}
	
	cout << endl << endl;
	
	/***********************************************************************/
	
	cout << "M�TODO 12: Diferencia (double otro)" << endl << endl;
	
	cout << "La diferencia solo ser� efectuada cuando la cantidad introducida "
	<< "sea menor o igual que la inicial" << endl;
	
	lector.SetTitulo("Introduzca la cantidad: ");
	cantidad = lector.LeeRealMayorOIgual(0);
	
	bool es_mayor_o_igual1 = (a_trabajar.EsMayor(cantidad) || 
	                         a_trabajar.EsIgual(cantidad));
	                         
	Dinero diferencia1;
	                         
	if (es_mayor_o_igual1){
		
		diferencia1 = a_trabajar.Diferencia(cantidad);
		
		cout << "La diferencia entre la cantidad inicial y la introducida es "
		<< "de: " << diferencia1.ToString();
	}
	
	else{
		
		cout << "La cantidad introducida es mayor que la inicial, por lo que"
		<< " la diferencia no puede ser efectuada";
	}

	return 0;
}
