/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/*
Programa que solicita al usuario puntos del plano XY (los cuales almacena en un
objeto de la clase ColeccionPuntos2D) y los datos caracter�sticos de una
circunferencia (su centro y su radio) con el fin de determinar los puntos
que pertenecen a dicha circunferencia de entre los que se han introducido.

Para ello he implementado la clase ColeccionPuntos2D, la cual es muy similar
a otras que se han hecho como SecuenciaCaracteres. Dicha clase viene m�s
abajo explicada en el c�digo con sus respectivos m�todos.
*/
/*****************************************************************************/

#include <iostream>
#include <string>
#include <cmath>

using namespace std;

/////////////////////////////////////////////////////////////////////////////

class Punto2D
{
private:
	
	// La pareja (x,y) son las coordenadas de un punto en un espacio 2D
	double x;
	double y;

public:
	
	/***********************************************************************/
	
	Punto2D (void) :
		x(0), y(0)
	{}
	
	/***********************************************************************/
	// Constructor con argumentos.
	//
	// Recibe: abscisaPunto y ordenadaPunto, la abscisa y ordenada, 
	// respectivamente del punto que se est� creando.
	
	Punto2D (double abscisaPunto, double ordenadaPunto)
	{
		SetCoordenadas (abscisaPunto, ordenadaPunto);
	}

	/***********************************************************************/
	// M�todo Set para fijar simultaneamente las coordenadas. 
	//
	// Recibe: abscisaPunto y ordenadaPunto, la abscisa y ordenada, 
	// respectivamente del punto que se est� modificando.
	
	void SetCoordenadas (double abscisaPunto, double ordenadaPunto)
	{
		x = abscisaPunto;
		y = ordenadaPunto;
	}

	/***********************************************************************/
	// M�todos Get para leer las coordenadas

	double GetX (void)
	{
		return (x);
	}
	double GetY (void)
	{
		return (y);
	}

	/***********************************************************************/
	// Calcula la distancia Eucl�dea del punto (objeto impl�cito) a otro que 
	// se recibe como argumento. 
	//
	// Recibe: otro, el punto respecto al cual que se quiere calcular la 
	// distancia eucl�dea.
	// Devuelve: la distancia entre los dos puntos. 

	double DistanciaEuclidea (Punto2D otro)
	{
		double dif_x = pow (x - otro.x, 2);
		double dif_y = pow (y - otro.y, 2);

		return (sqrt(dif_x + dif_y));
	}

	/***********************************************************************/

	string ToString ()
	{
		return ("["+to_string(x)+", "+to_string(y)+"]");
	}
	
	/***********************************************************************/

};

/////////////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////////////
// La clase "Circunferencia" representa circunferencias, objetos geom�tricos 
// que verifican la propiedad de que los puntos (x,y) que la forman est�n a 
// la misma distancia de otro punto (el centro).

class Circunferencia
{
private:

	// La constante "PI" es com�n a todos los objetos de la clase.
	static const double PI;		
	
	// Centro de la circunferencia
	Punto2D centro;	
	
	// Longitud del radio
	// PRE: radio >= 0
	double  radio;	

public:

	/***********************************************************************/
	// Constructor con argumentos
	// Recibe:
	//		el_centro, el punto central de la circunferencia. 
	//		radio, el valor del radio.
	// PRE: radio >= 0

	Circunferencia (Punto2D el_centro, double el_radio) : centro (el_centro)
	{
		// Observad c�mo se ha iniciado "centro": como es de clase "Punto2D"
		// se ha empleado la lista de iniciaci�n para que act�e el constructor
		// de la clase "Punto2D" 
		 
		radio  = el_radio; 
	}

	/***********************************************************************/
	// M�todos Get
	
	// Devuelve el punto central de la circunferencia
	Punto2D GetCentro (void)
	{
		return (centro);
	}

	// Devuelve el radio de la circunferencia
	double GetRadio (void)
	{
		return (radio);
	}

	// Devuelve el di�metro de la circunferencia
	double GetDiametro (void)
	{
		return (radio*2);
	}

	/***********************************************************************/
	// Calcula la longitud de la circunferencia

	double Longitud (void)
	{
		return (2.0 * PI * radio);
	}

	/***********************************************************************/
	// Calcula el �rea del c�rculo
	
	double Area (void)
	{
		return (PI * radio * radio);
	}

	/***********************************************************************/
	// Calcular si la circunferencia contiene a un punto dado.
	//
	// Recibe: un_punto, el punto del que se quiere evaluar su pertenencia. 
	/*
		Un punto (x, y) est� dentro de una circunferencia con 
		centro (x_0, y_0) y radio r si se verifica que:
			(x-0 - x)^2 + (y_0 - y)^2 <= r^2
	*/
	/*
	bool Contiene (Punto2D un_punto)
	{
		double dif_x = pow (centro.GetX() - un_punto.GetX(), 2);
		double dif_y = pow (centro.GetY() - un_punto.GetY(), 2);
		return (dif_x + dif_y <= radio*radio);
	}
	*/
	/***********************************************************************/
	// Calcular si la circunferencia contiene a un punto dado usando un 
	// test expl�cito sobre la distancia Eucl�dea del centro de la 
	// circunferencia al punto.
	//
	// Recibe: un_punto, el punto del que se quiere evaluar su pertenencia. 
	/*
		Un punto P(x, y) est� dentro de una circunferencia con centro 
		C(x_0, y_0) y radio r si DistaciaEuclidea (P, C) <= r
	*/
	// Esta implementaci�n es preferible a la anterior ya que no requiere 
	// duplicar (aunque sea de manera indiirecta) el c�digo referido al 
	// c�lculo de la distancia entre dos puntos. 
	
	bool Contiene (Punto2D un_punto)
	{
		Punto2D el_centro = GetCentro();
		double distancia = el_centro.DistanciaEuclidea (un_punto);
		return (distancia <= radio);
	}
	
	/***********************************************************************/
	
	string ToString (void)
	{
		string cadena;
		
		cadena = "Centro: " + centro.ToString() + " Radio = " 
		+ to_string(radio);
		
		return(cadena);
	}

	/***********************************************************************/
};

const double Circunferencia :: PI = 3.1415926;

/////////////////////////////////////////////////////////////////////////////

class ColeccionPuntos2D{
	
	private:
		static const int TAMANIO = 300;
		
		Punto2D puntos[TAMANIO];
		int total_utilizados;        // PRE: 0 < total_utilizados< TAMANIO
		
	public:
		
		/*********************************************************/
		//Constructor sin argumentos
		
		ColeccionPuntos2D(void):
			total_utilizados(0)
		{}
		
		/*********************************************************/
		// Devuelve el n�mero de casillas ocupadas
		
		int TotalUtilizados (void)
		{
			return(total_utilizados);
		}
		
		/*********************************************************/
		// Devuelve el n�mero de casillas disponibles
		
		int Capacidad (void)
		{
			return(TAMANIO);
		}
		
		/*********************************************************/
		/*********************************************************/
		// "Vac�a" completamente la secuencia
		
		void EliminaTodos (void)
		{
			total_utilizados = 0;
		}
		
		/*********************************************************/
		// A�ade un elemento ("nuevo") al vector.
		// PRE: puntos < TAMANIO
		// La adici�n se realiza si hay alguna casilla disponible.
		// El nuevo elemento se coloca al final del vector.
		// Si no hay espacio, no se hace nada.
		
		void Aniade (Punto2D nuevo)
		{
			if (total_utilizados < TAMANIO){
				puntos[total_utilizados] = nuevo;
				total_utilizados++;
			}
		}
		
		/*********************************************************/
		// Devuelve el elemento de la casilla "indice"
		// PRE: 0 <= indice < vector_alumnos
		
		Punto2D Elemento (int indice)
		{
			return(puntos[indice]);
		}
		
		/*********************************************************/
		// Cambia el contenido de la casilla "indice" por el valor
		// dado en "nuevo". El tama�o de la secuencia no cambia.
		// PRE: 0 <= indice < total_utilizados
		
		void Modifica (int indice, Punto2D nuevo)
		{
			if ((indice >= 0) && (indice < total_utilizados)) 
				puntos[indice] = nuevo;
		}
		
		/*********************************************************/
		/*********************************************************/
		// Eliminar el car�cter de la posici�n dada por "indice".
		// Realiza un borrado f�sico (desplazamiento y sustituci�n).
		// PRE: 0 <= indice < total_utilizados
		
		void Elimina (int indice)
		{
			if ((indice >= 0) && (indice < total_utilizados)) {
				int tope = total_utilizados-1; // posic. del �ltimo
				for (int i = indice ; i < tope ; i++)
					puntos[i] = puntos[i+1];
				total_utilizados--;
			}
		}
		
		/*********************************************************/
		// Inserta el punto "nuevo" en la posici�n dada por "indice".
		// Desplaza todos los puntos una posici�n a la derecha
		// antes de copiar en "indice" en valor "nuevo".
		// PRE: 0 <= indice < total_utilizados
		
		void Inserta (int indice, Punto2D nuevo)
		{
			if ((total_utilizados < TAMANIO) && (indice >= 0)
					&& (indice < total_utilizados)) 
			{
				for (int i = total_utilizados ; i > indice ; i--)
					puntos[i] = puntos[i-1];
				
				puntos[indice] = nuevo;
				total_utilizados++;
			}
		}
		
		/*********************************************************/
		// M�todo que compone una cadena que muestra todos los puntos
		// que forman parte del objeto de la clase ColeccionPuntos2D
		// sobre el que se ejecuta el m�todo
		
		string ToString (void)
		{
			string cadena;
			
			for(int i = 0; i < total_utilizados; i++){
				
				cadena += "Punto " + to_string(i+1) + ": " 
				+ puntos[i].ToString() + "\n";
			}
			
			return(cadena);
		}
};

//////////////////////////////////////////////////////////////////////////////

class Lector
{
	private:
		
		string titulo;
	
	public:
		
		// Constructor sin argumentos
		
		Lector (void) : titulo ("")
		{ }
		
		// Constructor con argumentos
		
		Lector (string cad) : titulo (cad)
		{ }
		
		// M�todo Set para fijar el campo "titulo"
		
		void SetTitulo (string cad)
		{
			titulo = cad;
		}
		
		/*********************************************************************/
		// Lee un dato int.
		// La lectura est� etiquetada con "titulo"
		// La lectura se efect�a repetidamente hasta que se introduce un valor
		// int correcto.
		
		int LeeEntero (void)
		{
			string cadena;
			
			do{
				cout << titulo;
				getline(cin, cadena);
			}
			while (!EsEntero(cadena));
			
			return (stoi(cadena));
		}
		
		/*********************************************************************/
		// Lee un dato int.
		// La lectura est� etiquetada con "titulo"
		// PRE: menor <= mayor
		// POST: menor <= valor devuelto <= mayor
		
		int LeeEnteroEnRango (int menor, int mayor)
		{
			int numero;
			
			do{
				
				numero = LeeEntero ();
			}
			while ((numero<menor) || (numero>mayor));
			
			return (numero);
		}
		
		/*********************************************************************/
		// Lee un dato int que debe ser mayor o igual que "menor" y lo devuelve.
		// La lectura est� etiquetada con "titulo"
		
		int LeeEnteroMayorOIgual (int menor)
		{
			int numero;
			
			do{
				numero = LeeEntero ();
			}
			while (numero < menor);
			
			return (numero);
		}
		
		/*********************************************************************/
		// Lee un dato double.
		// La lectura est� etiquetada con "titulo"
		// La lectura se efect�a repetidamente hasta que se introduce un valor
		// double correcto.
		
		double LeeReal (void)
		{
			string cadena;
			
			do{
				cout << titulo;
				getline(cin, cadena);
			}
			while (!EsReal(cadena));
			
			return (stod(cadena));
		}
		
		/*********************************************************************/
		// Lee un dato double.
		// La lectura est� etiquetada con "titulo"
		// PRE: menor <= mayor
		// POST: menor <= valor devuelto <= mayor
		
		double LeeRealEnRango (int menor, int mayor)
		{
			double numero;
			
			do{
				
				numero = LeeReal ();
			}
			while ((numero<menor) || (numero>mayor));
			
			return (numero);
		}

		/*********************************************************************/
		// Lee un dato double que debe ser mayor o igual que "menor" y lo 
		// devuelve. 
		// La lectura est� etiquetada con "titulo"
		
		double LeeRealMayorOIgual (int menor)
		{
			double numero;
			
			do{
				numero = LeeReal ();
			}
			while (numero < menor);
			
			return (numero);
		}

		/*********************************************************************/
		
		bool EsReal (string cadena)
		{
			bool es_real = true;
			
			cadena = EliminaPrimerosSeparadores (cadena);
			cadena = EliminaUltimosSeparadores (cadena);
			
			unsigned int long_cadena = cadena.length();
			
			if (long_cadena == 0) es_real = false;
			else {
				
				// Si el primer car�cter es '+' � '-', perfecto. En ese caso
				// se pasa al siguiente car�cter (posici�n 19.
				
				unsigned int pos;
				if (cadena.at(0)=='-' || cadena.at(0) == '+') pos = 1;
				else pos = 0;
				
				// Bandera que se activa al encontrar un punto
				bool encontrado_un_punto = false;
				
				while ((pos < long_cadena) && es_real) {
					
					char c = cadena.at(pos);
					
					if (!isdigit(c)) {
						
						// Solo puede haber un punto.
						// Si se ha encontrado un punto y ya se hab�a
						// encontrado otro, error. Si no, activar la bandera
						// "encontrado_un_punto" (ya no puede haber m�s).
						
						if (c == '.') {
							if (encontrado_un_punto) es_real = false;
							else encontrado_un_punto = true;
						}
						
					    // Si no es un punto ni un d�gito --> error
						else es_real = false;
					}
					
					pos++;
					
				}  // while ((pos < long_cadena) && es_real)
				
			}  // else de if (long_cadena == 0)
			
			return (es_real);
		}
	
	private:
		
		/*********************************************************************/
		// Devuelve una NUEVA cadena, resultante de eliminar los �ltimos
		// caracteres separadores de "cadena". Los caracteres separadores son
		// el espacio en blanco, el tabulador y el salto de l�nea.
		// Usaremos la funci�n isspace() para simplificar el c�lculo.
		//
		// Recibe: cadena, string sobre la que se va a trabajar.
		// Devuelve: el resultado de eliminar los �ltimos separadores de 
		// "cadena"
		/*********************************************************************/
		
		string EliminaUltimosSeparadores (string cadena)
		{
			while (cadena.length()>0 && isspace(cadena.back()))
				cadena.pop_back();
			
			return (cadena);
		}
		
		/*********************************************************************/
		// Devuelve una NUEVA cadena, resultante de eliminar los primeros
		// caracteres separadores de "cadena". Los caracteres separadores son
		// el espacio en blanco, el tabulador y el salto de l�nea.
		// Usaremos la funci�n isspace() para simplificar el c�lculo.
		//
		// Recibe: cadena, string sobre la que se va a trabajar.
		// Devuelve: el resultado de eliminar los �ltimos separadores de 
		// "cadena"
		/*********************************************************************/
		string EliminaPrimerosSeparadores (string cadena)
		{
			// Buscar el primer car�cter no espacio
			unsigned int pos = 0;
			while (pos < cadena.length() && isspace(cadena.at(pos))) pos++;
			
			string local;
			
			// Copiar todos los que quedan
			while (pos < cadena.length()) {
				local.push_back(cadena.at(pos));
				pos++;
			}
			
			return (local);
		}
		
		/*********************************************************************/
		// Devuelve una NUEVA cadena, resultante de eliminar los primeros 
		// �ltimos caracteres separadores de "cadena". Los caracteres 
		// separadores son el espacio en blanco, el tabulador y el salto de
		// l�nea
		//
		// Recibe: cadena, string sobre la que se va a trabajar.
		// Devuelve: el resultado de eliminar los primeros y los �ltimos
		//           separadores de "cadena".
		/*********************************************************************/
		
		string EliminaPrimerosYUltimosSeparadores (string cadena)
		{
			string cadena_podada = EliminaPrimerosSeparadores (cadena);
			cadena_podada = EliminaUltimosSeparadores (cadena_podada);
			
			return (cadena_podada);
		}
		
		/*********************************************************************/
		// Devuelve "true" si "cadena" es la representaci�n textual de un
		// entero
		//
		// Recibe: cadena, string sobre la que se va a trabajar.
		// Devuelve: "true" si "cadena" es la representaci�n textual de un int
		
		bool EsEntero (string cadena)
		{
			bool es_entero = true;
			
			cadena = EliminaPrimerosSeparadores (cadena);
			cadena = EliminaUltimosSeparadores (cadena);
			
			unsigned int long_cadena = cadena.length();
			
			if (long_cadena == 0) es_entero = false;
			else {
				
				// Si el primer car�cter es '+' � '-', perfecto. En ese caso
				// se pasa al siguiente car�cter (posici�n 19.
				
				unsigned int pos;
				if (cadena.at(0)=='-' || cadena.at(0) == '+') pos = 1;
				else pos = 0;
				
				while ((pos < long_cadena) && es_entero) {
					if(!isdigit(cadena.at(pos))) es_entero = false;
					else pos++;
				}
			}
			
			return (es_entero);
		}
};

//////////////////////////////////////////////////////////////////////////////

int main() // Programa principal
{
	string TERMINADOR = "FIN";
	string cadena;
	double abscisa;
	double ordenada;
	Punto2D punto;
	double radio;
	
	ColeccionPuntos2D coleccion;
	Lector lector;
	
	// Entrada de datos
	
	bool sigo = true;
	
	while ((coleccion.TotalUtilizados() < coleccion.Capacidad()) && sigo){
		
		cout << "Introduzca la abscisa del punto: ";
		getline(cin, cadena);
		
		if (cadena != TERMINADOR){
			
			if (lector.EsReal(cadena))
				abscisa = stod(cadena);
			
			else{
				
				lector.SetTitulo("Vuelva a introducir la abscisa: ");
				abscisa = lector.LeeReal();
			}
			
			lector.SetTitulo("Introduzca la ordenada del punto: ");
			ordenada = lector.LeeReal();
			
			punto.SetCoordenadas(abscisa, ordenada);
			coleccion.Aniade(punto);
			
			cout << endl;
			cout << "Introduzca los datos de otro punto: ";
			cout << endl;
		}
		
		else
			sigo = false;
	}
	
	
	cout << "La colecci�n de puntos introducida es: " << endl << endl;
	cout << coleccion.ToString();
	cout << endl;
	
	// Creaci�n del objeto de la clase Circunferencia
	
	cout << "DATOS DE LA CIRCUNFERENCIA" << endl << endl;
	
	lector.SetTitulo("Introduzca la abscisa del centro: ");
	abscisa = lector.LeeReal();
	
	lector.SetTitulo("Introduzca la ordenada del centro: ");
	ordenada = lector.LeeReal();
	
	punto.SetCoordenadas(abscisa, ordenada);
	
	lector.SetTitulo("Introduzca el radio: ");
	radio = lector.LeeRealMayorOIgual(0.01);
	
	Circunferencia c (punto, radio);
	
	// Creaci�n de la colecci�n de puntos contenidos en la circunferencia
	
	ColeccionPuntos2D contenidos;
	
	for (int i = 0; i < coleccion.TotalUtilizados(); i++){
				
		if (c.Contiene(coleccion.Elemento(i)))
			contenidos.Aniade(coleccion.Elemento(i));
	}
			
	
	// Salida de resultados
	
	cout << endl;
	cout << "La circunferencia caracterizada por: " << endl;
	cout << c.ToString() << endl;
	cout << "contiene a los siguientes puntos de la colecci�n introducida: ";
	
	cout << endl << endl;
	
	cout << contenidos.ToString();
	
	return 0;
}
