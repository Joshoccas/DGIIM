/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Programa que dado un rect�ngulo, calcula su �rea, per�metro y los tri�ngulos
inferior a su diagonal principal y superior a su otra diagonal. Tambi�n
determina si algunos puntos est�n contenidos en dicho rect�ngulo o no.

En cuanto a objetos de la clase Triangulo, dado un tri�ngulo se halla su 
per�metro, y se determina si es un tri�ngulo rect�ngulo o no.

Para poder llevar a cabo esas tareas he creado las clases Triangulo y
Rectangulo y he creado un m�todo para cada una de las tareas mencionadas
anteriormente. Los m�todos creados est�n comentados m�s abajo en el 
c�digo.
*/
/*****************************************************************************/

#include <iostream>
#include <string>
#include <cmath>

using namespace std;

class Punto2D
{
	private:
		
		// La pareja (x,y) son las coordenadas de un punto en un espacio 2D
		double x;
		double y;

	public:
	
		/********************************************************************/
		// Constructor con argumentos.
		//
		// Recibe: abscisaPunto y ordenadaPunto, la abscisa y ordenada, 
		// respectivamente del punto que se est� creando.
	
		Punto2D (double abscisaPunto, double ordenadaPunto)
		{
			SetCoordenadas (abscisaPunto, ordenadaPunto);
		}

		/********************************************************************/
		// M�todo Set para fijar simultaneamente las coordenadas. 
		//
		// Recibe: abscisaPunto y ordenadaPunto, la abscisa y ordenada, 
		// respectivamente del punto que se est� modificando.
	
		void SetCoordenadas (double abscisaPunto, double ordenadaPunto)
		{
			x = abscisaPunto;
			y = ordenadaPunto;
		}

		/********************************************************************/
		// M�todos Get para leer las coordenadas

		double GetX (void)
		{
			return (x);
		}
		double GetY (void)
		{
			return (y);
		}

		/********************************************************************/
		// Calcula si dos puntos son iguales 
		//
		// Recibe: otro, el punto que se quiere comparar con el objeto impl�cito 
		// Devuelve: true, si se consideran iguales los dos objetos. 

		bool EsIgual (Punto2D otro)
		{
			return (SonIguales(x,otro.x) && SonIguales(y,otro.y));
		}
	
		/********************************************************************/
	
		bool SonIguales (double coordenada1, double coordenada2)
		{
			bool son_iguales = (coordenada1 == coordenada2);
		
			return(son_iguales);
		}

		/********************************************************************/
		// Calcula la distancia Eucl�dea del punto (objeto impl�cito) a otro que 
		// se recibe como argumento. 
		//
		// Recibe: otro, el punto respecto al cual que se quiere calcular la 
		// distancia eucl�dea.
		// Devuelve: la distancia entre los dos puntos. 

		double DistanciaEuclidea (Punto2D otro)
		{
			double dif_x = pow (x - otro.x, 2);
			double dif_y = pow (y - otro.y, 2);

			return (sqrt(dif_x + dif_y));
		}

		/********************************************************************/

		string ToString ()
		{
			return ("["+to_string(x)+", "+to_string(y)+"]");
		}
	
		/********************************************************************/

};

/////////////////////////////////////////////////////////////////////////////

class Triangulo 
{
	private:
		
		Punto2D v1;
		Punto2D v2;
		Punto2D v3;
	
	public:
		
		// Constructor con argumentos
		// PRE: Los v�rtices tienen que ser puntos distintos entre s�
		
		Triangulo (Punto2D punto1, Punto2D punto2, Punto2D punto3) :
			v1 (punto1), v2 (punto2), v3 (punto3)
		{}
		
		/********************************************************************/
		// M�todo que calcula el per�metro de un objeto de la clase Triangulo
		// Devuelve: per�metro del tri�ngulo
		
		double Perimetro (void)
		{
			double longitud1;
			double longitud2;
			double longitud3;
			double perimetro;
			
			// Se hace uso del m�todo DistanciaEuclidea de la clase Punto2D
			// para hallar la longitud de los lados determinados por cada par
			// de v�rtices
			
			longitud1 = v1.DistanciaEuclidea(v2);
			
			longitud2 = v1.DistanciaEuclidea(v3);
			
			longitud3 = v2.DistanciaEuclidea(v3);
			
			perimetro = longitud1 + longitud2 + longitud3;
			
			return(perimetro);
		}
		
		/********************************************************************/
		// M�todo que determina si un objeto de la clase Triangulo es 
		// rect�ngulo
		// Devuelve: bool es_rectangulo (ser� true solo cuando se cumpla
		// el Th.Pitagoras en alg�n caso)
		
		bool EsRectangulo (void)
		{
			double lado1;
			double lado2;
			double lado3;
			bool es_rectangulo;
			
			// Se hace uso del m�todo DistanciaEuclidea de la clase Punto2D
			// para hallar la longitud de los lados determinados por cada par
			// de v�rtices
			
			lado1 = v1.DistanciaEuclidea(v2);
			
			lado2 = v1.DistanciaEuclidea(v3);
			
			lado3 = v2.DistanciaEuclidea(v3);
			
			// El tri�ngulo ser� rect�ngulo si se cumple el teorema de 
			// Pit�goras para alguno de los lados con respecto de los
			// otros dos
			
			es_rectangulo =
			((lado1*lado1 == lado2*lado2 + lado3*lado3) ||
			(lado2*lado2 == lado1*lado1 + lado3*lado3) ||
			(lado3*lado3 == lado1*lado1 + lado2*lado2));
			
			return(es_rectangulo);
		}
		
		/********************************************************************/
		// M�todo que devuelve una cadena que muestra los tres v�rtices del 
		// objeto de la clase Triangulo sobre el que se ejecuta
		// Devuelve: string cad (presenta los datos miembro del objeto)
		
		string ToString (void)
		{
			string cad;
			
			cad = v1.ToString() + "," + v2.ToString() + "," + v3.ToString();
			
			return(cad);
		}
};

/////////////////////////////////////////////////////////////////////////////

class Rectangulo
{
	private:
		
		Punto2D sup_izq;
		double base;
		double altura;
	
	public:
		
		// Constructor con argumentos
		// PRE: longitud1 > 0 && longitud2 > 0
		
		Rectangulo (Punto2D punto, double longitud1, double longitud2) :
			sup_izq (punto), base (longitud1), altura (longitud2)
		{}
		
		/********************************************************************/
		// M�todo que calcula el �rea de un objeto de la clase Rectangulo
		// Devuelve: double ---> �rea del rect�ngulo
		
		double Area (void)
		{
			return(base*altura);
		}
		
		/********************************************************************/
		// M�todo que calcula el per�metro de un objeto de la clase Rectangulo
		// Devuelve: double ---> per�metro del rect�ngulo
		
		double Perimetro (void)
		{
			return(2*base + 2*altura);
		}
		
		/********************************************************************/
		// M�todo que determina si un objeto de la clase Rectangulo contiene
		// a un punto determinado
		// Devuelve: bool contiene (ser� true solo cuando el rect�ngulo 
		// contenga al punto)
		
		bool Contiene (Punto2D punto)
		{
			
			// Un punto cualquiera estar� contenido en un rect�ngulo si est�
			// entre el v�rtice superior izquierdo y  derecho (anchura)
			// y entre los v�rtices superior izquierdo e inferior izquierdo
			// (altura)
			
			bool contiene = 
			(((punto.GetX() >= sup_izq.GetX()) && 
			(punto.GetX() <= (sup_izq.GetX() + base))) &&
			((punto.GetY() <= sup_izq.GetY()) &&
			(punto.GetY() >= (sup_izq.GetY() - altura))));
			
			return(contiene);
		}
		
		/********************************************************************/
		// M�todo que construye un objeto de la clase Triangulo considerando
		// la diagonal principal del rect�ngulo. El tri�ngulo que se construye
		// es el inferior a dicha diagonal
		// Devuelve: un objeto de la clase Triangulo
		
		Triangulo TrianguloInferior (void)
		{
			Punto2D inf_izq (sup_izq.GetX(), sup_izq.GetY() - altura);
			Punto2D inf_der (sup_izq.GetX() + base, inf_izq.GetY());
			
			Triangulo t_inf (sup_izq, inf_izq, inf_der);
			
			return(t_inf);
		}
		
		/********************************************************************/
		// M�todo que construye un objeto de la clase Triangulo considerando
		// la diagonal no principal del rect�ngulo. El tri�ngulo que se
		// construye es el superior a dicha diagonal
		// Devuelve: un objeto de la clase Triangulo
		
		Triangulo TrianguloSuperior (void)
		{
			Punto2D inf_izq (sup_izq.GetX(), sup_izq.GetY() - altura);
			Punto2D sup_der (sup_izq.GetX() + base, sup_izq.GetY());
			
			Triangulo t_sup (sup_izq, inf_izq, sup_der);
			
			return(t_sup);
		}
		
		/********************************************************************/
		// M�todo que devuelve una cadena que muestra el v�rtice superior 
		// izquierdo del objeto de la clase Rectangulo, as� como su base y su 
		// altura 
		// Devuelve: string cad (presenta los datos miembro del objeto)
		
		string ToString (void)
		{
			string cad;
			
			cad = "Esquina superior izquierda: " + sup_izq.ToString() + "\n" 
			+ "Base = " + to_string(base) + "\n"
			+ "Altura = " + to_string(altura);
			
			return(cad);
		}
};

/////////////////////////////////////////////////////////////////////////////

int main (void)
{
    cout.setf(ios::fixed);        // Notaci�n de punto fijo para los reales
    cout.setf(ios::showpoint);    // Mostrar siempre decimales 


    // Crear un rect�ngulo
    Rectangulo r (Punto2D(10,8), 6, 2);

    cout << "Rectangulo:" << endl;
    cout << r.ToString() << endl;

    cout << "Area = " << r.Area() << endl;
    cout << "Perimetro = " << r.Perimetro() << endl;
    cout << endl << endl;
    
    // Pruebas de pertenencia a un rect�ngulo
    cout << "Pertenencia a Rectangulo: " << endl;    
    cout << (Punto2D(12,11).ToString()) << " --> " 
         << ((r.Contiene (Punto2D(12,11))) ? "SI":"NO") << endl; 
    cout << (Punto2D(9,8).ToString()) << " --> " 
         << ((r.Contiene (Punto2D(9,8))) ? "SI":"NO") << endl; 
    cout << (Punto2D(16,8).ToString()) << " --> " 
         << ((r.Contiene (Punto2D(16,8))) ? "SI":"NO") << endl; 
    cout << endl;
    
    
    // Crear un tri�ngulo
    Triangulo t (Punto2D(12,7), Punto2D(17,11), Punto2D(20,7));
    
    cout << "Triangulo:" << endl;
    cout << t.ToString() << endl;        
    cout << "Perimetro = " << t.Perimetro() << endl;    
    cout << endl << endl;    
    
    // Crear otro tri�ngulo    (rect�ngulo)
    Triangulo tr (Punto2D(10,3), Punto2D(10,6), Punto2D(16,6));

    cout << "Triangulo rectangulo:" << endl;    
    cout << tr.ToString() << endl;    
    cout << endl << endl;
    
    // Crear un tri�ngulo a partir de un rect�ngulo (tri�ngulo inferior) 
    Triangulo t_inf = r.TrianguloInferior();

    cout << "Triangulo inferior del rectangulo:" << endl;    
    cout << t_inf.ToString() << endl;    
    cout << endl << endl;
    
    // Crear otro tri�ngulo a partir de un rect�ngulo (tri�ngulo superior) 
    Triangulo t_sup = r.TrianguloSuperior();

    cout << "Triangulo superior del rectangulo:" << endl;    
    cout << t_sup.ToString() << endl;    
    cout << endl << endl; 
        
    return 0;
}
