/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/*
Programa que inserta una secuencia de caracteres en otra a partir de una 
posici�n determinada por el usuario. Ej:


         Introducimos: 'Las lentejas'
         Introducimos: 'Comer bien'
         Posici�n de inserci�n: 2
         El programa nos devolver�: 'LaComer biens lentejas'
         
He usado la clase SecuenciaCaracteres proporcionada por el profesor y en
ella he creado tres m�todos: 

1. void InsertaSecuenciaCaracteres(int pos_insercion,SecuenciaCaracteres otra)

     Este m�todo llama a su vez a 
	 void Inserta(int pos_insercion, char valor_nuevo), el cual inserta el 
	 caracter valor_nuevo en la pos_insercion.
	 
2. void InsertaSecuenciaCaracteres2 (int pos_insercion, SecuenciaCaracteres otr)

     Este m�todo es el mismo que el anterior pero no hace uso del m�todo 
	 Inserta.
    
3. SecuenciaCaracteres InsertaSecuenciaCaracteres3 (int pos_insercion,
	                                                 SecuenciaCaracteres otra)
	
	Este m�todo no modifica la secuencia de caracteres inicial, sino que crea
	un objeto de la clase SecuenciaCaracteres y se trabaja sobre este, de
	manera que el resultado de la inserci�n lo contendr� dicho objeto, que
	ser� devuelto por este m�todo.
*/
/***************************************************************************/

#include <iostream>
#include <string>

using namespace std;

/////////////////////////////////////////////////////////////////////////////

class SecuenciaCaracteres {

	private:

    	static const int TAMANIO = 50; // N�m.casillas disponibles
    	char vector_privado[TAMANIO];

    	// PRE: 0<=total_utilizados<TAMANIO

    	int total_utilizados; // N�m.casillas ocupadas

	public:

    	/*******************************************************************/
    	// Constructor sin argumentos

    	SecuenciaCaracteres (void) : total_utilizados (0)
    	{}
    
    	/*******************************************************************/
    	// Constructor con argumentos
    	
    	SecuenciaCaracteres (string cadena) : total_utilizados (0)
    	{
    		StringACaracteres (cadena);
    	}

    	/*******************************************************************/
    	// Devuelve el n�mero de casillas ocupadas

    	int TotalUtilizados (void)
    	{
        	return (total_utilizados);
    	}

    	/*******************************************************************/
    	// Devuelve el n�mero de casillas disponibles

    	int Capacidad (void)
    	{
        	return (TAMANIO);
    	}

    	/*******************************************************************/
    	// "Vac�a" completamente la secuencia

		void EliminaTodos()
		{
			total_utilizados = 0;
		}

    	/*******************************************************************/
    	// A�ade un elemento ("nuevo") al vector.
    	// PRE: total_utilizados < TAMANIO
    	// 		La adici�n se realiza si hay alguna casilla disponible.
    	// 		El nuevo elemento se coloca al final del vector.
    	// 		Si no hay espacio, no se hace nada.

    	void Aniade (char nuevo)
    	{
        	if (total_utilizados < TAMANIO){
            	vector_privado[total_utilizados] = nuevo;
            	total_utilizados++;
        	}	
    	}

    	/*******************************************************************/
    	// Devuelve el elemento de la casilla "indice"
    	// PRE: 0 <= indice < total_utilizados

    	char Elemento (int indice)
    	{
        	return (vector_privado[indice]);
    	}

    	/*******************************************************************/
    	// Cambia el contenido de la casilla "indice" por el valor "nuevo"
    	// PRE: 0 <= indice < total_utilizados

		void Modifica (int indice, char nuevo)
   		{
			if ((indice >= 0) && (indice < total_utilizados))
				vector_privado[indice] = nuevo;
   		}

    	/*******************************************************************/
    	// Eliminar el car�cter de la posici�n dada por "indice".
    	// Realiza un borrado f�sico (desplazamiento y sustituci�n).
    	// PRE: 0 <= indice < total_utilizados

    	void Elimina (int indice)
    	{
        	if ((indice >= 0) && (indice < total_utilizados)) {

            	int tope = total_utilizados-1; // posic. del �ltimo

            	for (int i = indice ; i < tope ; i++)
                	vector_privado[i] = vector_privado[i+1];

            	total_utilizados--;
        	}
    	}
    
    /***********************************************************************/
    	// Inserta el car�cter "nuevo" en la posici�n dada por "indice".
    	// Desplaza todos los caracteres una posici�n a la derecha antes de 
		// copiar en "indice" en valor "nuevo".
		// PRE: 0 <= pos_insercion < total_utilizados
    	// PRE: total_utilizados < TAMANIO
    	// 		La inserci�n se realiza si hay alguna casilla disponible.
    	// 		Si no hay espacio, no se hace nada.
    
		void Inserta (int pos_insercion, char valor_nuevo)
		{
        	if ((pos_insercion >= 0) && (pos_insercion < total_utilizados) 
		   		 && (total_utilizados < TAMANIO)) {
		
				for (int i = total_utilizados; i > pos_insercion; i--)
					vector_privado[i] = vector_privado[i-1];
			
				vector_privado[pos_insercion] = valor_nuevo;
				total_utilizados++;		
			}
		}
		
    	/*******************************************************************/
    	// Inserta la secuencia "otra" en la secuencia sobre la que se ejecuta 
    	// el m�todo. Si la secuencia "otra" y la inicial suman m�s de 50 
    	// caracteres, la inserci�n no se lleva a cabo.
    	// PRE: TAMANIO >= total_utilizados + otra.total_utilizados
    	// PRE: 0 <= pos_insercion < total_utilizados

    	void InsertaSecuenciaCaracteres (int pos_insercion, 
	                             	    SecuenciaCaracteres otra)
		{
			bool se_inserta = 
			(TAMANIO >= total_utilizados + otra.total_utilizados);
		
			if (se_inserta){
		
				for (int i = 0; i < otra.total_utilizados; i++){
			
					Inserta (pos_insercion, otra.vector_privado[i]);
				
					// Actualizamos la posici�n de inserci�n 
				
					pos_insercion++;
				}
			}
		}
	
		/*******************************************************************/
		// Inserta la secuencia "otra" en la secuencia sobre la que se ejecuta 
    	// el m�todo. Si la secuencia "otra" y la inicial suman m�s de 50 
    	// caracteres, la inserci�n no se lleva a cabo. La diferencia con el 
    	// m�todo anterior es que no llama al m�todo Inserta
    	// PRE: TAMANIO >= total_utilizados + otra.total_utilizados
    	// PRE: 0 <= pos_insercion < total_utilizados
	
		void InsertaSecuenciaCaracteres2 (int pos_insercion,
	                                 	SecuenciaCaracteres otra)
		{
			bool se_inserta = 
			(TAMANIO >= total_utilizados + otra.total_utilizados);
		
			if (se_inserta){
			
				for(int j = 0; j < otra.total_utilizados; j++){
				
					for (int i = total_utilizados; i > pos_insercion; i--)
						vector_privado[i] = vector_privado[i-1];
				
					vector_privado[pos_insercion] = otra.vector_privado[j];
				
					// Actualizamos la posici�n de inserci�n
				
					pos_insercion++;
				
					//Actualizamos total_utilizados
				
					total_utilizados++;
				}
			}
		}
	
		/*******************************************************************/
		// Crea una secuencia de salida que muestra el resultado de insertar la 
		// secuencia "otra" en la secuencia sobre la que se ejecuta el m�todo.
    	// Si la secuencia "otra" y la inicial suman m�s de 50 caracteres,
    	// la inserci�n no se lleva a cabo. 
    	// PRE: TAMANIO >= total_utilizados + otra.total_utilizados
    	// PRE: 0 <= pos_insercion < total_utilizados
    	// Recibe: int pos_insercion y SecuenciaCaracteres otra
    	// Devuelve: SecuenciaCaracteres resultado
	
		SecuenciaCaracteres InsertaSecuenciaCaracteres3 (int pos_insercion,
	                                                 SecuenciaCaracteres otra)
		{
		
			SecuenciaCaracteres resultado;
	
			bool se_inserta = 
			(TAMANIO >= total_utilizados + otra.total_utilizados);
	
			if (se_inserta){
			
				// Se comienza copiando la secuencia inicial en la secuencia de
				// salida
		
				for(int i = 0; i < total_utilizados; i++){
			
					resultado.Aniade(vector_privado[i]);
				}
		
				for(int j = 0; j < otra.total_utilizados; j++){
			
					for (int i = resultado.total_utilizados; 
					i > pos_insercion; i--){
						resultado.vector_privado[i] = 
						resultado.vector_privado[i-1];
					}
			
					resultado.vector_privado[pos_insercion] = 
					otra.vector_privado[j];
				
					// Actualizamos la posici�n de inserci�n
				
					pos_insercion++;
				
					// Actualizamos total_utilizados de la secuencia de salida
				
					resultado.total_utilizados++;
				}
			}
		
			// En caso de que ambas secuencias sumen m�s de 50 caracteres, se 
			// copia la secuencia inicial en la secuencia de salida (es decir, 
			// no se lleva a cabo la inserci�n)
		
			else{
			
				for(int i = 0; i < total_utilizados; i++)
					resultado.Aniade(vector_privado[i]);
			}
	
			return (resultado);
		}

    	/*******************************************************************/
    	// Compone un string con todos los caracteres que est�n
    	// almacenados en la secuencia y lo devuelve.

    	string ToString()
    	{
        	string cadena;

        	for (int i=0; i<total_utilizados; i++)
            	cadena = cadena + vector_privado[i];

        	return (cadena);
    	}

		/*****************************************************************/
		
	private:
	
		// M�todo que rellena el vector privado del objeto a partir de un
		// dato string
		
		void StringACaracteres (string cadena)
		{
			for(unsigned int i = 0; i < cadena.length(); i++){
			
				Aniade(cadena.at(i));
			}
		}
};

/////////////////////////////////////////////////////////////////////////////

class Lector
{
	private:
		
		string titulo;
	
	public:
		
		// Constructor sin argumentos
		
		Lector (void) : titulo ("")
		{ }
		
		// Constructor con argumentos
		
		Lector (string cad) : titulo (cad)
		{ }
		
		// M�todo Set para fijar el campo "titulo"
		
		void SetTitulo (string cad)
		{
			titulo = cad;
		}
		
		/*********************************************************************/
		// Lee un dato int.
		// La lectura est� etiquetada con "titulo"
		// La lectura se efect�a repetidamente hasta que se introduce un valor
		// int correcto.
		
		int LeeEntero (void)
		{
			string cadena;
			
			do{
				cout << titulo;
				getline(cin, cadena);
			}
			while (!EsEntero(cadena));
			
			return (stoi(cadena));
		}
		
		/*********************************************************************/
		// Lee un dato int.
		// La lectura est� etiquetada con "titulo"
		// PRE: menor <= mayor
		// POST: menor <= valor devuelto <= mayor
		
		int LeeEnteroEnRango (int menor, int mayor)
		{
			int numero;
			
			do{
				
				numero = LeeEntero ();
			}
			while ((numero<menor) || (numero>mayor));
			
			return (numero);
		}
		
		/*********************************************************************/
		// Lee un dato int que debe ser mayor o igual que "menor" y lo devuelve.
		// La lectura est� etiquetada con "titulo"
		
		int LeeEnteroMayorOIgual (int menor)
		{
			int numero;
			
			do{
				numero = LeeEntero ();
			}
			while (numero < menor);
			
			return (numero);
		}
	
	private:
		
		/*********************************************************************/
		// Devuelve una NUEVA cadena, resultante de eliminar los �ltimos
		// caracteres separadores de "cadena". Los caracteres separadores son
		// el espacio en blanco, el tabulador y el salto de l�nea.
		// Usaremos la funci�n isspace() para simplificar el c�lculo.
		//
		// Recibe: cadena, string sobre la que se va a trabajar.
		// Devuelve: el resultado de eliminar los �ltimos separadores de 
		// "cadena"
		/*********************************************************************/
		
		string EliminaUltimosSeparadores (string cadena)
		{
			while (cadena.length()>0 && isspace(cadena.back()))
				cadena.pop_back();
			
			return (cadena);
		}
		
		/*********************************************************************/
		// Devuelve una NUEVA cadena, resultante de eliminar los primeros
		// caracteres separadores de "cadena". Los caracteres separadores son
		// el espacio en blanco, el tabulador y el salto de l�nea.
		// Usaremos la funci�n isspace() para simplificar el c�lculo.
		//
		// Recibe: cadena, string sobre la que se va a trabajar.
		// Devuelve: el resultado de eliminar los �ltimos separadores de 
		// "cadena"
		/*********************************************************************/
		string EliminaPrimerosSeparadores (string cadena)
		{
			// Buscar el primer car�cter no espacio
			unsigned int pos = 0;
			while (pos < cadena.length() && isspace(cadena.at(pos))) pos++;
			
			string local;
			
			// Copiar todos los que quedan
			while (pos < cadena.length()) {
				local.push_back(cadena.at(pos));
				pos++;
			}
			
			return (local);
		}
		
		/*********************************************************************/
		// Devuelve una NUEVA cadena, resultante de eliminar los primeros 
		// �ltimos caracteres separadores de "cadena". Los caracteres 
		// separadores son el espacio en blanco, el tabulador y el salto de
		// l�nea
		//
		// Recibe: cadena, string sobre la que se va a trabajar.
		// Devuelve: el resultado de eliminar los primeros y los �ltimos
		//           separadores de "cadena".
		/*********************************************************************/
		
		string EliminaPrimerosYUltimosSeparadores (string cadena)
		{
			string cadena_podada = EliminaPrimerosSeparadores (cadena);
			cadena_podada = EliminaUltimosSeparadores (cadena_podada);
			
			return (cadena_podada);
		}
		
		/*********************************************************************/
		// Devuelve "true" si "cadena" es la representaci�n textual de un
		// entero
		//
		// Recibe: cadena, string sobre la que se va a trabajar.
		// Devuelve: "true" si "cadena" es la representaci�n textual de un int
		
		bool EsEntero (string cadena)
		{
			bool es_entero = true;
			
			cadena = EliminaPrimerosSeparadores (cadena);
			cadena = EliminaUltimosSeparadores (cadena);
			
			unsigned int long_cadena = cadena.length();
			
			if (long_cadena == 0) es_entero = false;
			else {
				
				// Si el primer car�cter es '+' � '-', perfecto. En ese caso
				// se pasa al siguiente car�cter (posici�n 19.
				
				unsigned int pos;
				if (cadena.at(0)=='-' || cadena.at(0) == '+') pos = 1;
				else pos = 0;
				
				while ((pos < long_cadena) && es_entero) {
					if(!isdigit(cadena.at(pos))) es_entero = false;
					else pos++;
				}
			}
			
			return (es_entero);
		}
};

//////////////////////////////////////////////////////////////////////////////

int main() // Programa principal
{
	// Declaraci�n de datos
	
	string cadena_inicial;
	string a_insertar;
	int pos_insercion;
	
	// Entrada de datos
	
	cout << "AVISO: Recuerde que la secuencia inicial y la que quiere insertar"
	<< " en ella no deben de tener entre ambas m�s de 50 caracteres. En caso "
	<< "de superar los 50, no se insertar� nada y se mostrar� la secuencia"
	<< " inicial" << endl;
	
	cout << "Adem�s, la posici�n de inserci�n debe estar entre 0 y la posici�n"
	<< " m�xima del �ltimo caracter introducido de la secuencia inicial";
	
	cout << endl << endl;
	
	cout << "Introduzca una secuencia de caracteres cualquiera: ";
	getline(cin, cadena_inicial);
	
	SecuenciaCaracteres secuencia(cadena_inicial);
	SecuenciaCaracteres secuenciaA(secuencia);
	SecuenciaCaracteres secuenciaB(secuencia);
	
	cout << "Introduzca la secuencia de caracteres a insertar en la anterior: ";
	getline(cin, a_insertar);
	
	SecuenciaCaracteres secuencia1(a_insertar);
	
	// Lectura de la posici�n de inserci�n
	
	Lector lector;
	
	lector.SetTitulo("Introduzca la posici�n por la que se va a insertar: ");
	pos_insercion = lector.LeeEnteroEnRango(0, secuencia.TotalUtilizados() - 1);
	
	/***********************************************************************/
	
	cout << "M�TODO 1" << endl << endl;
	
	secuencia.InsertaSecuenciaCaracteres(pos_insercion, secuencia1);
	
	cout << "Tras insertar la secuencia a la inicial obtenemos: " 
	<< secuencia.ToString() << endl << endl;
	
	/***********************************************************************/
	
	cout << "M�TODO 2" << endl << endl;
	
	secuenciaA.InsertaSecuenciaCaracteres2(pos_insercion, secuencia1);
	
	cout << "Tras insertar la secuencia a la inicial obtenemos: " 
	<< secuenciaA.ToString() << endl << endl;
	
	/***********************************************************************/
	
	cout << "M�TODO 3" << endl << endl;
	
	SecuenciaCaracteres 
	secuenciaC
	(secuenciaB.InsertaSecuenciaCaracteres3(pos_insercion, secuencia1));
	
	cout << "Tras insertar la secuencia a la inicial obtenemos: " 
	<< secuenciaC.ToString() << endl << endl;
	
	return 0;
}
