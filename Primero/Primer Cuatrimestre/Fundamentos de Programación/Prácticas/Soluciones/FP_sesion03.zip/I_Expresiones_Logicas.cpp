/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa consta de 5 partes y su principal funci�n es determinar si un dato
que introducimos cumple con unas condiciones que se especifican con un dato de
tipo bool. Si no cumple con lo establecido, el programa nos devolver� un 0, lo 
cual significa que es falso que el dato introducido cumple las condiciones. Si 
nos devuelve un 1, significar� que es verdad que el dato introducido satisface
lo establecido en el dato de tipo bool.

Parte 1: Al introducir una letra, si es may�scula aparecer� un 1, y si no lo es,
aparecer� un 0. En la expresi�n l�gica he hecho uso de los valores entre los
que est�n las may�sculas en la tabla ASCII de la p�gina 82 de los apuntes.
Parte 2: Al introducir una edad, el programa nos dice si es una edad superior o
igual que 18 a�os y menor que 67 a�os. Si est� en dicho intervalo la edad 
introducida, aparecer� un 1. Si no, un 0.
Parte 3: Al introducir un a�o, el programa nos dice si es bisiesto o no. Si es
bisiesto, nos devolver� un 1. Si no lo es, un 0.
Parte 4: Al introducir una distancia y dado un n�mero con decimales (LIMITE), 
aparecer� un 0 si la distancia introducida es mayor que LIMITE y un 1 si es 
menor que LIMITE.
Parte 5 : Al introducir dos n�meros enteros se determina si el primero es menor,
mayor o igual que el segundo. En este caso, se usan tres datos de tipo bool y
solo uno de ellos nos dar� 1, mientras que los otros dos ser�n 0.
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recursos de E/S

using namespace std;

int main () // Programa principal
{
	// Declaraci�n de datos para la primera expresi�n l�gica
	
	char letra;
	bool mayus_o_minus;
	
	// Entrada de datos para la primera expresi�n l�gica
	
	cout << "Introduzca una letra para saber si es may�scula: ";
	cin >> letra;
	
	// Asignaci�n al dato de tipo bool "mayus_o_minus"
	
	mayus_o_minus = 65 <= letra && letra <= 90;
	
	// Salida de datos
	
	cout << mayus_o_minus;
	
	/*************************************************************************/
	
	// Declaraci�n de datos para la segunda expresi�n l�gica
	
	int edad;
	bool intervalo_edad;
	
	// Entrada de datos para la segunda expresi�n l�gica
	
	cout << endl;
	cout << endl;
	cout << "Introduzca una edad: ";
	cin >> edad;
	
	// Asignaci�n al dato de tipo bool "intervalo_edad"
	
	intervalo_edad = edad >= 18 && edad < 67;
	
	// Salida de datos
	
	cout << intervalo_edad;
	
	/*************************************************************************/
	
	// Declaraci�n de datos para la tercera expresi�n l�gica
	
	int fecha;
	bool bisiesto;
	
	// Entrada de datos para la tercera expresi�n l�gica
	
	cout << endl;
	cout << endl;
	cout << "Introduzca un a�o para saber si es bisiesto: ";
	cin >> fecha;
	
	// Asignaci�n al dato de tipo bool "bisiesto"
	
	bisiesto = ((fecha%4 == 0) && (!(fecha%100 == 0) || (fecha%400 == 0)));
	
	// Salida de datos
	
	cout << bisiesto;
	
	/*************************************************************************/
	
	// Declaraci�n de datos para la cuarta expresi�n l�gica
	
	double distancia;
	const double LIMITE = 45.6;
	bool distancia_limite;
	
	// Entrada de datos para la cuarta expresi�n l�gica
	
	cout << endl;
	cout << endl;
	cout << "Introduzca la distancia para saber si es menor que 45.6: ";
	cin >> distancia;
	
	// Asignaci�n al dato de tipo bool "distancia_limite"
	
	distancia_limite = distancia < LIMITE;
	
	// Salida de datos
	
	cout << distancia_limite;
	
	/*************************************************************************/
	
	// Declaraci�n de datos para la quinta expresi�n l�gica
	
	int variable1;
	int variable2;
	bool menor;
	bool igual;
	bool mayor;
	
	// Entrada de datos para la quinta expresi�n l�gica
	
	cout << endl;
	cout << endl;
	cout << "Introduzca un entero: ";
	cin >> variable1;
	cout << "Introduzca otro entero: ";
	cin >> variable2;
	
	// Asignaci�n a los datos de tipo bool "menor", "igual" o "mayor"
	
	menor = variable1 < variable2;
	igual = variable1 == variable2;
	mayor = variable1 > variable2;
	
	// Salida de datos
	
	cout << menor << endl;
	cout << igual << endl;
	cout << mayor << endl;
	
	
	
	return 0;
}
	
