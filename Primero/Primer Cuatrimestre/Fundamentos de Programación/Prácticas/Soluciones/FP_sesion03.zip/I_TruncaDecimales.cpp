/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa trunca un n�mero real (con decimales) introducido por el usuario 
justo por la cifra decimal que el usuario desea (por ejemplo, si tenemos el
3.284 y el usuario quiere truncarlo hasta la segunda cifra decimal, el programa
dar�a como resultado 3.28). Para resolverlo, es necesario multiplicar el n�mero
introducido por 10 elevado al n� de cifra hasta la que se desea truncar. El 
n�mero que resulta de dicha operaci�n tiene su parte decimal formada por todas 
las cifras que deseamos eliminar. Para deshacernos de ella, he declarado un dato 
de tipo entero al cual he llamado "auxiliar" y le he asignado el n�mero real que
ha resultado de la multiplicaci�n anterior. As�, el dato auxiliar tendr� como 
valor la parte entera de ese n�mero, la cual, al dividirla por 10 elevado al 
n�mero de cifra hasta la que se quer�a truncar, obtenemos el n�mero truncado 
final.
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recursos de E/S
#include <cmath> // Inclusi�n de los recursos matem�ticos

using namespace std;

int main() // Programa principal
{
	// Declaraci�n de datos
	
	double numero_a_truncar;
	int cifra_referencia;
	int auxiliar;
	double truncado;
	
	// Entrada de datos
	
	cout << "Introduza el n�mero que desea truncar: ";
	cin >> numero_a_truncar;
	cout << "Introduzca la posici�n de la cifra decimal hasta la que desea "
	<< "truncar: ";
	cin >> cifra_referencia;
	
	// C�lculos
	
	numero_a_truncar = numero_a_truncar*pow(10,cifra_referencia);
	auxiliar = numero_a_truncar;
	truncado = auxiliar/pow(10,cifra_referencia);
	
	// Salida de datos
	
	cout << endl;
	cout << "El n�mero truncado que resulta es " << truncado;
	
	return 0;
}
