/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa transforma una letra introducida en may�scula a min�scula 
(suponiendo que el usuario introducir� una letra may�scula s� o s�). Para ello,
primero he declarado un dato de tipo char que ser�a la letra en may�scula que
introduce el usuario. El segundo dato que he declarado ha sido una constante 
entera que es la distancia a la que se encuentra una letra may�scula de su
min�scula (esto lo he hecho fij�ndome en la tabla ASCII de la p�gina 82 de los
apuntes de la asignatura). Dicha distancia la he definido con 'a'-'A' ya que
es la misma para todas las letras (A se corresponde con 65 y a con 97, por lo
que la diferencia es 32; B se corresponde con 66 y b con 98, siendo su 
diferencia tambi�n 32. Es por ello que he sabido que 'a' - 'A' es una diferencia
v�lida para todas las letras may�sculas con respecto de sus min�sculas). 
Finalmente, como se puede operar con datos char e int, he sumado dicha 
diferencia a la letra que haya introducido el usuario, resultando as� la 
letra min�scula al imprimir en pantalla el dato de tipo char "letra".
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recursos de E/S

using namespace std;

int main() // Programa principal
{
	// Declaraci�n de datos
	
	char letra;
	const int DIFERENCIA_MAYUS_MINUS = 'a'-'A';
	
	// Entrada de datos
	
	cout << "Introduzca una letra may�scula: ";
	cin >> letra;
	
	// C�lculos
	
	letra = letra + DIFERENCIA_MAYUS_MINUS;
	
	// Salida de datos
	
	cout << endl;
	cout << "La letra introducida en min�scula es: " << letra;
	
	return 0;
}
	
	
