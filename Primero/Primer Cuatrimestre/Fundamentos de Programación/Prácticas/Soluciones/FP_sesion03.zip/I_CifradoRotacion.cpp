/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/*
Este programa nos permite desplazar un n�mero de posiciones concreto dentro del
abecedario (sin tener en cuenta la �) una letra may�scula, la cual es 
introducida por el usuario. Para realizar este ejercicio he usado la estructura
que cre� en el ejercicio 22 de la sesi�n de pr�cticas 2. La �nica diferencia es
que como en este caso lo que queremos desplazar es una letra en vez de un 
n�mero, he tenido que declarar un dato de tipo char que ser�a la letra may�scula
que introduce el usuario. En esta ocasi�n, la amplitud del intervalo la he 
definido como la diferencia de los n�meros con los que se corresponden en la
tabla ASCII las letras A (que ser�a el m�nimo del intervalo) y Z (que ser�a el
m�ximo del intervalo). Finalmente, he asignado el c�lculo que cre� para el
ejercicio 22 a otro dato de tipo char, pues ese es el dato que quiero que se 
imprima en pantalla y necesito que sea char para que aparezca la letra
desplazada. Para saber de d�nde sale el c�lculo principal de este programa, 
en el ejercicio 22 de la anterior sesi�n de pr�cticas lo explico en profundidad.
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recursos de E/S

using namespace std;

int main() // Programa principal
{
	// Declaraci�n de datos
	
	char letra_a_desplazar;
	int clave;
	int desplazado;
	int amplitud;
	char letra_desplazada;
	
	// Entrada de datos
	
	cout << "Introduzca la letra may�scula a desplazar: ";
	cin >> letra_a_desplazar;
	cout << "Introduzca el n� de posiciones que la desea desplazar: ";
	cin >> clave;
	
	// C�lculos
	
	desplazado = letra_a_desplazar + clave;
	amplitud = 'Z'- ('A'-1);
	letra_desplazada = ((desplazado -'A')%amplitud) + 'A';
	
	// Salida de datos
	
	cout << endl;
	cout << "Su letra desplazada es " << letra_desplazada;
	
	return 0;
}

