/***************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/*	
	Una recta r viene determinada por tres coeficientes A, B, C, de forma 
	que todos los puntos (x, y) del plano que pertenecen a la recta verifican:
		r : Ax + By + C = 0 (ecuaci�n general)
	
	Es m�s frecuente utilizar la ecuaci�n expl�cita de la recta, en la que 
	se expresa la abscisa en funci�n de la pendiente de la recta (m) y de 
	la ordenada en origen (n):
		r : y = mx + n  (ecuaci�n expl�cita)
	de manera que m = -A/B y n = -C/B
	
	Este programa: 
	
		a) 	Pide los coeficientes de dos rectas,
		b) 	Muestra los puntos (x, y) por los que pasan las rectas para 
			valores de x = -10, -9, ..., 10 con Incr_x = +1 y para 
			y = -5,- 4, .... 5 con Incr_y = 0.5
			
			Usa las funciones:
				double Ordenada (Recta recta, Punto2D punto);
				double Abscisa  (Recta recta, Punto2D punto);
			
			para calcular la ordenada "y" dada la abscisa "x" (y viceversa)  
			para la recta Ax+By+C=0
			
		c) Escribe la ecuaci�n expl�cita de las dos rectas
		
			i) con una funci�n que escribe directamente la ecuaci�n:
				void PintaEcuacionExplicita (Recta recta);
		
			ii) con una funci�n que devuelve un string con la expresi�n de 
				la ecuaci�n:
				string ObtenEcuacionExplicita (Recta recta);
				
			En ambos casos se calcula la pendiente y la ordenada en el origen 
			con sendas funciones:
				double Pendiente (Recta recta);
				double OrdenadaEnOrigen (Recta recta);				
					
		d) 	Indica si las rectas son paralelas, secantes o coincidentes 
			usando las funciones:
				bool SonCoincidentes (Recta recta1, Recta recta2); 			
				bool SonParalelas    (Recta recta1, Recta recta2); 			
				bool SonSecantes     (Recta recta1, Recta recta2); 
				
		e) Calcula el punto de corte en caso de que sean secantes:
		        Punto2D PuntoCorte (Recta recta1, Recta recta2);
		        
		He de explicar la f�rmula que he utilizado para hallar las coordenadas
		x e y del punto de corte. Sean dos rectas secantes Ax+By+C = 0 y
		A'x+B'y+C' = 0. Para hallar el punto de corte he despejado y en ambas
		ecuaciones de manera que y = (-Ax-C)/B e y = (-A'x-C')/B'. Tras esto,
		he igualado ambas expresiones (ya que las coordenadas deben ser iguales
		en el punto de corte) obteniendo (-Ax-C)/B = (-A'x-C')/B'. Entonces, he
		despejado x y me ha dado como soluci�n gen�rica:
		
		x = (-BC' + CB')/(BA' - AB')
		
		Para hallar la soluci�n gen�rica de y he sustituido la expresi�n
		gen�rica de x en la ecuaci�n y = (-Ax-C)/B y he obtenido que:
		
		y = (AC' - CA')/(BA' - AB')
		
		La precondici�n de nuestra funci�n es que el denominador sea distinto
		de 0. Sin embargo, veremos que estas posibilidades est�n cubiertas. Para
		que el denominador sea igual a 0 caben varias posibilidades:
		
		1. Que BA' = AB', pero eso significar�a que las rectas introducidas
		son paralelas o coincidentes. Sin embargo, la funci�n PuntoCorte se 
		utiliza solo si las rectas son secantes.
		
		2. Que BA' Y AB' sean 0. Sabemos que A y B no pueden ser simult�neamente
		0, y tampoc A' y B'. Entonces solo nos queda la opci�n de que A y A'
		sean 0 (lo cual significa que las dos rectas son paralelas al eje x,
		por lo que la funci�n ni se habr�a ejecutado pues solo se ejecuta
		para rectas secantes) o que B y B' sean 0 (lo cual significa que las dos
		rectas son paralelas al eje Y, y tampoco se habr�a ejecutado la 
		funci�n ya que solo se ejecuta para rectas secantes).
		
		f) Determina si un punto pertenece a la primera recta introducida
		       bool Pertenece (Recta recta, Punto2D punto)
									  
									  			
*/
/***************************************************************************/

#include <iostream>
#include <iomanip>
#include <string>
#include <cmath>
using namespace std;


// Primero he de crear los dos struct que se piden en el ejercicio

struct Punto2D {
	
	double x;
	double y;
};

struct Recta {
	
	double A;
	double B;
	double C;
};

/***************************************************************************/
// Calcula la ordenada "y" dada la abscisa "x" para la recta Ax+By+C=0
// Recibe: recta y un punto
// PRE: B != 0
/***************************************************************************/

double Ordenada (Recta recta, Punto2D punto)
{
	return ((-recta.A*punto.x - recta.C) / recta.B);
}

/***************************************************************************/
// Calcula la abscisa "x" dada la ordenada "y" para la recta Ax+By+C=0
// Recibe: recta y un punto
// PRE: A != 0
/***************************************************************************/

double Abscisa  (Recta recta , Punto2D punto)
{
	return ((-recta.B*punto.y - recta.C) / recta.A);	
}
	
/***************************************************************************/
// Devuelve la pendiente de la recta (m = -A/B)
// Recibe: recta
// PRE: B != 0
/***************************************************************************/

double Pendiente (Recta recta)
{
	return (-recta.A/recta.B);
}
		
/***************************************************************************/
// Devuelve la ordenada en origen de la recta (n = -C/B)
// Recibe: recta
// PRE: B != 0
/***************************************************************************/

double OrdenadaEnOrigen (Recta recta)
{
	return (-recta.C/recta.B);	
}
			
/***************************************************************************/
// Escribe directamente la ecuaci�n expl�cita de una recta
// Recibe: recta
// PRE: B != 0
/***************************************************************************/

void PintaEcuacionExplicita (Recta recta)
{
	double m = Pendiente (recta);
	double n = OrdenadaEnOrigen (recta);	
	
	cout << " y = ";
	
	if (m!=0) 
		cout << setw(5) << setprecision(2) << m <<  " x ";	

	if (n != 0) {
		
		if (n>0) cout << " +";
		else     cout << " -";
		
		// cout << ((n > 0) ? " +" : " -");
	}
	
	cout << setw(5) << setprecision(2) << fabs(n);	
}
		
/***************************************************************************/
// Devuelve un string con la expresi�n de la ecuaci�n explicita
// Recibe: recta
// Devuelve: un string con la ecuaci�n expl�cita de la recta.
// PRE: B != 0
/***************************************************************************/

string ObtenEcuacionExplicita (Recta recta)
{
	double m = Pendiente (recta);
	double n = OrdenadaEnOrigen (recta);	
	
	string explicita;
	
	explicita = "y = ";
	
	if (m!=0) explicita = explicita +to_string (m) + " x ";	
	
	if (n != 0) {
		
		if (n>0) explicita = explicita + " +";
		else     explicita = explicita + " -";
		
		// explicita = explicita + ((n > 0) ? " +" : " -");
	}
	
	explicita = explicita + to_string (fabs(n));	
	
	return (explicita);
}
			
/***************************************************************************/
// Calcula si dos rectas son coincidentes.
// Recibe: recta1, recta2
// Devuelve: "true" si las rectas son coincidentes.
/***************************************************************************/

bool SonCoincidentes (Recta recta1, Recta recta2)
{
	double razon = recta1.A/recta2.A;
	return ((razon == recta1.B/recta2.B) && (razon == recta1.C/recta2.C));
}
					 			
/***************************************************************************/
// Calcula si dos rectas son paralelas.
// Recibe: recta1, recta2
// Devuelve: "true" si las rectas son paralelas.
/***************************************************************************/

bool SonParalelas (Recta recta1, Recta recta2)		
{
	double razon = recta1.A/recta2.A;
	return ((razon == recta1.B/recta2.B) && (razon != recta1.C/recta2.C));
}

/***************************************************************************/
// Calcula si dos rectas son secantes.
// Recibe: recta1, recta2
// Devuelve: "true" si las rectas son secantes.
/***************************************************************************/

bool SonSecantes (Recta recta1, Recta recta2)
{
	double razon = recta1.A/recta2.A;	
	return (razon != recta1.B/recta2.B);
}

/***************************************************************************/
// Calcula el punto de corte de dos rectas secantes
// Recibe: recta1, recta2
// Devuelve: punto de corte

Punto2D PuntoCorte (Recta recta1, Recta recta2){
	
	Punto2D punto_corte;
	
	punto_corte.x = (-recta1.B*recta2.C + recta1.C*recta2.B) /
	(recta1.B*recta2.A - recta1.A*recta2.B);
	punto_corte.y = (recta1.A*recta2.C - recta1.C*recta2.A) /
	(recta1.B*recta2.A - recta1.A*recta2.B);
	
	return (punto_corte);
}
			
/***************************************************************************/
// Calcula si un punto pertenece a una recta
// Recibe: una recta y un punto
// Devuelve: "true" el punto pertenece a la recta

bool Pertenece (Recta recta, Punto2D punto)
{
	return ((recta.A*punto.x + recta.B*punto.y + recta.C == 0));
}
						  
									  				
/***************************************************************************/
/***************************************************************************/

int main()
{
	cout.setf(ios::fixed);		// Notaci�n de punto fijo para los reales
	cout.setf(ios::showpoint);	// Mostrar siempre decimales 
	
	Recta recta1;  // PRE: A1 y B1 no pueden ser ambos 0 
	Recta recta2;  // PRE: A2 y B2 no pueden ser ambos 0 
	Punto2D punto_aux;
	Punto2D punto_corte;
	
	// a) Lectura de los coeficientes de las dos rectas

	cout << endl;	
	cout << "Recta 1: ";

	do 	{
		cout << endl; 
		cout << "\tA: ";
		cin >> recta1.A;
		cout << "\tB: ";
		cin >> recta1.B;
	} while (recta1.A==0 && recta1.B==0);

	cout << "\tC: ";
	cin >> recta1.C;
	
	cout << endl;	
	cout << "Recta 2: ";
	
	do 	{
		cout << endl; 
		cout << "\tA: ";
		cin >> recta2.A;
		cout << "\tB: ";
		cin >> recta2.B;
	} while (recta2.A==0 && recta2.B==0);

	cout << "\tC: ";
	cin >> recta2.C;
	
	cout << endl;	


	// b) Mostrar puntos (x,y) por los que pasan las rectas
	
	if (recta1.B!=0) {
		cout << endl;	
		cout << "Recta 1. x=-10.0, -9.0, ..., 10.0" << endl;
		cout << endl;	
		
		for (punto_aux.x=-10.0; punto_aux.x<=10.0; punto_aux.x++) {
			
			punto_aux.y = Ordenada (recta1, punto_aux);
			
			cout << "\t(" << setw(6) << setprecision(2) << punto_aux.x << ", " 
			     << setw(6) << setprecision(2) 
				 << punto_aux.y << ")" << endl;
		}
	}
	else // B1==0
		cout << "Recta 1 paralela al eje Y--> x = " 
		     << setw(6) << setprecision(2) << (-recta1.C/recta1.A) << endl;
	cout << endl;	
	
	if (recta1.A!=0) {
		cout << endl;
		cout << "Recta 1. y=-5.0, -4.5, -4.0, ..., 5.0" << endl; 
		cout << endl;	
		
		for (punto_aux.y=-5.0; punto_aux.y<=5.0; punto_aux.y+=0.5) {
			
			punto_aux.x = Abscisa (recta1, punto_aux);
			
			cout << "\t(" << setw(6) << setprecision(2) 
			     << punto_aux.x  << ", " 
			     << setw(6) << setprecision(2) << punto_aux.y << ")" << endl;
		}
	}
	else // A1==0
		cout << "Recta 1 paralela al eje X--> y = " 
		     << setw(6) << setprecision(2) << (-recta1.C/recta1.B) << endl;
	cout << endl;
		
	if (recta2.B!=0) {
		cout << endl;		
		cout << "Recta 2. x=-10.0, -9.0, ..., 10.0" << endl;
		cout << endl;	
		
		for (punto_aux.x=-10.0; punto_aux.x<=10.0; punto_aux.x++) {
			
			punto_aux.y = Ordenada (recta2, punto_aux);
			
			cout << "\t(" << setw(6) << setprecision(2) << punto_aux.x << ", " 
			     << setw(6) << setprecision(2) 
				 << punto_aux.y << ")" << endl;
		}
	}
	else // B2==0
		cout << "Recta 2 paralela al eje Y--> x = " 
		     << setw(6) << setprecision(2) << (-recta2.C/recta2.A) << endl;
	cout << endl;

	if (recta2.A!=0) {			 	
		cout << endl;
		cout << "Recta 2. y=-5.0, -4.5, -4.0, ..., 5.0" << endl; 
		cout << endl;	
	
		for (punto_aux.y=-5.0; punto_aux.y<=5.0; punto_aux.y+=0.5) {
			
			punto_aux.x = Abscisa (recta2, punto_aux);
			
			cout << "\t(" << setw(6) << setprecision(2) 
			     << punto_aux.x  << ", " 
			     << setw(6) << setprecision(2) << punto_aux.y << ")" << endl;
		}
	}
	else
		cout << "Recta 2 paralela al eje X--> y = " 
		     << setw(6) << setprecision(2) << (-recta2.C/recta2.B) << endl;
	cout << endl;	
				
					 		
	// c) Escribir la ecuaci�n expl�cita de las dos rectas
	
	if (recta1.B != 0) {
		cout << "Recta 1: " << endl;
		PintaEcuacionExplicita (recta1);
		cout << endl;
		
		cout << endl;
		cout << "Recta 1: " << ObtenEcuacionExplicita (recta1) << endl;
		cout << endl;
	}
	
	if (recta2.B != 0) {		
		cout << endl;
		cout << "Recta 2: " << endl;
		PintaEcuacionExplicita (recta2);
		cout << endl;
	
		cout << endl;
		cout << "Recta 2: " << ObtenEcuacionExplicita (recta2) << endl;
		cout << endl;
	}

	// d) Posici�n relativa de las dos rectas
	
	cout << endl;
	cout << "Las rectas son ";	
	
	if (SonCoincidentes(recta1, recta2))
		cout << " COINCIDENTES" << endl; 
	else if (SonParalelas(recta1, recta2))
		cout << " PARALELAS" << endl; 
		
	// e) C�lculo del punto de corte
	
	else if (SonSecantes(recta1, recta2))
		cout << " SECANTES" << endl;
		
		punto_corte = PuntoCorte (recta1, recta2);
		cout << "El punto de corte entre las dos rectas es (" << punto_corte.x
		<< ", " << punto_corte.y << ")";
	cout << endl << endl;
	
	// f) Comprobar si un punto pertenece a alguna de las dos rectas
	
	string entrada;
	bool terminador;
	
	cout << endl;
	cout << "�PERTENECE EL PUNTO A INTRODUCIR A LA RECTA 1?";
	do{
		cout << endl;
		cout << "Introduzca la abscisa del punto a comprobar: ";
		cin >> entrada;
		
		terminador = (entrada == "FIN");
		
		if (!(terminador)){
			
			punto_aux.x = stod(entrada);
			cout << "Introduza la ordenada del punto a comprobar: ";
			cin >> punto_aux.y;
			
			if (Pertenece (recta1, punto_aux)){
				
				cout << "El punto (" << punto_aux.x << ", " << punto_aux.y
				<< ") pertenece a la recta 1";
			}
		}
	}
	while (!(terminador));

	return 0;
}
