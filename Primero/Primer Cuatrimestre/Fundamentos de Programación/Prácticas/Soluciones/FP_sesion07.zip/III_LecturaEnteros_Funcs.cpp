/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa se encarga de la lectura de enteros y no finaliza hasta que la
lectura hasta que el dato introducido sea un entero. En total se realizan
tres lecturas y para cada lectura hemos creado una funci�n:

1. En la primera lectura hacemos uso de la funci�n LeeEntero, la cual pide al
un entero y no permite que se avance a la siguiente lectura hasta que no se
haya introducido un entero (es decir, se volver� a pedir un entero si el 
usuario no ha introducido un entero).

2. En la segunda lectura hacemos uso de la funci�n LeeEnteroEnRango, la cual,
adem�s de solicitar un entero y rechazar cualquier entrada que no sea un 
entero, tambi�n obliga a que el entero que se haya introducido est� entre
-25 y 25.

3. La �ltima lectura se hace mediante el uso de la funci�n LeeEnteroMayorOIgual,
la cual, adem�s de solicitar un entero y rechazar cualquier entrada que no sea
un entero, tambi�n obliga a que el entero que se haya introducido sea mayor o
igual que 2.
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recursos de E/S
#include <string>
#include <cctype>
#include <iomanip>

using namespace std;

// Creaci�n de las tres funciones que se piden en el enunciado

int LeeEntero (string titulo) {
	
	string entrada;
	string numero;
	bool es_entero;
	
	do{
		cout << titulo;
		cin >> entrada;
		
		int posicion = 0;
		es_entero = true;
		
		// Iremos recorriendo las posiciones de la cadena una a una (la primera
		// posici�n es la 0) comprobando que cada elemento de la misma es un
		// d�gito o no (para ello usaremos isdigit)
		
		while (posicion < entrada.length()){
			
			// Si el primer elemento no es un d�gito ni un espacio, hemos de
			// considerar que sea un '-' (por lo tanto ser�a un n�mero negativo)
			// o si no es un '-', por lo que es_entero pasa a ser falso y se
			// vuelve a pedir un entero
			
			if (!isdigit(entrada.at(posicion)) && 
			!isspace(entrada.at(posicion))){
				
				if ((entrada.at(posicion) == '-') && (numero.length() == 0)
				&& (isdigit(entrada.at(posicion + 1)))){
					
					// Se le a�ade el primer elemento a la cadena de salida
					// 'numero', en este caso un signo negativo. En la siguiente
					// iteraci�n del c�digo esta parte no se ejecutar� porque
					// la longitud de la cadena 'numero' ya no ser� 0
					
					numero.push_back(entrada.at(posicion));
				}
				
				// Si el primer elemento no es n�mero, signo - ni espacio, 
				// hacemos que posicion tenga el valor de la longitud de la
				// cadena de entrada para que se salga del bucle. Tambi�n 
				// hemos de hacer que es_entero sea falso para que se vuelva
				// a pedir un entero (recordar que esto es un bucle anidado)
				
				else{
					
					posicion = entrada.length();
					es_entero = false;
				}
			}
			
			// Si el elemento que se est� evaluando es un d�gito, se a�ade al
			// final de la cadena 'numero'
			
			else{
				
				numero.push_back(entrada.at(posicion));
			}
			
			// Actualizamos la posici�n a la del siguiente elemento a examinar
			
			posicion++;
		}
		
		// Si la cadena fuese vac�a, se debe pedir un entero otra vez, es decir,
		// es_entero = false para que el bucle se vuelva a ejecutar
		
		if (entrada.length() == 0){
			
			es_entero = false;
		}
	}
	while (!es_entero);
	
	return (stoi(numero));
}

/*****************************************************************************/

int LeeEnteroEnRango (string titulo, int menor, int mayor){
	
	int numero;
	
	do{
		numero = LeeEntero (titulo);
	}
	while ((numero < menor) || (numero > mayor));
	
	return (numero);
}

/*****************************************************************************/

 int LeeEnteroMayorOIgual (string titulo, int referencia){

 	int numero;

 	do{
 		numero = LeeEntero (titulo);
 	}
 	while (numero < referencia);
 	
 	return (numero);
 }
 
 /****************************************************************************/
 
 int main() // Programa principal
 {
 	LeeEntero ("Introduzca un entero: ");
 	LeeEnteroEnRango ("Introduzca un entero entre -25 y 25: ", -25, 25);
 	LeeEnteroMayorOIgual ("Introduzca un entero mayor o igual que 2: ", 2);
 	
 	return 0;
 }
