/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa tiene como funci�n principal calcular la circunferencia de centro
el punto medio de la diagonal de un rect�ngulo que el usuario ha determinado
introduciendo las coordenadas de dos de sus v�rtices (el de la esquina superior
izquierda y el de la esquina inferior derecha). Como datos de salida se 
muestran el �rea del rect�ngulo dado y las caracter�sticas de la circunferencia
que se quer�a hallar (la primera con centro el punto medio de la diagonal del
rect�ngulo cuyo �rea es mayor que la del rect�ngulo): su centro, su radio y
su �rea.

Para realizar este ejercicio he creado tres datos de tipo struct que han sido
Punto2D, Rectangulo y Circunferencia. Una vez establecidos, he creado tres
funciones que se encargan de hallar el punto medio de la diagonal del 
rect�ngulo, el �rea de un rect�ngulo y el �rea de una circunferencia. El resto
est� explicado en los comentarios intercalados del programa.
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recursos de E/S
#include <cmath> // Inclusi�n de los recursos matem�ticos

using namespace std;

// Se necesitan tres registros, pues hay tres tipos de datos que se usan en
// este programa

// 1. Un punto bidimensional

struct Punto2D {
	
	double abscisa;
	double ordenada;
};

// 2. Un rect�ngulo

struct Rectangulo {
	
	Punto2D punto_1; // Coordenada superior izquierda
	Punto2D punto_2; // Coordenada inferior derecha
};

// 3. Una circunferencia

struct Circunferencia {
	
	Punto2D centro; // El punto media de la diagonal que se calcula
	double radio; // El radio de la circunferencia
};

// Ahora se crean las funciones necesarias, que son tres

// 1. C�lculo del punto medio de la diagonal de un rect�ngulo dados dos puntos

Punto2D PuntoMedio (Rectangulo rectangulo){
	
	Punto2D punto_medio;
	
	punto_medio.abscisa = 
	(rectangulo.punto_1.abscisa + rectangulo.punto_2.abscisa)/2;
	
	punto_medio.ordenada = 
	(rectangulo.punto_1.ordenada + rectangulo.punto_2.ordenada)/2;
	
	return (punto_medio);
}

// 2. C�lculo del �rea del rect�ngulo 

double AreaRectangulo (Rectangulo rectangulo){
	
	double base;
	double altura;
	double resultado; // �rea del rect�ngulo
	
	base = rectangulo.punto_2.abscisa - rectangulo.punto_1.abscisa;
	altura = rectangulo.punto_1.ordenada - rectangulo.punto_2.ordenada;
	resultado = base * altura;
	
	return (resultado);
}

// 3. C�lculo del �rea de la circunferencia

double AreaCircunferencia (Circunferencia circunferencia){
	
	const double PI = 6 * asin(0.5);
	double resultado; // �rea de la circunferencia
	
	resultado = PI*circunferencia.radio*circunferencia.radio;
	
	return (resultado);
}

int main() // Programa principal
{
	// Declaraci�n de datos
	
	const double RADIO_INICIAL = 0.5;
	const double SALTO = 0.25;
	Rectangulo rectangulo;
	Circunferencia circunferencia;
	double radio = RADIO_INICIAL;
	double area_rectangulo;
	double area_circunferencia;
	
	// Entrada de datos
	
	cout << "Introduzca la coordenada x del v�rtice superior izquierdo de su"
	<< " rect�ngulo: ";
	cin >> rectangulo.punto_1.abscisa;
	cout << "Introduzca la coordenada y del v�rtice superior izquierdo de su"
	<< " rect�ngulo: ";
	cin >> rectangulo.punto_1.ordenada;
	
	// Hay que establecer filtros para el v�rtice inferior derecho, ya que 
	// su coordenada x debe ser mayor que la del v�rtice superior izquierdo
	// y su coordenada y debe ser menor que la del v�rtice superior izquierdo
	
	do{
		cout << "Introduzca la coordenada x del v�rtice inferior derecho de su"
		<< " rect�ngulo: ";
		cin >> rectangulo.punto_2.abscisa;
	}
	while (rectangulo.punto_2.abscisa <= rectangulo.punto_1.abscisa);


	do{
		cout << "Introduzca la coordenada y del v�rtice inferior derecho de su"
		<< " rect�ngulo: ";
		cin >> rectangulo.punto_2.ordenada;
	}
	while (rectangulo.punto_2.ordenada >= rectangulo.punto_1.ordenada);
	
	// Una vez ya se tienen los dos v�rtices del rect�ngulo, se halla el punto
	// medio de su diagonal (el cual ser� el centro de la circunferencia a
	// hallar) y su �rea
	
	circunferencia.centro = PuntoMedio (rectangulo);
	area_rectangulo = AreaRectangulo (rectangulo);
	
	// Como ya tenemos el centro de la circunferencia y el �rea del rect�ngulo,
	// hallaremos mediante un bucle la primera circunferencia con ese centro
	// cuyo �rea es mayor que la del rect�ngulo. El bucle finalizar� cuando
	// el �rea calculada es mayor que la del rect�ngulo.
	
	area_circunferencia = AreaCircunferencia (circunferencia);
	
	while (area_circunferencia <= area_rectangulo){
		
		circunferencia.radio = radio;
		area_circunferencia = AreaCircunferencia (circunferencia);
		
		// Actualizamos el valor del radio
		
		radio = radio + SALTO;
	}
	
	// Salida de datos
	
	cout << endl;
	cout << "El �rea del rect�ngulo es " << area_rectangulo;
	cout << endl;
	cout << "La circunferencia de centro (" << circunferencia.centro.abscisa
	<< "," << circunferencia.centro.ordenada << "), de radio "
	<< circunferencia.radio << " y de �rea " << area_circunferencia 
	<< " es la que busc�bamos";
	
	return 0;
}
	
		


