/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa se encarga de hallar los primos menores o iguales que un n�mero
natural introducido por el usuario. Para lograr esto, se comienza eliminando
los m�ltiplos de 2, los de 3, los de 5 y as� sucesivamente hasta llegar al
n�mero que se hab�a introducido. Este es un famoso m�todo de b�squeda de primos
que usaba Eratostenes.

En mi caso, he usado la funci�n LeeEnteroEnRango para asegurarme de que el 
usuario introduce un n�mero natural (mayor o igual que 1) y menor o igual que
el l�mite de 5000, que es el que se suger�a en el enunciado. El resto est�
explicado en los comentarios intercalados.
*/
/*****************************************************************************/

#include <iostream>
#include <iomanip>

using namespace std;

/*****************************************************************************/

int LeeEntero(string titulo){
	
	string entrada;
	string salida;
	bool es_entero;
	
	// El bucle no termina hasta que el valor introducido sea entero
	
	do{
		
		salida = "";
		
		cout << titulo;
		getline(cin,entrada);
		
		es_entero = true;
		
		int i = 0;
		
		// Se comprueban las posiciones de la cadena introducida hasta que 
		// llega al final 
		
		while (i < entrada.length()){
			
			// En caso de que el caracter en la posici�n i no sea ni un 
			// numero ni un espacio
			
			if (!isdigit(entrada.at(i)) && !isspace(entrada.at(i))) {
				
				//En caso de que el numero sea negativo
				
				if ((entrada.at(i) == '-') && (salida.length() == 0) && 
					isdigit(entrada.at(i+1))) {
					
					salida.push_back(entrada.at(i));
					
				}
				
				else{
					
					es_entero = false;
					i = entrada.length();
						 
				}
				
			}
			
			// En caso de que el caracter en la posici�n i sea un n�mero
			
			else{
					
					salida.push_back(entrada.at(i));
					
			}
			
			i++;	
		}
		
		//Si la cadena de salida est� vacia, se vuelve a pedir un entero
		
		if (salida.length() == 0){
		
			es_entero = false;
				
		}
		
		cout << endl;
		
	}while (!es_entero);
	
	//Se devuelve un valor entero
	
	return (stoi(salida));
}

/*****************************************************************************/

int LeeEnteroEnRango (string titulo, int menor, int mayor){
	
	int resultado;
	
	do {
		
		resultado = LeeEntero(titulo);
	
	} while ((resultado < menor) || (resultado > mayor));
	
	return (resultado);
}

int main() // Programa principal
{
	// Declaraci�n de datos
	
	int n; // Es el natural que introduce el usuario
	const int MAX_PRIMO = 5000; // No se admitir�n naturales mayores que 5000
	int naturales[MAX_PRIMO];
	bool es_primo[MAX_PRIMO];
	
	// Entrada de datos
	
	n = LeeEnteroEnRango ("Introduzca un natural: ", 1, MAX_PRIMO);
	
	// Inicializaci�n de los vectores con los que se va a trabajar: naturales
	// y es_primo
	
	for (int i = 0; i < n; i++){
		
		// En el vector naturales se introducen todos los naturales menores
		// o iguales que n. Como cada posici�n contiene a un natural de valor
		// una unidad mayor que el de la posici�n, cada posici�n tendr� i + 1
		
		naturales[i] = i + 1;
		
		// En el vector es_primo solo inicializaremos todos los datos como 
		// true, de los cuales pasar�n a ser false los que no se correspondan
		// con n�meros primos
		
		es_primo[i] = true;
	}
	
	// Como 1 es primo y todos los n�meros son m�ltiplos de 1, el bucle 
	// siguiente comenzar� con i = 1, pues si no, se quedar�an todos los
	// datos de es_primo como false
	
	int i = 1;
	
	while (naturales[i]*naturales[i] < n){
		
		if (es_primo[i]){
			
			// Empezamos viendo si el natural siguiente de la posici�n i es
			// divisible por el de la posici�n i, de ah� que j = i + 1
			
			for (int j = i + 1; j<n; j++){
				
				bool es_divisible;
				es_divisible = naturales[j]%naturales[i] == 0;
				
				if (es_divisible){
					
					es_primo[j] = false;
				}
			}
		}
		
		// Actualizamos la posici�n una vez que se ha tachado todos los 
		// m�ltiplos de naturales[i] menores o iguales que n y se repite
		// el proceso
		
		i++;		
	}
	
	// Una vez tenemos determinados los primos, creamos el vector de salida que
	// se llamar� primos y tendr� capacidad MAX_PRIMO
	
	int primos[MAX_PRIMO];
	int total_utilizados = 0;
	
	// Copiamos los enteros menores que n que son primos del vector naturales
	// en el vector primos
	
	for (int i = 0; i<n; i++){
		
		if (es_primo[i]){
			
			primos[total_utilizados] = naturales [i];
			total_utilizados++;
		}
	}
	
	// Salida de datos
	
	cout << "Los primos menores o iguales que " << n << " son: ";
	
	for (int i = 0; i<total_utilizados; i++){
		
		cout << primos[i] << " ";
	}
	
	return 0;
}
