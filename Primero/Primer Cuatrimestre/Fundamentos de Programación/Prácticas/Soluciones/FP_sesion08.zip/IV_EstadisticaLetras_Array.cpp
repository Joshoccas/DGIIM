/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa realiza una serie de estad�sticas sobre una cantidad 
indeterminada de caracteres que pueden ser letras, espacios u otro 
tipo de caracteres. La condici�n de parada del programa es que lea
un '*'.

Concretamente, los datos que el prograa calcula son:

1. El n�mero de caracteres totales le�dos.
2. El n�mero de espacios le�dos.
3. El n�mero de caracteres de otro tipo le�dos.
4. El n�mero de letras le�das.
5. Las letras que han aparecido y las veces que lo han hecho.
6. El n�mero de letras que no han aparecido y cu�les han sido.
7. La letra que m�s ha aparecido y las veces que lo ha hecho.
8. La letra que menos ha aparecido y las veces que lo ha hecho.
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recursos de E/S
#include <string>

using namespace std;

int main() // Programa principal
{
	// Declaraci�n de datos
	
	const int TAMAGNIO = 2500000;
	char texto[TAMAGNIO];
	const char TERMINADOR = '*';
	
	// El vector letras tendr� capacidad 26, y cada casilla almacenar� el
	// n�mero que ha aparecido cada letra del abecedario
	
	const int LETRAS = 'Z' - 'A' + 1;
	int letras[LETRAS];
	
	// El dato de tipo char letra me permitir� saber a qu� letra nos estamos
	// refiriendo habiendo dado la posici�n i
	
	char letra;
	
	// Creaci�n contadores
	
	int cont_letras = 0;
	int espacios = 0;
	int otros = 0;
	int caracteres_totales = 0;
	int no_encontradas = 0;
	
	// Entrada de datos
	
	cout << "Introduzca un texto cualquiera: ";
	
	bool caracteres_bien = true;
	
	for(int i = 0; caracteres_bien; i++){
		
		// En este caso se usa cin.get() ya que con cin no se pueden leer
		// separadores. Con cin.get() iremos leyendo car�cter a car�cter 
		// que se ir� almacenando en cada casilla del vector texto, hasta
		// que se lea un *
		
		texto[i] = cin.get();
		
		if (texto[i] != TERMINADOR){
			
			caracteres_totales++;
			
			bool es_letra = ((texto[i] >= 'a') && (texto[i] <= 'z')) ||
			((texto[i] >= 'A') && (texto[i] <= 'Z'));
			
			if (es_letra || (texto[i] == ' ')){
				
				if(es_letra){
					
					// Si es una letra el car�cter de la posici�n i, se 
					// actualiza el contador
					
					cont_letras++;
					
					// Nos aseguramos de que sea may�scula
					
					texto[i] = toupper(texto[i]);
					
					// Ahora comprobamos de qu� letra se trata para sumarle
					// una unidad a su contador de apariciones
					
					for(int j = 0; j < LETRAS; j++){
						
						if(texto[i] == 'A' + j){
							
							letras[j]++;
						}
					}
				}
				
				else{
					
					espacios++;
				}
			}
			
			else{
				
				// En caso de que el car�cter le�do no sea una letra ni un
				// espacio, sumamos 1 al contador de otro tipo de caracteres
				
				otros++;
			}
		}
		
		else{
			
			// Cuando se lea un car�cter *, la condici�n del bucle pasa a ser
			// falsa y as� termina el recuento de letras
			
			caracteres_bien = false;
		}
	}
	
	// A continuaci�n se determinan cu�ntas letras no han aparecido en el texto
	
	for(int i = 0; i < LETRAS; i++){
		
		if(letras[i] == 0){
			
			no_encontradas++;
		}
	}
	
	// Ahora determinamos qu� letra es la m�s frecuente y cu�l la menos 
	// frecuente
	
	int menos_frecuente = 0;
	int mas_frecuente = 0;
	
	for(int i = 0; i < LETRAS; i++){
		
		if ((letras[menos_frecuente] > letras[i]) && (letras[i] != 0)){
			
			menos_frecuente = i;
		}
		
		if((letras[mas_frecuente] < letras[i])){
			
			mas_frecuente = i;
		}
	}
	
	// Como ya tenemos la posici�n del vector letras con menos y con m�s
	// apariciones, hallaremos de qu� letras se tratan sum�ndole a 'A' la
	// respectiva posici�n 
	
	char menos_frecuente_1;
	char mas_frecuente_1;
	
	menos_frecuente_1 = 'A' + menos_frecuente;
	mas_frecuente_1 = 'A' + mas_frecuente;
	
	// Salida de datos
	
	cout << endl;
	cout << "Se han le�do un total de " << caracteres_totales << " caracteres";
	
	cout << endl;
	cout << "Se han le�do un total de " << espacios << " espacios";
	
	cout << endl;
	cout << "Se han le�do un total de " << otros << " caracteres de otro tipo";
	
	cout << endl;
	cout << "Se han le�do un total de " << cont_letras << " letras";
	cout << endl;
	
	for(int i = 0; i < LETRAS; i++){
		
		if(letras[i] != 0){
			
			letra = 'A' + i;
			
			cout << letra << ": " << letras[i] << " apariciones";
			cout << endl;
		}
	}
	
	cout << "No han aparecido " << no_encontradas << " letras: ";
	
	for(int i = 0; i < LETRAS; i++){
		
		if(letras[i] == 0){
			
			letra = 'A' + i;
			
			cout << letra << " ";
		}
	}
	
	cout << endl;
	cout << "La letra m�s frecuente ha sido la " << mas_frecuente_1 
	<< " con " << letras[mas_frecuente] << " apariciones";
	
	cout << endl;
	cout << "La letra menos frecuente ha sido la " << menos_frecuente_1
	<< " con " << letras[menos_frecuente] << " apariciones";
	
	return 0;
}
