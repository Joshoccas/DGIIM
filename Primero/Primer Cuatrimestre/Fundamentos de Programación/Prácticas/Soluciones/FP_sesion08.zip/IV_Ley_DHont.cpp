/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa nos permite calcular los esca�os que le corresponden a cada
partido en unas elecciones hipot�ticas con unos esca�os, partidos y votos
introducidos por el usuario. El algoritmo en el que se basa este programa 
es el conocido sistema D'Hondt, que consiste en lo siguiente:

       La asignaci�n de los esca�os se hace a trav�s de un proceso iterativo en 
	   el que en cada iteraci�n se asigna un esca�o a un partido y as� hasta 
	   llegar al n�mero total de esca�os a repartir. Se calculan cocientes 
	   sucesivos para cada partido pol�tico. La f�rmula de los cocientes es: 
	   cociente = Vi/(Si + 1) donde Vi es el n�mero total de votos obtenidos 
	   por el partido i y Si es el n�mero de esca�os que ha obtenido hasta
       el momento el partido i.
       
       El n�mero de votos recibidos por cada partido se divide sucesivamente 
	   por cada uno de los divisores, desde 1 hasta el n�mero total de esca�os 
	   a repartir. La asignaci�n de cada esca�o se determina hallando el m�ximo 
	   de los cocientes y asignando a cada uno un esca�o, hasta que estos se 
	   agoten.
	   
La forma en la que he implementado este sistema en el c�digo est� explicada
en los comentarios intercalados.
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recursos de E/S

using namespace std;

// Primero se crea el struct Partido

struct Partido {
	
	char sigla;
	long votos;
	int escagnos;
};

/*****************************************************************************/

int LeeEntero(string titulo){
	
	string entrada;
	string salida;
	bool es_entero;
	
	// El bucle no termina hasta que el valor introducido sea entero
	
	do{
		
		salida = "";
		
		cout << titulo;
		getline(cin,entrada);
		
		es_entero = true;
		
		int i = 0;
		
		// Se comprueban las posiciones de la cadena introducida hasta que 
		// llega al final 
		
		while (i < entrada.length()){
			
			// En caso de que el caracter en la posici�n i no sea ni un 
			// numero ni un espacio
			
			if (!isdigit(entrada.at(i)) && !isspace(entrada.at(i))) {
				
				//En caso de que el numero sea negativo
				
				if ((entrada.at(i) == '-') && (salida.length() == 0) && 
					isdigit(entrada.at(i+1))) {
					
					salida.push_back(entrada.at(i));
					
				}
				
				else{
					
					es_entero = false;
					i = entrada.length();
						 
				}
				
			}
			
			// En caso de que el caracter en la posici�n i sea un n�mero
			
			else{
					
					salida.push_back(entrada.at(i));
					
			}
			
			i++;	
		}
		
		//Si la cadena de salida est� vacia, se vuelve a pedir un entero
		
		if (salida.length() == 0){
		
			es_entero = false;
				
		}
		
		cout << endl;
		
	}while (!es_entero);
	
	//Se devuelve un valor entero
	
	return (stoi(salida));
}

/*****************************************************************************/

int LeeEnteroEnRango (string titulo, int menor, int mayor){
	
	int resultado;
	
	do {
		
		resultado = LeeEntero(titulo);
	
	} while ((resultado < menor) || (resultado > mayor));
	
	return (resultado);
}

/*****************************************************************************/

int main() // Programa principal
{
	// Declaraci�n de datos
	
	int escagnos_totales; // N�mero de esca�os a repartir
	int n; // N�mero de partidos
	
	// Entrada de datos
	
	escagnos_totales = LeeEnteroEnRango ("N�mero de esca�os: ", 1, 400);
	n = LeeEnteroEnRango ("N�mero de partidos: ", 2, 100);
	
	// Creaci�n del vector partidos
	
	Partido partidos[n];
	
	// Inicializaci�n de los distintos partidos con 0 esca�os, sus votos y
	// su respectiva sigla
	
	for(int i = 0; i < n; i++){
		
		partidos[i].escagnos = 0;
		
		// Empezamos nombrando por la sigla A
		
		partidos[i].sigla = '@' + (i + 1);
		
		cout << "Introduzca los votos obtenidos por el partido " << 
		partidos[i].sigla << ": ";
		cin >> partidos[i].votos;
	}
	
	int escagnos_repartidos = 0;
	double cocientes[n]; // En este vector se guardan los distintos cocientes
	
	while(escagnos_repartidos < escagnos_totales){
		
		// Calculamos los distintos cocientes
		
		for(int i = 0; i<n; i++){
			
			cocientes[i] = (partidos[i].votos)/(partidos[i].escagnos + 1);
		}
		
		// Se comparan los cocientes para determinar cu�l es el mayor
		// Se comienza comparando el primer cociente, por eso i = 0
		
		int i = 0;
		int cociente_max = 0;
		
		for(int j = i + 1; j < n; j++){
			
			if (cocientes[i] > cocientes[j]){
				
				cociente_max = i;
			}
			
			else{
				
				cociente_max = j;
				i = j; // El nuevo valor por el que se empieza a comparar 
				       // cocientes es j, ya que el cociente de la posici�n
				       // j es el m�ximo por el momento
			}
		}
		
		// Se aumenta en uno el n�mero de esca�os al partido con mayor cociente
		
		partidos[cociente_max].escagnos++;
		
		// Se aumenta en uno el n�mero de esca�os totales repartidos
		
		escagnos_repartidos++;
	}
	
	// Salida de datos
	
	cout << endl;
	cout << "El reparto de esca�os queda de la siguiente forma: ";
	
	for(int i = 0; i < n; i++){
		
		cout << endl;
		cout << "Partido " << partidos[i].sigla << " con "
		<< partidos[i].votos << " votos: " << partidos[i].escagnos 
		<< " esca�os";
	}
	
	return 0;
}

