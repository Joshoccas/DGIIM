/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa tiene como funci�n principal determinar cu�l ha sido la secuencia
creciente de temperaturas de mayor longitud de entre una serie de temperaturas
arbitrarias que son introducidas por el usuario. Al final del programa se 
muestra la m�xima secuencia creciente de temperaturas que ha habido, en qu�
d�a comenz�, en qu� d�a acab� y la duraci�n.

El resto est� explicado en los comentarios intercalados del programa.
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recursos de E/S

using namespace std;

int main() // Programa principal
{
	// Declaraci�n de datos
	
	const int MAX_DATOS = 100;
	double temperatura;
	int inicio = 0; // Inicializamos la posici�n de inicio y final de la
	int final = 0;  // primera secuencia en 0, pues empieza en 0
	int longitud;
	int inicio_max;   // Inicio de la secuencia ordenada m�xima
	int final_max;     // Final de la secuencia ordenada m�xima
	int longitud_max = 0; // Puede que se introduzca solo una temperatura, por
	                      // eso se inicializa con 0
	int total_utilizados = 0; // Casillas del vector ocupadas
	
	// Creamos el vector donde se almacenar�n las temperaturas
	
	double temperaturas[MAX_DATOS];
	
	// Entrada de datos
	
	cout << "Introduzca las temperaturas: ";
	
	do{
		
		cin >> temperatura;
		
		if (temperatura >= 0){
			
			temperaturas[total_utilizados] = temperatura;
			
			// Actualizamos total_utilizados ya que se ha ocupado una casilla
			
			total_utilizados++;
		}
	}
	while ((temperatura >= 0) && (total_utilizados < MAX_DATOS));
	
	// C�lculos
	
	for(int i = 0; i < total_utilizados; i++){
		
		if (temperaturas[i + 1] >= temperaturas[i]){
			
			// Si la temperatura siguiente es mayor que la actual, la 
			// secuencia aumenta una unidad de longitud, es decir, el final
			// pasa a ser la posici�n siguiente
			
			final = i + 1;
		}
		
		else{
			
			// En caso de que la secuencia creciente se haya roto, debemos
			// calcular su longitud y comprobar si es mayor que la longitud
			// de la �ltima secuencia creciente m�s grande. Si es mayor,
			// longitud_max, inicio_max y final_max cambian
			
			longitud = final - inicio;
			
			if (longitud >= longitud_max){
				
				longitud_max = longitud;
				inicio_max = inicio;
				final_max = final;
			}
			
			// En caso de que una secuencia creciente se haya roto, el inicio
			// pasar� a ser la posici�n siguiente a la que se est� valorando
			
			inicio = i + 1;
		}
	}
	
	// Salida de datos
	
	cout << "La secuencia ordenada creciente m�xima ha sido: ";
	
	for(int i = inicio_max; i <= final_max; i++){
		
		cout << temperaturas[i] << " ";
	}
	
	// En el mensaje de salida es necesario sumar 1 a longitud_max ya que la
	// diferencia entre inicio_max y final_max es una unidad menor que la
	// longitud real. Por ejemplo, si empez� en el d�a 2 y acab� en el d�a 5,
	// la longitud ser�a 4 y no 3, como indicar�a la diferencia 5 - 2
	
	cout << endl;
	cout << "Comenz� en el d�a " << inicio_max << ", termin� en el "
	<< "d�a " << final_max << " y dur� " << longitud_max + 1 << " d�a(s)";
	
	return 0;
	
}
