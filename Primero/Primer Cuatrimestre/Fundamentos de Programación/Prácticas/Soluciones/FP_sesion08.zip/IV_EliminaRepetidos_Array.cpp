/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa elimina los valores repetidos de una secuencia de n�meros 
introducida por el usuario. En esta versi�n (hubo dos anteriores con distintos
algoritmos al de esta), se ha implementado el algoritmo que usa dos apuntadores, 
pos_lectura y pos_escritura, que nos van indicando, en cada momento, la 
componente que se est� leyendo y el sitio d�nde tiene que escribirse.

Por ejemplo, supongamos que en un determinado momento la variable
pos_lectura vale 6 y pos_escritura 3. Si la componente en
la posici�n 6 est� repetida, simplemente avanzaremos posicion_lectura. Por
el contrario, no estuviese repetida, la colocaremos en la posici�n 3 y 
avanzaremos una posici�n ambas variables.
*/
/*****************************************************************************/

#include <iostream>
#include <iomanip>
using namespace std;

int main () // Programa principal
{
	cout.setf(ios::fixed);		// Notaci�n de punto fijo para los reales
	cout.setf(ios::showpoint);	// Mostrar siempre decimales 
	
	// Vector de datos
	
	const int MAX_DATOS = 50; 
	int datos[MAX_DATOS];
	
	int total_utilizados = 0;	

	// Lectura de los datos 
	
	bool sigo = true; 
	int dato; 
	
	cout << "Introduzca los valores del vector: ";
	cin >> dato;
	
	while ((dato>=0) && (sigo)) {

		datos[total_utilizados]	= dato;
		total_utilizados++;

		if (total_utilizados==MAX_DATOS) 
			sigo = false;
		else 
			cin >> dato;
	}
	
	// Se muestran los datos originales
	
	cout << endl;
	cout << "--------------------------------------------------------" << endl;
	cout << endl;	
 	cout << "Datos originales: " << "(" << setw(3) 
	 	 << total_utilizados << " datos): " << endl;	
	 	 
	for (int i=0; i<total_utilizados; i++) 
		cout << setw(3) << datos[i] << "  "; 
	cout << endl;
			
	cout << "--------------------------------------------------------" << endl;
	cout << endl;
	
	// VERSI�N 3: DOS APUNTADORES (UNO DE LECTURA Y OTRO DE ESCRITURA)
	
	int pos_lectura;
	int pos_escritura;
	
	// Comenzamos a comprobar los valores de la segunda posici�n del vector
	
	pos_lectura = 1;
	pos_escritura = 1;
	
	while (pos_lectura < total_utilizados){
		
		int valor_buscado = datos[pos_lectura];
		
		// Busco "valor_buscado" en el subvector izquierdo
		// (posiciones: 0 hasta "pos_lectura"-1)
		
		int pos = 0;
		bool encontrado = false;
		
		while ((pos < pos_lectura) && (!encontrado)){
			
			if (datos[pos] == valor_buscado){
	
				encontrado = true;
			}
			
			else{
				
				pos++;
			}
		}
		
		if (!encontrado){
			
			// Si el valor de la casilla en la que se encuentra posici�n
			// de lectura no est� repetido en las casillas anteriores, se
			// copia su valor en el de la casilla de la posici�n de 
			// escritura y pos_escritura aumenta en una unidad
			
			datos[pos_escritura] = datos[pos_lectura];
			pos_escritura++;
		}
		
		// La posici�n de lectura siempre se aumenta en una unidad 
		// independientemente de si el valor era repetido o no
		
		pos_lectura++;
	}
	
	cout << "Tras eliminar los repetidos, el vector queda as�: ";
	for(int i = 0; i < pos_escritura; i++){
		
		cout << setw(3) << datos[i] << "  "; 
	}
	
	return 0;
}
