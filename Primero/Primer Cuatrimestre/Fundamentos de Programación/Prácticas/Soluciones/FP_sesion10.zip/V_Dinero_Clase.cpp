/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa se encarga de mostrar la cantidad en euros y c�ntimos de la que
se dispone cada mes tras aplicar a una cantidad de euros y c�ntimos introducida
por el usuario un incremento fijo mensual (los meses tambi�n son indicados por
el usuario).
*/
/*****************************************************************************/

#include <iostream> 
#include <string>

using namespace std;

///////////////////////////////////////////////////////////////////////////////

// Creaci�n de la clase Dinero

class Dinero
{
	
	private:
		
		int euros;
		int centimos;
	
	public:
		
		// PRE: Los euros y c�ntimos deben ser 0 o cantidades positivas
		
		Dinero (int euros_intr, int centimos_intr) :
			euros (euros_intr), centimos (centimos_intr)
		{
			AjusteDinero (euros, centimos);
		}
			
		
		void Incrementar (double incremento)
		{
			centimos = centimos + (incremento - int(incremento))*100;
			euros = euros + int(incremento);
			
			AjusteDinero (euros, centimos);
		}
		
		string ToString (void)
		{
			string cad;
			
			cad = to_string(euros) + " euros y " + to_string(centimos) + 
			" c�ntimos";
			
			return(cad);
		}
		
	private:
		
		// Necesitamos un m�todo privado que se encargue de ajustar el dinero
		
		void AjusteDinero (int los_euros, int los_centimos)
		{
			centimos = los_centimos%100;
			euros = los_euros + los_centimos/100;
		}
		
};

///////////////////////////////////////////////////////////////////////////////

int LeeEntero(string titulo){
	
	string entrada;
	string salida;
	bool es_entero;
	
	// El bucle no termina hasta que el valor introducido sea entero
	
	do{
		
		salida = "";
		
		cout << titulo;
		getline(cin,entrada);
		
		es_entero = true;
		
		int i = 0;
		
		// Se comprueban las posiciones de la cadena introducida hasta que 
		// llega al final 
		
		while (i < entrada.length()){
			
			// En caso de que el caracter en la posici�n i no sea ni un 
			// numero ni un espacio
			
			if (!isdigit(entrada.at(i)) && !isspace(entrada.at(i))) {
				
				//En caso de que el numero sea negativo
				
				if ((entrada.at(i) == '-') && (salida.length() == 0) && 
					isdigit(entrada.at(i+1))) {
					
					salida.push_back(entrada.at(i));
					
				}
				
				else{
					
					es_entero = false;
					i = entrada.length();
						 
				}
				
			}
			
			// En caso de que el caracter en la posici�n i sea un n�mero
			
			else{
					
					salida.push_back(entrada.at(i));
					
			}
			
			i++;	
		}
		
		//Si la cadena de salida est� vacia, se vuelve a pedir un entero
		
		if (salida.length() == 0){
		
			es_entero = false;
				
		}
		
		cout << endl;
		
	}while (!es_entero);
	
	//Se devuelve un valor entero
	
	return (stoi(salida));
}

/*****************************************************************************/

 int LeeEnteroMayorOIgual (string titulo, int referencia){

 	int numero;

 	do{
 		numero = LeeEntero (titulo);
 	}
 	while (numero < referencia);
 	
 	return (numero);
 }
 
/*****************************************************************************/

int main() // Programa principal
{
	// Declaraci�n de datos
	
	int meses;
	double incremento;
	int euros;
	int centimos;
	
	// Entrada de datos con filtros
	
	euros = LeeEnteroMayorOIgual ("Introduzca los euros: ", 0);
	centimos = LeeEnteroMayorOIgual ("Introduzca los c�ntimos: ", 0);
	meses = LeeEnteroMayorOIgual ("Introduzca los meses de incremento: ", 1);
	
	do{
		cout << "Introduzca el incremento fijo a aplicar: ";
		cin >> incremento;
	}
	while (incremento <= 0);
	
	// Creaci�n del objeto 
	
	Dinero dinero (euros, centimos);
	
	cout << endl;
	
	for(int i = 0; i < meses; i++){
		
		dinero.Incrementar (incremento);
		cout << dinero.ToString() << " en el mes " << i + 1;
		cout << endl;
	}
	
	return 0;
}
	
