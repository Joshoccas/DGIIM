/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa se encarga de, dados dos instantes en segundos, minutos y horas,
hallar el instante de diferencia entre dichos instantes en horas, minutos y
segundos. Tambi�n calcula dicha diferencia en segundos totales y en minutos
totales.
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recursos de E/S
#include <string> 

using namespace std;

///////////////////////////////////////////////////////////////////////////////

// Creaci�n de la clase Instante

class Instante
{
	private:
		
		int horas;
		int minutos;
		int segundos;
	
	public:
		
		// Se crean 2 constructores: el primero es el que se utiliza para los
		// instantes inicial y final, mientras que el segundo se utiliza para
		// la creaci�n del instante diferencia a partir de la diferencia en
		// segundos entre los dos instantes introducidos
		
		Instante (int horas_intr, int minutos_intr, int segundos_intr) :
			horas (horas_intr), minutos (minutos_intr), segundos (segundos_intr)
		{}
		
		Instante (int segundos_totales) :
			
			horas (0), minutos (0), segundos(segundos_totales)
		
		{
			CalculoSegundosInstante (segundos_totales);
			CalculoMinutosInstante (segundos_totales);
			CalculoHorasInstante (segundos_totales);
		}
		
		string ToString (void)
		{
			string cad;
			
			cad = to_string(horas) + " h :" + to_string(minutos) + " m :"
			+ to_string(segundos) + " s";
			
			return(cad);
		}
		
		// Los m�todos p�blicos Segundos y Minutos calculan la cantidad de
		// segundos totales en un objeto instante a partir de sus datos
		// miembros y la cantidad de minutos totales respectivamente
		
		int Segundos (void)
		{
			int segundos_totales;
			
			segundos_totales = horas*3600 + minutos*60 + segundos;
			
			return(segundos_totales);
		}
		
		int Minutos (void)
		{
			int minutos_totales;
			
			minutos_totales = horas*60 + minutos + segundos/60;
			
			return(minutos_totales);
		}	
	
	private:
		
		// Los m�todos privados siguientes son usados por el constructor que
		// se encarga de inicializar los datos miembro del instante diferencia
		// a partir de la diferencia entre dos instantes dada en segundos. 
		// As�, un m�todo se encarga del c�lculo de los segundos en rango,
		// otro de los minutos en rango y otro de las horas en rango y 
		// asignan dicho c�lculo a los datos miembros del objeto que se crea
		
		void CalculoSegundosInstante (int segundos_totales)
		{
			int segs;
			segs = segundos_totales%60;
			
			segundos = segs;
		}
		
		void CalculoMinutosInstante (int segundos_totales)
		{
			int mins;
			mins = (segundos_totales/60)%60;
			
			minutos = mins;
		}
		
		void CalculoHorasInstante (int segundos_totales)
		{
			int hrs;
			hrs = (segundos_totales/60)/60;
			
			horas = hrs;
		}
		
};

///////////////////////////////////////////////////////////////////////////////

int LeeEntero(string titulo){
	
	string entrada;
	string salida;
	bool es_entero;
	
	// El bucle no termina hasta que el valor introducido sea entero
	
	do{
		
		salida = "";
		
		cout << titulo;
		getline(cin,entrada);
		
		es_entero = true;
		
		int i = 0;
		
		// Se comprueban las posiciones de la cadena introducida hasta que 
		// llega al final 
		
		while (i < entrada.length()){
			
			// En caso de que el caracter en la posici�n i no sea ni un 
			// numero ni un espacio
			
			if (!isdigit(entrada.at(i)) && !isspace(entrada.at(i))) {
				
				//En caso de que el numero sea negativo
				
				if ((entrada.at(i) == '-') && (salida.length() == 0) && 
					isdigit(entrada.at(i+1))) {
					
					salida.push_back(entrada.at(i));
					
				}
				
				else{
					
					es_entero = false;
					i = entrada.length();
						 
				}
				
			}
			
			// En caso de que el caracter en la posici�n i sea un n�mero
			
			else{
					
					salida.push_back(entrada.at(i));
					
			}
			
			i++;	
		}
		
		//Si la cadena de salida est� vacia, se vuelve a pedir un entero
		
		if (salida.length() == 0){
		
			es_entero = false;
				
		}
		
		cout << endl;
		
	}while (!es_entero);
	
	//Se devuelve un valor entero
	
	return (stoi(salida));
}

/*****************************************************************************/

int LeeEnteroEnRango (string titulo, int menor, int mayor){
	
	int numero;
	
	do{
		numero = LeeEntero (titulo);
	}
	while ((numero < menor) || (numero > mayor));
	
	return (numero);
}

/*****************************************************************************/

int main() // Programa principal
{
	// Declaraci�n de datos
	
	int horas1;
	int minutos1;
	int segundos1;
	int horas2;
	int minutos2;
	int segundos2;
	int diferencia_en_segundos;
	
	// Entrada de datos con filtros
	
	horas1 = LeeEnteroEnRango ("Horas del 1er instante: ",0,23);
	minutos1 = LeeEnteroEnRango ("Minutos del 1er instante: ",0,59);
	segundos1 = LeeEnteroEnRango ("Segundos del 1er instante: ",0,59);
	
	horas2 = LeeEnteroEnRango ("Horas del 2o instante: ",0,23);
	minutos2 = LeeEnteroEnRango ("Minutos del 2o instante: ",0,59);
	segundos2 = LeeEnteroEnRango ("Segundos del 2o instante: ",0,59);
	
	// Creaci�n de los objetos instante1 e instante2
	
	Instante instante1 (horas1, minutos1, segundos1);
	Instante instante2 (horas2, minutos2, segundos2);
	
	// C�lculos
	
	diferencia_en_segundos = abs(instante1.Segundos() - instante2.Segundos());
	
	// Creaci�n del objeto instante_diferencia
	
	Instante instante_diferencia (diferencia_en_segundos);
	
	// Salida de datos
	
	cout << "Instante de diferencia: " << instante_diferencia.ToString();
	cout << endl;
	cout << "Segundos del instante: " << instante_diferencia.Segundos();
	cout << endl;
	cout << "Minutos del instante: " << instante_diferencia.Minutos();
	
	return 0;
}
	
	
