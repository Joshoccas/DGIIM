/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa se encarga de proporcionar un login como sugerencia al usuario
a partir de su nombre, apellidos y el n�mero de caracteres que el usuario 
desea utilizar de su nombre y cada apellido. Por ejemplo:

    Nombre y apellidos: David Moreno Rodr�guez
    N�mero de caracteres a coger: 3
    Login sugerido: davmorrod
    
En caso de que el n�mero de caracteres sea mayor que el del nombre o apellidos,
se toma la palabra entera. Por ejemplo:

    Nombre y apellidos: Ana L�pez Fern�ndez
    N�mero de caracteres a coger: 5
    Login sugerido: anal�pezfern�
    
El resto est� explicado en los comentarios intercalados.
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recursos de E/S
#include <string>
#include <cctype>

using namespace std;

///////////////////////////////////////////////////////////////////////////////

class Login
{
	private:
		
		int num_caracteres_a_coger;
	
	public:
		
		// Creamos el constructor de la clase
		
		Login (int n) :
			num_caracteres_a_coger (n)
		{}
		
		// Creamos el m�todo Codifica, que recibe una cadena string (nombre y
		// (apellidos del usuario) y a partir del dato miembro 
		// num_caracteres _a_coger, devuelve una cadena string que ser�
		// el login sugerido
		
		string Codifica (string nombre)
		{
			string login = ""; // Variable local para devolver la cadena login
			
			int long_cad = nombre.length(); // Longitud del nombre
			
			int contador_copiados = 0;
			
			for (int pos_lectura = 0; pos_lectura < long_cad; pos_lectura++){
				
				if (!(isspace(nombre.at(pos_lectura))) && 
				contador_copiados < num_caracteres_a_coger){
					
					// Se a�ade el caracter en min�scula
					
					char c = tolower(nombre.at(pos_lectura));
					login.push_back(c); 
					
					contador_copiados++;
				}
				
				if (isspace(nombre.at(pos_lectura)))
					contador_copiados = 0;
			}
			
			return(login);
		}
};

///////////////////////////////////////////////////////////////////////////////

int LeeEntero(string titulo){
	
	string entrada;
	string salida;
	bool es_entero;
	
	// El bucle no termina hasta que el valor introducido sea entero
	
	do{
		
		salida = "";
		
		cout << titulo;
		getline(cin,entrada);
		
		es_entero = true;
		
		int i = 0;
		
		// Se comprueban las posiciones de la cadena introducida hasta que 
		// llega al final 
		
		while (i < entrada.length()){
			
			// En caso de que el caracter en la posici�n i no sea ni un 
			// numero ni un espacio
			
			if (!isdigit(entrada.at(i)) && !isspace(entrada.at(i))) {
				
				//En caso de que el numero sea negativo
				
				if ((entrada.at(i) == '-') && (salida.length() == 0) && 
					isdigit(entrada.at(i+1))) {
					
					salida.push_back(entrada.at(i));
					
				}
				
				else{
					
					es_entero = false;
					i = entrada.length();
						 
				}
				
			}
			
			// En caso de que el caracter en la posici�n i sea un n�mero
			
			else{
					
					salida.push_back(entrada.at(i));
					
			}
			
			i++;	
		}
		
		//Si la cadena de salida est� vacia, se vuelve a pedir un entero
		
		if (salida.length() == 0){
		
			es_entero = false;
				
		}
		
		cout << endl;
		
	}while (!es_entero);
	
	//Se devuelve un valor entero
	
	return (stoi(salida));
}

/*****************************************************************************/

 int LeeEnteroMayorOIgual (string titulo, int referencia){

 	int numero;

 	do{
 		numero = LeeEntero (titulo);
 	}
 	while (numero < referencia);
 	
 	return (numero);
 }
 
 /****************************************************************************/

int main() // Programa principal
{
	// Declaraci�n de datos
	
	string nombre_completo;
	int n; // Es el n�mero de caracteres a coger
	
	// Entrada de datos
	
	do{
		cout << "Introduzca su nombre y apellidos: ";
		getline (cin, nombre_completo);
	}
	while (nombre_completo.length()==0);
	
	n = LeeEnteroMayorOIgual ("Introduzca n�mero de caracteres: ", 1);
	
	// Creaci�n del objeto 
	
	Login login (n);
	
	// Salida de datos
	
	cout << endl;
	cout << "Nombre y apellidos: " << nombre_completo << endl;
	cout << endl;
	cout << "N�mero de caracteres a coger = " << n;
	cout << endl;
	cout << "Login sugerido: " << login.Codifica(nombre_completo);
	cout << endl;
	
	return 0;
}
