/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa consiste en un lector de n�meros enteros y n�meros reales que 
no deja pasar a cualquier otro tipo de entrada. Para lograrlo, se han 
definido una serie de m�todos para cada lectura (entero o real), as�
como tambi�n para la lectura de enteros o reales en un rango predeterminado
o mayores que una referencia. Para probar el lector al usuario se le pide:

LECTURA DE ENTEROS

       1. Se solicita una temperatura entera y se muestra solo cuando esta
       es v�lida.
       
       2. Se solicitan horas, minutos y segundos, que deben estar entre 0 y
       23, 0 y 59 y 0 y 59 respectivamente. Solo se mostrar� la hora cuando
       los tres datos sean enteros y est�n en rango.
       
       3. Se solicita un ingreso de dinero, que debe ser 0 o mayor, pues no
       existe dinero negativo, y se muestra el ingreso si es entero y mayor
       o igual que 0.

LECTURA DE REALES

       1. Se solicita una temperatura real (con decimales) y se muestra solo
       cuando realmente se ha introducido un dato correcto.
       
       2. Se solicita una nota de un examen cualquiera, la cual puede ser
       un real y siempre est� entre 0 y 10. Solo se mostrar� en pantalla
       cuando sea real y est� en rango.
       
       3. Se solicita un ingreso de dinero, que debe ser 0 o mayor, ya que
       no existe dinero negativo, y se muestra el ingreso si es un dato real
       y mayor o igual que 0.
*/
/*****************************************************************************/

#include <iostream>    //Inclusi�n de los recursos de E/S
#include <string>

using namespace std;  

///////////////////////////////////////////////////////////////////////////////

// Creaci�n de la clase Lector

class Lector
{
	private:
		
		string titulo;
	
	public:
		
		// Creamos el constructor de nuestra clase
		
		Lector (string cad) :
			titulo (cad)
		
		{}
		
		// El m�todo SetTitulo nos servir� para cambiar el dato miembro titulo
		// de un lector que necesite pedir varios datos
		
		void SetTitulo (string cad)
		{
			titulo = cad;
		}
		
		/*********************************************************************/
		
		// Creaci�n de m�todos para la lectura de enteros
		
		bool EsEntero (string cad)
		{
			int posicion = 0;
			
			if ((cad.at(posicion) == '-') || (cad.at(posicion) == '+')){
				
				posicion++;
			}
			
			bool entero_bien = true;
			char caracter;
			
			while (entero_bien && (posicion < cad.length())){
				
				caracter = cad.at(posicion);
				
				entero_bien = ((caracter >= '0') && (caracter <= '9'));
				
				posicion++;
			}
			
			return(entero_bien);
		}
		
		int LeeEntero (void)
		{
			string numero;
			bool cadena_bien;
			
			do{
				
				cout << titulo;
				getline(cin, numero);
				
				cadena_bien = EsEntero(numero);
			}
			while (!cadena_bien);
			
			return(stoi(numero));
		}
		
		int LeeEnteroEnRango (int menor, int mayor)
		{
			int numero;
			
			do{
				numero = LeeEntero();
			}
			while ((numero < menor) || (numero > mayor));
			
			return(numero);
		}
		
		int LeeEnteroMayorOIgual (int referencia)
		{
			int numero;
			
			do{
				numero = LeeEntero();
			}
			while (numero < referencia);
			
			return(numero);
		}
		
		/*********************************************************************/
		
		// Creaci�n de m�todos para la lectura de reales
		
	    bool EsDouble (string cad)
	    {

		    int posicion = 0;           
		    char caracter; 
								  
		    bool double_bien = true;

	
		    if(cad.at(0) == '-' || cad.at(0) == '+'){   
		
		        posicion++;  
	    	}
		
		    if (cad.at(0) == '.')
			    double_bien = false;

		    int contador_comas = 0;
		
		    while(double_bien && (posicion < cad.length())){
		
		 	    caracter = cad.at(posicion);
		 	
		 	    double_bien = (((caracter >= '0') && (caracter <= '9')) 
			    || caracter == '.');
		 	
		 	    if (caracter == '.')
		 		    contador_comas++;
		 	
		 	    if (contador_comas >= 2)
		 		    double_bien = false;
		 	
		 	
			    posicion++;
		    }
	
		    return (double_bien); 	
	    }
	
	    double LeeDouble (void)
	    {
		    string numero;
		    bool cadena_bien;
			
		    do{
				
			    cout << titulo;
			    getline(cin, numero);
				
			    cadena_bien = EsDouble(numero);
		    }
		    while (!cadena_bien);
			
		    return(stod(numero));
	    }
	
	    double LeeDoubleEnRango (double menor, double mayor)
	    {
	        double numero;
			
		    do{
			    numero = LeeDouble();
		    }
		    while ((numero < menor) || (numero > mayor));
	
		    return(numero);
	    }
		
	    double LeeDoubleMayorOIgual (double referencia)
	    {
		    double numero;
			
		    do{
			    numero = LeeDouble();
		    }
		    while (numero < referencia);
			
		    return(numero);
	    }
		
};

/*****************************************************************************/

int main() // Programa principal
{
	cout.setf(ios::fixed);        // Notaci�n de punto fijo
	cout.setf(ios::showpoint);    // Mostrar siempre decimales
	
	
	cout << "LECTURA DE ENTEROS";
	cout << endl;
	cout << endl;
	cout << "Lectura de un entero - APARTADO A";
	cout << endl;
	
	Lector lector_temp("Temperatura: ");
    int temp = lector_temp.LeeEntero();
    cout << "Temperatura leida = " << temp;
    cout << endl;
    cout << endl;
    
    /*************************************************************************/
    
    cout << "Lectura de enteros acotados superior e inferiormente - APARTADO B";
    cout << endl;
    
    int hora, minuto, segundo;
    string cad;
    
    Lector lector_hora(cad);
    
    lector_hora.SetTitulo ("Introduzca hora: ");
    hora = lector_hora.LeeEnteroEnRango (0, 23);
    
    
    lector_hora.SetTitulo ("Introduzca minuto: ");
    minuto = lector_hora.LeeEnteroEnRango (0, 59);
    
    
    lector_hora.SetTitulo ("Introduzca segundo: ");
    segundo = lector_hora.LeeEnteroEnRango (0, 59);
    
    
    cout << "Hora: " << hora << ":" << minuto << ":" << segundo << endl;
    cout << endl;
    
    /*************************************************************************/
    
    cout << "Lectura de un entero acotado inferiormente - APARTADO C";
    cout << endl;
    
    int ingreso;
    
    Lector lector_ingreso("Cantidad a ingresar: ");
    ingreso = lector_ingreso.LeeEnteroMayorOIgual (0);
    
    cout << "Valor del ingreso = " << ingreso << endl;
    cout << endl;
    
    /*************************************************************************/
    
    cout << "LECTURA DE REALES";
    cout << endl;
    cout << endl;
    cout << "Lectura de un real - APARTADO A";
    cout << endl;
    
    Lector lector_temp1("Temperatura: ");
    double temp1 = lector_temp1.LeeDouble();
    cout << "Temperatura leida = " << temp1;
    cout << endl;
    cout << endl;
    
    /*************************************************************************/
    
    cout << "Lectura de enteros acotados superior e inferiormente - APARTADO B";
    cout << endl;
    double nota;
    
    
    Lector lector_nota("Introduzca su nota obtenida en el examen: ");
    nota = lector_nota.LeeDoubleEnRango(0,10);
    
    cout << "Nota le�da = " << nota;
    cout << endl;
    cout << endl;
    
    /*************************************************************************/
    
    cout << "Lectura de un real acotado inferiormente - APARTADO C";
    cout << endl;
    
    double ingreso1;
    
    Lector lector_ingreso1("Cantidad a ingresar: ");
    ingreso1 = lector_ingreso1.LeeDoubleMayorOIgual (0);
    
    cout << "Valor del ingreso = " << ingreso1 << endl;
    cout << endl;
    
    return 0;
}
