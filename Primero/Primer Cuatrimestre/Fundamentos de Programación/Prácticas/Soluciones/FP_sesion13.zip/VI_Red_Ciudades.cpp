/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Programa que solicita un n�mero de ciudades y las distancias entre las mismas
para crear una matriz con esos datos y realizar 4 tareas:

	1. Halla la ciudad con m�s conexiones directas
	2. Calcula laa conexiones directas de una ciudad en concreto
	3. Halla cu�l es la ciudad intermedia que conecta mas cerca dos ciudades
	sin conexi�n
	4. Dada una serie de ciudades, determina si entre todas ellas existen
	conexiones directas o no 
*/
/*****************************************************************************/

#include <iostream>
#include <string>

using namespace std;

///////////////////////////////////////////////////////////////////////////////

class SecuenciaEnteros {

	private:

    	static const int TAMANIO = 40; // N�m.casillas disponibles
    	int vector_privado[TAMANIO];

    	// PRE: 0<=total_utilizados<TAMANIO

    	int total_utilizados; // N�m.casillas ocupadas

	public:

    	/*******************************************************************/
    	// Constructor sin argumentos

    	SecuenciaEnteros (void) : total_utilizados (0)
    	{}

    	/*******************************************************************/
    	// Devuelve el n�mero de casillas ocupadas

    	int TotalUtilizados (void)
    	{
        	return (total_utilizados);
    	}

    	/*******************************************************************/
    	// Devuelve el n�mero de casillas disponibles

    	int Capacidad (void)
    	{
        	return (TAMANIO);
    	}

    	/*******************************************************************/
    	// "Vac�a" completamente la secuencia

		void EliminaTodos()
		{
			total_utilizados = 0;
		}

    	/*******************************************************************/
    	// A�ade un elemento ("nuevo") al vector.
    	// PRE: total_utilizados < TAMANIO
    	// 		La adici�n se realiza si hay alguna casilla disponible.
    	// 		El nuevo elemento se coloca al final del vector.
    	// 		Si no hay espacio, no se hace nada.

    	void Aniade (int nuevo)
    	{
        	if (total_utilizados < TAMANIO){
            	vector_privado[total_utilizados] = nuevo;
            	total_utilizados++;
        	}	
    	}

    	/*******************************************************************/
    	// Devuelve el elemento de la casilla "indice"
    	// PRE: 0 <= indice < total_utilizados

    	int Elemento (int indice)
    	{
        	return (vector_privado[indice]);
    	}

    	/*******************************************************************/
    	// Cambia el contenido de la casilla "indice" por el valor "nuevo"
    	// PRE: 0 <= indice < total_utilizados

		void Modifica (int indice, int nuevo)
   		{
			if ((indice >= 0) && (indice < total_utilizados))
				vector_privado[indice] = nuevo;
   		}

    	/*******************************************************************/
    	// Eliminar el real de la posici�n dada por "indice".
    	// Realiza un borrado f�sico (desplazamiento y sustituci�n).
    	// PRE: 0 <= indice < total_utilizados

    	void Elimina (int indice)
    	{
        	if ((indice >= 0) && (indice < total_utilizados)) {

            	int tope = total_utilizados-1; // posic. del �ltimo

            	for (int i = indice ; i < tope ; i++)
                	vector_privado[i] = vector_privado[i+1];

            	total_utilizados--;
        	}
    	}
    
    	/*******************************************************************/
    	// Inserta el real "nuevo" en la posici�n dada por "indice".
    	// Desplaza todos los reales una posici�n a la derecha antes de 
		// copiar en "indice" en valor "nuevo".
		// PRE: 0 <= pos_insercion < total_utilizados
    	// PRE: total_utilizados < TAMANIO
    	// 		La inserci�n se realiza si hay alguna casilla disponible.
    	// 		Si no hay espacio, no se hace nada.
    
		void Inserta (int pos_insercion, int valor_nuevo)
		{
        	if ((pos_insercion >= 0) && (pos_insercion < total_utilizados) 
		   		 && (total_utilizados < TAMANIO)) {
		
				for (int i = total_utilizados; i > pos_insercion; i--)
					vector_privado[i] = vector_privado[i-1];
			
				vector_privado[pos_insercion] = valor_nuevo;
				total_utilizados++;		
			}
		}
		
		/*******************************************************************/
		// Representa mediante un dato string el estado del objeto. En este 
		// caso, muestra los elementos del vector dato miembro del objeto
		// dispuestos en una fila
		
		string ToString (void)
		{
			string cad;
			
			for (int i = 0; i < total_utilizados; i++){
				
				cad+= to_string(vector_privado[i]) + " ";
			}
			
			return(cad);
		}
};

///////////////////////////////////////////////////////////////////////////////

class SecuenciaReales {

	private:

    	static const int TAMANIO = 40; // N�m.casillas disponibles
    	double vector_privado[TAMANIO];

    	// PRE: 0<=total_utilizados<TAMANIO

    	int total_utilizados; // N�m.casillas ocupadas

	public:

    	/*******************************************************************/
    	// Constructor sin argumentos

    	SecuenciaReales (void) : total_utilizados (0)
    	{}

    	/*******************************************************************/
    	// Devuelve el n�mero de casillas ocupadas

    	int TotalUtilizados (void)
    	{
        	return (total_utilizados);
    	}

    	/*******************************************************************/
    	// Devuelve el n�mero de casillas disponibles

    	int Capacidad (void)
    	{
        	return (TAMANIO);
    	}

    	/*******************************************************************/
    	// "Vac�a" completamente la secuencia

		void EliminaTodos()
		{
			total_utilizados = 0;
		}

    	/*******************************************************************/
    	// A�ade un elemento ("nuevo") al vector.
    	// PRE: total_utilizados < TAMANIO
    	// 		La adici�n se realiza si hay alguna casilla disponible.
    	// 		El nuevo elemento se coloca al final del vector.
    	// 		Si no hay espacio, no se hace nada.

    	void Aniade (double nuevo)
    	{
        	if (total_utilizados < TAMANIO){
            	vector_privado[total_utilizados] = nuevo;
            	total_utilizados++;
        	}	
    	}

    	/*******************************************************************/
    	// Devuelve el elemento de la casilla "indice"
    	// PRE: 0 <= indice < total_utilizados

    	double Elemento (int indice)
    	{
        	return (vector_privado[indice]);
    	}

    	/*******************************************************************/
    	// Cambia el contenido de la casilla "indice" por el valor "nuevo"
    	// PRE: 0 <= indice < total_utilizados

		void Modifica (int indice, double nuevo)
   		{
			if ((indice >= 0) && (indice < total_utilizados))
				vector_privado[indice] = nuevo;
   		}

    	/*******************************************************************/
    	// Eliminar el real de la posici�n dada por "indice".
    	// Realiza un borrado f�sico (desplazamiento y sustituci�n).
    	// PRE: 0 <= indice < total_utilizados

    	void Elimina (int indice)
    	{
        	if ((indice >= 0) && (indice < total_utilizados)) {

            	int tope = total_utilizados-1; // posic. del �ltimo

            	for (int i = indice ; i < tope ; i++)
                	vector_privado[i] = vector_privado[i+1];

            	total_utilizados--;
        	}
    	}
    
    	/*******************************************************************/
    	// Inserta el real "nuevo" en la posici�n dada por "indice".
    	// Desplaza todos los reales una posici�n a la derecha antes de 
		// copiar en "indice" en valor "nuevo".
		// PRE: 0 <= pos_insercion < total_utilizados
    	// PRE: total_utilizados < TAMANIO
    	// 		La inserci�n se realiza si hay alguna casilla disponible.
    	// 		Si no hay espacio, no se hace nada.
    
		void Inserta (int pos_insercion, double valor_nuevo)
		{
        	if ((pos_insercion >= 0) && (pos_insercion < total_utilizados) 
		   		 && (total_utilizados < TAMANIO)) {
		
				for (int i = total_utilizados; i > pos_insercion; i--)
					vector_privado[i] = vector_privado[i-1];
			
				vector_privado[pos_insercion] = valor_nuevo;
				total_utilizados++;		
			}
		}
};

///////////////////////////////////////////////////////////////////////////////

class MapaDistancias
{

private:

    static const int NUM_FILS = 50; // Filas disponibles
    static const int NUM_COLS = 50; // Columnas disponibles
    
    double  matriz_privada[NUM_FILS][NUM_COLS];

    // PRE: 0 <= filas_utilizadas <= NUM_FILS
    // PRE: 0 <= col_utilizadas < NUM_COLS
    
    int filas_utilizadas;
    int cols_utilizadas;

public:

	/***********************************************************************/
	// Constructor sin argumentos (Matriz nula)

	MapaDistancias(void): filas_utilizadas(0), cols_utilizadas(0) {}
	
	/***********************************************************************/
	// Constructor con argumentos
	// Recibe "numero_de_columnas" que indica el n�mero de 
	// columnas que deben tener TODAS las filas. 
	// PRE: numero_de_columnas <= NUM_COLS

	MapaDistancias (int numero_de_columnas) : filas_utilizadas(0), 
		  cols_utilizadas(numero_de_columnas)
	{ }

	/***********************************************************************/
	// Constructor con argumentos 
	// Recibe una secuencia de reales. El n�mero de elementos
	// de la secuencia es el valor que se usa como "col_utilizadas"
	// PRE: primera_fila.TotalUtilizados() <= NUM_COLS

	MapaDistancias (SecuenciaReales primera_fila)
		: filas_utilizadas(0), cols_utilizadas (primera_fila.TotalUtilizados())
	{
		Aniade(primera_fila); // Actualiza "filas_utilizadas"
	}

	/***********************************************************************/
	// M�todo de lectura: n�mero m�ximo de filas

	int CapacidadFilas (void)
	{
		return (NUM_FILS);
	}

	/***********************************************************************/
	// M�todo de lectura: n�mero m�ximo de columnas

	int CapacidadColumnas (void)
	{
		return (NUM_COLS);
	}

	/***********************************************************************/
	// M�todo de lectura: n�mero real de filas usadas

	int FilasUtilizadas (void)
	{
		return (filas_utilizadas);
	}

	/***********************************************************************/
	// M�todo de lectura: n�mero real de columnas usadas

	int ColumnasUtilizadas (void)
	{
		return (cols_utilizadas);
	}

	/***********************************************************************/
	// M�todo de lectura: devuelve el dato que ocupa la casilla 
	// de coordenadas (fila, columna)
	// PRE: 0 <= fila < filas_utilizadas
	// PRE: 0 <= columna < cols_utilizadas	
	
	int Elemento (int fila, int columna)
	{
		return (matriz_privada[fila][columna]);
	}

	/***********************************************************************/
	// Devuelve true si la tabla est� vac�a

	bool EstaVacia (void)
	{
		return (filas_utilizadas == 0);
	}
	
	/*****************************************************************/
	// Devuelve una fila completa (un objeto "SecuenciaReales")
	// PRE: 0 <= indice_fila < filas_utilizadas
	
	SecuenciaReales Fila (int indice_fila)
	{
		SecuenciaReales fila;

		for (int col=0; col<cols_utilizadas; col++)
			fila.Aniade(matriz_privada[indice_fila][col]);

		return (fila);
	}

	/***********************************************************************/
	// Devuelve una columna completa (un objeto "SecuenciaReales")
	// PRE: 0 <= indice_columna < cols_utilizadas
	
	SecuenciaReales Columna (int indice_columna)
	{
		SecuenciaReales columna;

		for (int fil=0; fil<filas_utilizadas; fil++)
			columna.Aniade (matriz_privada[fil][indice_columna]);

		return (columna);
	}

	/***********************************************************************/
	// A�ade una fila completa (un objeto "SecuenciaReales")
	// PRE:  fila_nueva.TotalUtilizados() = cols_utilizadas
	// PRE:  filas_utilizadas < NUM_FILS
	
	void Aniade (SecuenciaReales fila_nueva)
	{
		int numero_columnas_fila_nueva = fila_nueva.TotalUtilizados();
					
		if ((filas_utilizadas < NUM_FILS) &&
			(numero_columnas_fila_nueva == cols_utilizadas)) {

			for (int col = 0; col < numero_columnas_fila_nueva; col++)
				matriz_privada[filas_utilizadas][col]=fila_nueva.Elemento(col);

			filas_utilizadas++;
		}
	}

	/***********************************************************************/
	// "Vac�a" una tabla

	void EliminaTodos (void)
	{
		filas_utilizadas = 0;
	}

	/***********************************************************************/
	// Elimina una fila completa, dada una posici�n. 
	// 
	// Recibe: num_fila, la posici�n de la fila a eliminar.
	// PRE:  0 <= num_fila < TotalUtilizados()
	
	void Elimina (int num_fila)
	{		
		// Precondiciones
		
		if ((0<=num_fila) && (num_fila <=filas_utilizadas)) {

			// "Desplazar" las filas hacia posiciones bajas. 
			// En la posici�n "num_fila" se copia la que est� en la posici�n
			// siguiente ("num_fila"+1), en su lugar se copia que est� en 
			// "num_fila"+2, ... y en la posici�n "total_utilizados"-2 se 
			// copia la de "total_utilizados"-1. 
			
			for (int fil=num_fila; fil<filas_utilizadas-1; fil++) {
			
				int num_columnas = cols_utilizadas;
					
				for (int c=0; c<num_columnas; c++) 
					matriz_privada[fil][c]=matriz_privada[fil+1][c];
			}
			
			filas_utilizadas--; // Actualizaci�n del tama�o de la tabla.
		}
	}
	
	/***********************************************************************/
	// M�todo que calcula el n�mero de ciudades conectadas a una ciudad dada
	// PRE: ciudad >= 0 && ciudad < cols_utilizadas
	// Recibe: int ciudad
	// Devuelve: int conexiones
	
	
	int Conexiones (int ciudad)
	{
		double conexiones = 0;
		
		for (int i = 0; i < cols_utilizadas; i++){
			
			if (matriz_privada[ciudad][i] > 0)
				conexiones++;
		}
		
		return (conexiones);
	}
	
	/***********************************************************************/
	// M�todo que halla qu� ciudad de una red de ciudades es la que presenta
	// m�s conexiones directas con el resto
	// Devuelve: int ciudad
	
	int MasConexiones (void)
	{
		// Inicializamos ciudad con la primera ciudad
		
		int ciudad = 0;
		
		// Recorremos cada fila (es decir, cada ciudad) y usamos el m�todo
		// Conexiones para calcular sus conexiones directas. El dato ciudad
		// se ir� actualizando seg�n se vayan encontrando ciudades con m�s
		// conexiones que la �ltima almacenada
		
		for (int i = 1; i < filas_utilizadas; i++)
			
			if (Conexiones(i) > Conexiones(ciudad))
				ciudad = i;
		
		return (ciudad);
	}
	
	/***********************************************************************/
	// M�todo que devuelve una secuencia de enteros cuyos elementos son los
	// �ndices de las ciudades conectadas con una dada
	// PRE: ciudad >= 0 && ciudad < cols_utilizadas
	// Recibe: int ciudad
	// Devuelve: SecuenciaEnteros ciudades
	
	SecuenciaEnteros CiudadesConectadas (int ciudad)
	{
		SecuenciaEnteros ciudades;
		
		for (int i = 0; i < cols_utilizadas; i++){
			
			if (matriz_privada[ciudad][i] > 0)
				ciudades.Aniade(i);
		}
		
		return (ciudades);
	}
	
	/***********************************************************************/
	// M�todo que halla la ciudad intermedia entre dos ciudades sin conexi�n
	// directa. Dicha ciudad intermedia es la que m�s corto hace el trayecto
	// de una ciudad a la otra
	// PRE: Elemento(ciudad1, ciudad2) = 0
	// Recibe: int ciudad1, int ciudad2
	// Devuelve: int intermedia
	
	int CiudadIntermedia (int ciudad1, int ciudad2){
		
		// En caso de que no se encuentre una ciudad intermedia, el m�todo 
		// devolver� un -1, por eso se inicializa con -1 desde el principio
		
		int intermedia = -1;
		
		double distancia;
		double distancia_min = 12000000;
		
		for (int i = 0; i < cols_utilizadas; i++){
			
			// Si la ciudad que se est� evaluando no es ninguna de las dos
			// introducidas y est� conectada a ambas, calculamos la distancia
			// entre ambas a partir de dicha ciudad
			
			if ((i != ciudad1) && (i != ciudad2)){
				
				if ((matriz_privada[i][ciudad1] > 0)
				&& (matriz_privada[i][ciudad2] > 0)){
					
					distancia = matriz_privada[i][ciudad1] 
					+ matriz_privada[i][ciudad2];
					
					// Si la distancia calculada es menor que la �ltima
					// distancia m�nima registrada, se actualiza la distancia
					// m�nima y el �ndice de la ciudad intermedia
					
					if (distancia < distancia_min){
						
						distancia = distancia_min;
						intermedia = i;
					}
				}
			}
		}
		
		return (intermedia);
	}
		
	/***********************************************************************/
	// M�todo que determina si un conjunto de ciudades est�n todas conectadas
	// entre s� o no
	// PRE: ciudades.TotalUtilizados() > 1
	// Recibe: SecuenciaEnteros ciudades
	// Devuelve: bool conectadas
	
	bool TodasConectadas (SecuenciaEnteros ciudades)
	{
		bool conectadas = true;
		
		for (int i = 0; i < ciudades.TotalUtilizados() && conectadas; i++){
			
			for (int j = 0; j < ciudades.TotalUtilizados() && conectadas; j++){
				
				if (i != j){
					
					conectadas = 
					(matriz_privada[ciudades.Elemento(i)][ciudades.Elemento(j)] 
					> 0);
				}
			}
		}	
					
		return (conectadas);
	}
};

//////////////////////////////////////////////////////////////////////////////

class Lector
{
	private:
		
		string titulo;
	
	public:
		
		// Constructor sin argumentos
		
		Lector (void) : titulo ("")
		{ }
		
		// Constructor con argumentos
		
		Lector (string cad) : titulo (cad)
		{ }
		
		// M�todo Set para fijar el campo "titulo"
		
		void SetTitulo (string cad)
		{
			titulo = cad;
		}
		
		/*********************************************************************/
		// Lee un dato int.
		// La lectura est� etiquetada con "titulo"
		// La lectura se efect�a repetidamente hasta que se introduce un valor
		// int correcto.
		
		int LeeEntero (void)
		{
			string cadena;
			
			do{
				cout << titulo;
				getline(cin, cadena);
			}
			while (!EsEntero(cadena));
			
			return (stoi(cadena));
		}
		
		/*********************************************************************/
		// Lee un dato int.
		// La lectura est� etiquetada con "titulo"
		// PRE: menor <= mayor
		// POST: menor <= valor devuelto <= mayor
		
		int LeeEnteroEnRango (int menor, int mayor)
		{
			int numero;
			
			do{
				
				numero = LeeEntero ();
			}
			while ((numero<menor) || (numero>mayor));
			
			return (numero);
		}
		
		/*********************************************************************/
		// Lee un dato int que debe ser mayor o igual que "menor" y lo devuelve.
		// La lectura est� etiquetada con "titulo"
		
		int LeeEnteroMayorOIgual (int menor)
		{
			int numero;
			
			do{
				numero = LeeEntero ();
			}
			while (numero < menor);
			
			return (numero);
		}
		
		/*********************************************************************/
		// Lee un dato double.
		// La lectura est� etiquetada con "titulo"
		// La lectura se efect�a repetidamente hasta que se introduce un valor
		// double correcto.
		
		double LeeReal (void)
		{
			string cadena;
			
			do{
				cout << titulo;
				getline(cin, cadena);
			}
			while (!EsReal(cadena));
			
			return (stod(cadena));
		}
		
		/*********************************************************************/
		// Lee un dato double.
		// La lectura est� etiquetada con "titulo"
		// PRE: menor <= mayor
		// POST: menor <= valor devuelto <= mayor
		
		double LeeRealEnRango (int menor, int mayor)
		{
			double numero;
			
			do{
				
				numero = LeeReal ();
			}
			while ((numero<menor) || (numero>mayor));
			
			return (numero);
		}

		/*********************************************************************/
		// Lee un dato double que debe ser mayor o igual que "menor" y lo 
		// devuelve. 
		// La lectura est� etiquetada con "titulo"
		
		double LeeRealMayorOIgual (int menor)
		{
			double numero;
			
			do{
				numero = LeeReal ();
			}
			while (numero < menor);
			
			return (numero);
		}

		/*********************************************************************/
	
	private:
		
		/*********************************************************************/
		// Devuelve una NUEVA cadena, resultante de eliminar los �ltimos
		// caracteres separadores de "cadena". Los caracteres separadores son
		// el espacio en blanco, el tabulador y el salto de l�nea.
		// Usaremos la funci�n isspace() para simplificar el c�lculo.
		//
		// Recibe: cadena, string sobre la que se va a trabajar.
		// Devuelve: el resultado de eliminar los �ltimos separadores de 
		// "cadena"
		/*********************************************************************/
		
		string EliminaUltimosSeparadores (string cadena)
		{
			while (cadena.length()>0 && isspace(cadena.back()))
				cadena.pop_back();
			
			return (cadena);
		}
		
		/*********************************************************************/
		// Devuelve una NUEVA cadena, resultante de eliminar los primeros
		// caracteres separadores de "cadena". Los caracteres separadores son
		// el espacio en blanco, el tabulador y el salto de l�nea.
		// Usaremos la funci�n isspace() para simplificar el c�lculo.
		//
		// Recibe: cadena, string sobre la que se va a trabajar.
		// Devuelve: el resultado de eliminar los �ltimos separadores de 
		// "cadena"
		/*********************************************************************/
		string EliminaPrimerosSeparadores (string cadena)
		{
			// Buscar el primer car�cter no espacio
			unsigned int pos = 0;
			while (pos < cadena.length() && isspace(cadena.at(pos))) pos++;
			
			string local;
			
			// Copiar todos los que quedan
			while (pos < cadena.length()) {
				local.push_back(cadena.at(pos));
				pos++;
			}
			
			return (local);
		}
		
		/*********************************************************************/
		// Devuelve una NUEVA cadena, resultante de eliminar los primeros 
		// �ltimos caracteres separadores de "cadena". Los caracteres 
		// separadores son el espacio en blanco, el tabulador y el salto de
		// l�nea
		//
		// Recibe: cadena, string sobre la que se va a trabajar.
		// Devuelve: el resultado de eliminar los primeros y los �ltimos
		//           separadores de "cadena".
		/*********************************************************************/
		
		string EliminaPrimerosYUltimosSeparadores (string cadena)
		{
			string cadena_podada = EliminaPrimerosSeparadores (cadena);
			cadena_podada = EliminaUltimosSeparadores (cadena_podada);
			
			return (cadena_podada);
		}
		
		/*********************************************************************/
		// Devuelve "true" si "cadena" es la representaci�n textual de un
		// entero
		//
		// Recibe: cadena, string sobre la que se va a trabajar.
		// Devuelve: "true" si "cadena" es la representaci�n textual de un int
		
		bool EsEntero (string cadena)
		{
			bool es_entero = true;
			
			cadena = EliminaPrimerosSeparadores (cadena);
			cadena = EliminaUltimosSeparadores (cadena);
			
			unsigned int long_cadena = cadena.length();
			
			if (long_cadena == 0) es_entero = false;
			else {
				
				// Si el primer car�cter es '+' � '-', perfecto. En ese caso
				// se pasa al siguiente car�cter (posici�n 19.
				
				unsigned int pos;
				if (cadena.at(0)=='-' || cadena.at(0) == '+') pos = 1;
				else pos = 0;
				
				while ((pos < long_cadena) && es_entero) {
					if(!isdigit(cadena.at(pos))) es_entero = false;
					else pos++;
				}
			}
			
			return (es_entero);
		}
		
		/*********************************************************************/

		bool EsReal (string cadena)
		{
			bool es_real = true;
			
			cadena = EliminaPrimerosSeparadores (cadena);
			cadena = EliminaUltimosSeparadores (cadena);
			
			unsigned int long_cadena = cadena.length();
			
			if (long_cadena == 0) es_real = false;
			else {
				
				// Si el primer car�cter es '+' � '-', perfecto. En ese caso
				// se pasa al siguiente car�cter (posici�n 19.
				
				unsigned int pos;
				if (cadena.at(0)=='-' || cadena.at(0) == '+') pos = 1;
				else pos = 0;
				
				// Bandera que se activa al encontrar un punto
				bool encontrado_un_punto = false;
				
				while ((pos < long_cadena) && es_real) {
					
					char c = cadena.at(pos);
					
					if (!isdigit(c)) {
						
						// Solo puede haber un punto.
						// Si se ha encontrado un punto y ya se hab�a
						// encontrado otro, error. Si no, activar la bandera
						// "encontrado_un_punto" (ya no puede haber m�s).
						
						if (c == '.') {
							if (encontrado_un_punto) es_real = false;
							else encontrado_un_punto = true;
						}
						
					    // Si no es un punto ni un d�gito --> error
						else es_real = false;
					}
					
					pos++;
					
				}  // while ((pos < long_cadena) && es_real)
				
			}  // else de if (long_cadena == 0)
			
			return (es_real);
		}
};

int main () // Programa principal
{
	// Declaraci�n de datos
	
	int ciudades;
	Lector lector;
	double distancia;
	SecuenciaReales distancias;
	int TERMINADOR = -1;
	
	// Entrada de datos
	
	lector.SetTitulo("Introduzca el n�mero de ciudades de la red: ");
	ciudades = lector.LeeEnteroEnRango(2, 50); // Como m�nimo se necesitan
	                                           // dos ciudades
	cout << endl;
	
	lector.SetTitulo("");
	MapaDistancias red (ciudades);
	
	for (int i = 0; i < red.ColumnasUtilizadas(); i++) {
		
		cout << endl;
		
		if (i < (ciudades -1))
		cout << "Distancias a la ciudad " << to_string(i) << ":" << endl;
		
		for (int j = 0; j < red.ColumnasUtilizadas(); j++) {
			
			if (j >= i){
				
				cout << endl;
				lector.SetTitulo("Ciudad "+to_string(j)+": ");
				
				if (i != j)
					distancia = lector.LeeRealMayorOIgual(0);
				else
					distancia = 0;
				
				distancias.Aniade(distancia);
			}
			else
				distancias.Aniade(red.Elemento(j, i));
		}
		
		red.Aniade(distancias);
		
		distancias.EliminaTodos();
	}
	
	// APARTADO A
	
	// Salida de datos
	
	cout << "La ciudad con m�s conexiones es la ciudad " << 
	to_string(red.MasConexiones()) << " con " << 
	to_string(red.Conexiones(red.MasConexiones())) << " conexiones ";
	cout << endl << endl;
	
	// APARTADO B
	
	// Entrada de datos
	
	lector.SetTitulo("Ciudad cuyas conexiones directas desea saber: ");
	int ciudad = lector.LeeEnteroEnRango(0, ciudades - 1);
	
	// Salida de datos
	
	cout << "Las ciudades conectadas directamente a la ciudad " << 
	to_string(ciudad) << " son las de los �ndices: " << 
	red.CiudadesConectadas(ciudad).ToString() << endl << endl;
	
	// APARTADO C
	
	// Lectura de datos
	
	cout << "Introduzca los �ndices de las ciudades entre las que desea saber"
	<< " si hay una ciudad intermedia: " << endl;
	
	lector.SetTitulo("Primera ciudad: ");
	ciudad = lector.LeeEnteroEnRango(0, ciudades - 1);
	lector.SetTitulo("Segunda ciudad: ");
	int ciudad1 = lector.LeeEnteroEnRango(0, ciudades - 1);
	
	// C�lculos y salida de datos
	
	if (red.Elemento(ciudad, ciudad1) == 0){
		
		if (red.CiudadIntermedia(ciudad, ciudad1) != -1){
			
			cout << "La ciudad intermedia entre estas dos es la ciudad "
			<< red.CiudadIntermedia(ciudad, ciudad1);
		}
		
		// En caso de que el m�todo devuelva un -1, entonces es que no se
		// ha encontrado ninguna ciudad intermedia
		
		else{
			
			cout << "No existe dicha ciudad intermedia";
		}
	}
	
	// En caso de que se introduzcan dos ciudades con camino directo, no es
	// necesario buscar una ciudad intermedia
	
	else
		cout << "Esas ciudades est�n conectadas entre s�";
	
	cout << endl << endl;
	
	// APARTADO D
	
	cout << "Introduzca �ndices de ciudades: " << endl;
	
	lector.SetTitulo("Ciudad: ");
	int lectura = lector.LeeEnteroEnRango(TERMINADOR, ciudades - 1);
	SecuenciaEnteros secuencia;
	
	while (lectura != TERMINADOR) {
		
		secuencia.Aniade(lectura);
		
		// Nueva lectura
		
		lectura = lector.LeeEnteroEnRango(TERMINADOR, ciudades - 1);
	}
	
	// Salida de datos

	cout << endl;
	
	if (secuencia.TotalUtilizados() > 1){
		
		cout << "�Est�n todas las ciudades conectadas?: " <<
		(red.TodasConectadas(secuencia) ? "SI":"NO");
	}
	else
		cout << "No se han introducido suficientes ciudades";
	
	return 0;
}
