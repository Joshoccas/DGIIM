/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Programa que solicita una matriz de n�meros reales al usuario con el fin de 
extraer de ella una matriz rectangular que tiene el mismo n�mero de filas que
la inicial y el mismo n�mero de columnas que la fila con menos columnas de 
la matriz inicial (ya que la inicial es dentada, cada fila puede tener un
n�mero distinto de columnas utilizadas con respecto a las dem�s filas.

Realmente no se est�n usando matrices, sino vectores de secuencias, pero
lo he explicado como si fueran matrices para una explicaci�n m�s sencilla.
*/
/*****************************************************************************/

#include <iostream>
#include <string>

using namespace std;

///////////////////////////////////////////////////////////////////////////////

class SecuenciaReales {

	private:

    	static const int TAMANIO = 40; // N�m.casillas disponibles
    	double vector_privado[TAMANIO];

    	// PRE: 0<=total_utilizados<TAMANIO

    	int total_utilizados; // N�m.casillas ocupadas

	public:

    	/*******************************************************************/
    	// Constructor sin argumentos

    	SecuenciaReales (void) : total_utilizados (0)
    	{}

    	/*******************************************************************/
    	// Devuelve el n�mero de casillas ocupadas

    	int TotalUtilizados (void)
    	{
        	return (total_utilizados);
    	}

    	/*******************************************************************/
    	// Devuelve el n�mero de casillas disponibles

    	int Capacidad (void)
    	{
        	return (TAMANIO);
    	}

    	/*******************************************************************/
    	// "Vac�a" completamente la secuencia

		void EliminaTodos()
		{
			total_utilizados = 0;
		}

    	/*******************************************************************/
    	// A�ade un elemento ("nuevo") al vector.
    	// PRE: total_utilizados < TAMANIO
    	// 		La adici�n se realiza si hay alguna casilla disponible.
    	// 		El nuevo elemento se coloca al final del vector.
    	// 		Si no hay espacio, no se hace nada.

    	void Aniade (double nuevo)
    	{
        	if (total_utilizados < TAMANIO){
            	vector_privado[total_utilizados] = nuevo;
            	total_utilizados++;
        	}	
    	}

    	/*******************************************************************/
    	// Devuelve el elemento de la casilla "indice"
    	// PRE: 0 <= indice < total_utilizados

    	double Elemento (int indice)
    	{
        	return (vector_privado[indice]);
    	}

    	/*******************************************************************/
    	// Cambia el contenido de la casilla "indice" por el valor "nuevo"
    	// PRE: 0 <= indice < total_utilizados

		void Modifica (int indice, double nuevo)
   		{
			if ((indice >= 0) && (indice < total_utilizados))
				vector_privado[indice] = nuevo;
   		}

    	/*******************************************************************/
    	// Eliminar el real de la posici�n dada por "indice".
    	// Realiza un borrado f�sico (desplazamiento y sustituci�n).
    	// PRE: 0 <= indice < total_utilizados

    	void Elimina (int indice)
    	{
        	if ((indice >= 0) && (indice < total_utilizados)) {

            	int tope = total_utilizados-1; // posic. del �ltimo

            	for (int i = indice ; i < tope ; i++)
                	vector_privado[i] = vector_privado[i+1];

            	total_utilizados--;
        	}
    	}
    
    	/*******************************************************************/
    	// Inserta el real "nuevo" en la posici�n dada por "indice".
    	// Desplaza todos los reales una posici�n a la derecha antes de 
		// copiar en "indice" en valor "nuevo".
		// PRE: 0 <= pos_insercion < total_utilizados
    	// PRE: total_utilizados < TAMANIO
    	// 		La inserci�n se realiza si hay alguna casilla disponible.
    	// 		Si no hay espacio, no se hace nada.
    
		void Inserta (int pos_insercion, double valor_nuevo)
		{
        	if ((pos_insercion >= 0) && (pos_insercion < total_utilizados) 
		   		 && (total_utilizados < TAMANIO)) {
		
				for (int i = total_utilizados; i > pos_insercion; i--)
					vector_privado[i] = vector_privado[i-1];
			
				vector_privado[pos_insercion] = valor_nuevo;
				total_utilizados++;		
			}
		}
		
		/******************************************************************/
		// Representa el estado del objeto mediante un dato de tipo string
		// Para ello, muestra los elementos del vector dato miembro dispuestos
		// en fila
		
		string ToString (void)
		{
			string cad;
			
			for (int i = 0; i < total_utilizados; i++){
				
				cad+= to_string(vector_privado[i]) + " ";
			}
			
			return(cad);
		}
};

//////////////////////////////////////////////////////////////////////////////

class TablaRectangularReales
{

private:

    static const int MAX_FIL = 50; // "filas" disponibles
    static const int MAX_COL = 40;

    SecuenciaReales vector_privado[MAX_FIL];

    // PRE: 0 <= filas_utilizadas <= MAX_FIL
    // PRE: 0 <= cols_utilizadas <= MAX_COL
    
    int filas_utilizadas;
    int cols_utilizadas;

public:
	
	
	/***********************************************************************/
	// Constructor sin argumentos (Matriz nula)

	TablaRectangularReales(void): filas_utilizadas(0),cols_utilizadas(0) { }

	/***********************************************************************/
	// Constructor
	// Recibe "numero_de_columnas" que indica el n�mero de columnas
	// que deben tener TODAS las filas. 
	// PRE: numero_de_columnas <= MAX_COL


	TablaRectangularReales (int numero_de_columnas)
		: filas_utilizadas(0), cols_utilizadas(numero_de_columnas)
	{ }

	/***********************************************************************/
	// Constructor
	// Recibe una secuencia de reales.  El n�mero de elementos
	// de la secuencia es el valor que se usa como "col_utilizadas"
	// PRE: primera_fila.TotalUtilizados() <= MAX_COL

	TablaRectangularReales (SecuenciaReales primera_fila)
		: filas_utilizadas(0), cols_utilizadas (primera_fila.TotalUtilizados())
	{
		Aniade(primera_fila); // Actualiza "filas_utilizadas"
	}

	/***********************************************************************/
	// M�todo de lectura: n�mero m�ximo de filas

	int CapacidadFilas (void)
	{
		return (MAX_FIL);
	}

	/*****************************************************************/
	// M�todo de lectura: n�mero m�ximo de columnas

	int CapacidadColumnas (void)
	{
		return (MAX_COL);
	}

	/*****************************************************************/
	// M�todo de lectura: n�mero real de filas usadas

	int FilasUtilizadas (void)
	{
		return (filas_utilizadas);
	}

	/*****************************************************************/
	// M�todo de lectura: n�mero real de columnas usadas

	int ColumnasUtilizadas (void)
	{
		return (cols_utilizadas);
	}

	/*****************************************************************/
	// M�todo de lectura: devuelve el dato que ocupa la casilla 
	// de coordenadas (fila, columna)
	// PRE: 0 <= fila < filas_utilizadas
	// PRE: 0 <= columna < cols_utilizadas	
	
	int Elemento (int fila, int columna)
	{
		return ((vector_privado[fila]).Elemento(columna));
	}

	/*****************************************************************/
	// Devuelve una fila completa (un objeto "SecuenciaReales")
	// PRE: 0 <= indice_fila < filas_utilizadas
	
	SecuenciaReales Fila (int indice_fila)
	{
		return (vector_privado[indice_fila]);
	}

	/*****************************************************************/
	// Devuelve una columna completa (un objeto "SecuenciaReales")
	// PRE: 0 <= indice_columna < cols_utilizadas
	
	SecuenciaReales Columna (int indice_columna)
	{
		SecuenciaReales columna;

		for (int fil=0; fil<filas_utilizadas; fil++)
			columna.Aniade ((vector_privado[fil]).Elemento(indice_columna));

		return (columna);
	}

	/***********************************************************************/
	// A�ade una fila completa (un objeto "SecuenciaReales")
	// PRE:  fila_nueva.TotalUtilizados() = cols_utilizadas
	// PRE:  filas_utilizadas < MAX_FIL
	
	void Aniade (SecuenciaReales fila_nueva)
	{
		int numero_columnas_fila_nueva = fila_nueva.TotalUtilizados();
					
		if ((filas_utilizadas < MAX_FIL) && 
			(numero_columnas_fila_nueva == cols_utilizadas)) {

			vector_privado[filas_utilizadas] = fila_nueva;

			filas_utilizadas++;
		}
	}


	/***********************************************************************/
	// "Vac�a" una tabla

	void EliminaTodos (void)
	{
		filas_utilizadas = 0;
	}
	
	/***********************************************************************/
	// Inserta una fila completa en una posici�n dada. 
	// La fila se porporciona en un objeto "SecuenciaReales".
	// 
	// Recibe: num_fila, la posici�n que ocupar� "fila_nueva" cuando se 
	//		 		inserte en la tabla.
	//		   fila_nueva, la secuencia que se va a insertar. Se trata 
	//				de un objeto de la clase SecuenciaReales. 
	//
	// PRE:  fila_nueva.TotalUtilizados() = cols_utilizadas
	// PRE:  filas_utilizadas < MAX_FIL
	// PRE:  0 <= num_fila <= TotalUtilizados()
	//		 Si num_fila = 0, "nueva_fila" ser� la nueva primera fila. 
	//		 Si num_fila = TotalUtilizados(), "nueva_fila" ser� la nueva 
	//		 �ltima fila (el resultado ser� equivalente al de "Aniade()" 
	
	void Inserta (int num_fila, SecuenciaReales fila_nueva)
	{
		int numero_columnas_fila_nueva = fila_nueva.TotalUtilizados();
					
		// Precondiciones
		
		if ((filas_utilizadas < MAX_FIL) && 
			(numero_columnas_fila_nueva == cols_utilizadas) && 
			(0<=num_fila) && (num_fila <=filas_utilizadas)) {

			// "Desplazar" las filas hacia posiciones altas. 
			// La �ltima fila se copia en una NUEVA FILA que ocupa la 
			// posici�n "filas_utilizadas", la pen�ltima se copia en 
			// "filas_utilizadas"-1, ... y se queda un "hueco" en 
			// la fila "num_fila ".
			// NOTA: no se modifica (todav�a) "filas_utilizadas" 
			
			for (int fil=filas_utilizadas; fil>num_fila; fil--) 			
				vector_privado[fil]=vector_privado[fil-1];
			
			// Copiar en el "hueco" (fila "num_fila") el contenido de 
			// la secuencia "fila_nueva"
			
			vector_privado[num_fila]=fila_nueva;	
			
			filas_utilizadas++; // Actualizaci�n del tama�o de la tabla.
		}
	}

	/*****************************************************************/
	// Elimina una fila completa, dada una posici�n. 
	// 
	// Recibe: num_fila, la posici�n de la fila a eliminar.
	// PRE:  0 <= num_fila < TotalUtilizados()
	
	void Elimina (int num_fila)
	{		
		// Precondiciones
		
		if ((0<=num_fila) && (num_fila <=filas_utilizadas)) {

			// "Desplazar" las filas hacia posiciones bajas. 
			// En la posici�n "num_fila" se copia la que est� en la posici�n
			// siguiente ("num_fila"+1), en su lugar se copia que est� en 
			// "num_fila"+2, ... y en la posici�n "total_utilizados"-2 se 
			// copia la de "total_utilizados"-1. 
			
			for (int fil=num_fila; fil<filas_utilizadas-1; fil++) 
				vector_privado[fil]=vector_privado[fil+1];
			
			filas_utilizadas--; // Actualizaci�n del tama�o de la tabla.
		}
	}
	
	/*****************************************************************/
	// Representa mediante un dato string el estado del objeto. En este 
	// caso, muestra los elementos de cada secuencia del vector dato miembro
	// del objeto dispuestos por filas y columnas
	
	string ToString (void)
	{
		string cad;
		
		for (int i = 0; i < filas_utilizadas; i++){
			
			cad+= vector_privado[i].ToString() + "\n";
		}
		
		return(cad);
	}
};

//////////////////////////////////////////////////////////////////////////////

class TablaDentadaReales
{
	private:
		
		static const int MAX_FIL = 50; // "filas" disponibles
    	static const int MAX_COL = 40;

    	SecuenciaReales vector_privado[MAX_FIL];

    	// PRE: 0 <= filas_utilizadas <= MAX_FIL
    	// PRE: 0 <= cols_utilizadas <= MAX_COL
    
    	int filas_utilizadas;
    	
    	// PRE: 0 <= num_cols_utilizadas[i] <= MAX_COL
		//     para i = 0,1,...,filas_utilizadas-1
		// N�mero de columnas ocupadas en cada fila
		
		int num_cols_utilizadas[MAX_FIL] = {0};
		
	public:
		
		// Constructor sin argumentos
		
		TablaDentadaReales (void)
		 : filas_utilizadas(0)
		
		{}
		
		// Recibe "primera_fila" (una secuencia de reales)
		// PRE: primera_fila.TotalUtilizados() <= MAX_COL
		
		TablaDentadaReales (SecuenciaReales primera_fila)
		 : filas_utilizadas(0)
		{
			Aniade(primera_fila); // Actualiza "filas_utilizadas"
		}
		
		/*******************************************************************/
		// M�todo de lectura: n�mero m�ximo de filas

		int CapacidadFilas (void)
		{
			return (MAX_FIL);
		}	

		/*******************************************************************/
		// M�todo de lectura: n�mero m�ximo de columnas

		int CapacidadColumnas (void)
		{
			return (MAX_COL);
		}

		/*******************************************************************/
		// M�todo de lectura: n�mero real de filas usadas

		int FilasUtilizadas (void)
		{
			return (filas_utilizadas);
		}
		
		/*******************************************************************/
		// A�ade una fila completa (un objeto "SecuenciaReales")
		// PRE:  filas_utilizadas < NUM_FILS
		// PRE:  fila_nueva.TotalUtilizados() <= NUM_COLS
	
		void Aniade (SecuenciaReales fila_nueva)
		{
			int numero_columnas_fila_nueva = fila_nueva.TotalUtilizados();
					
			if ((filas_utilizadas < MAX_FIL) &&
				(numero_columnas_fila_nueva <= MAX_COL)) {
				
				// El n�mero de columnas de la nueva fila se guarda en el 
				// vector que almacena el n�mero de columnas de cada fila
					
				num_cols_utilizadas[filas_utilizadas] =
				numero_columnas_fila_nueva;

				vector_privado[filas_utilizadas] = fila_nueva;

				filas_utilizadas++;
			}
		}
		
		/*******************************************************************/
		// M�todo que devuelve un objeto de la clase TablaRectangularReales
		// cuyo n�mero de secuencias es el de la tabla dentada sobre la que 
		// act�a el m�todo y cuyo n�mero de columnas es el n�mero de columnas 
		// m�s peque�o de entre todas las secuencias del vector
		
		TablaRectangularReales CalculoTablaRect (void)
		{
			// Se busca el n�mero de columnas de la tabla rectangular a crear
			// y se inicializa con el n�mero de columnas de la primera fila
			
			int num_cols_min = num_cols_utilizadas[0];
			
			for (int i = 1; i < filas_utilizadas; i++){
				
				if (num_cols_utilizadas[i] < num_cols_min)
					num_cols_min = num_cols_utilizadas[i];
			}
			
			// Se crea la secuencia de reales en la que se ir� introduciendo
			// cada fila de la matriz dentada. Tambi�n se crea la tabla 
			// rectangular que devolver� el m�todo, la cual tendr� num_cols_min
			// columnas
			
			SecuenciaReales auxiliar;
			TablaRectangularReales resultado (num_cols_min);
			
			for (int i = 0; i < filas_utilizadas; i++){
				
				for (int j = 0; j < num_cols_min; j++){
					
					auxiliar.Aniade(vector_privado[i].Elemento(j));
				}
				
				// Una vez introducidos todos los elementos de la fila en la
				// secuencia, se a�ade dicha secuencia a la primera fila de
				// la tabla rectangular
				
				resultado.Aniade(auxiliar);
				
				// Borramos el contenido de la secuencia auxiliar para la
				// siguiente iteraci�n
				
				auxiliar.EliminaTodos();
			}
			
			return(resultado);
		}
		
		/*******************************************************************/
		// Representa mediante un dato string el estado del objeto. En este 
		// caso, muestra los elementos de cada secuencia del vector dato miembro
		// del objeto dispuestos por filas y columnas
		
		string ToString (void)
		{
			string cad;
			
			for (int i = 0; i < filas_utilizadas; i++){
				
				cad+= vector_privado[i].ToString() + "\n";
			}
			
			return(cad);
		}
};

//////////////////////////////////////////////////////////////////////////////

class Lector
{
	private:
		
		string titulo;
	
	public:
		
		// Constructor sin argumentos
		
		Lector (void) : titulo ("")
		{ }
		
		// Constructor con argumentos
		
		Lector (string cad) : titulo (cad)
		{ }
		
		// M�todo Set para fijar el campo "titulo"
		
		void SetTitulo (string cad)
		{
			titulo = cad;
		}
		
		/*********************************************************************/
		// Lee un dato int.
		// La lectura est� etiquetada con "titulo"
		// La lectura se efect�a repetidamente hasta que se introduce un valor
		// int correcto.
		
		int LeeEntero (void)
		{
			string cadena;
			
			do{
				cout << titulo;
				getline(cin, cadena);
			}
			while (!EsEntero(cadena));
			
			return (stoi(cadena));
		}
		
		/*********************************************************************/
		// Lee un dato int.
		// La lectura est� etiquetada con "titulo"
		// PRE: menor <= mayor
		// POST: menor <= valor devuelto <= mayor
		
		int LeeEnteroEnRango (int menor, int mayor)
		{
			int numero;
			
			do{
				
				numero = LeeEntero ();
			}
			while ((numero<menor) || (numero>mayor));
			
			return (numero);
		}
		
		/*********************************************************************/
		// Lee un dato int que debe ser mayor o igual que "menor" y lo devuelve.
		// La lectura est� etiquetada con "titulo"
		
		int LeeEnteroMayorOIgual (int menor)
		{
			int numero;
			
			do{
				numero = LeeEntero ();
			}
			while (numero < menor);
			
			return (numero);
		}
		
		/*********************************************************************/
		// Lee un dato double.
		// La lectura est� etiquetada con "titulo"
		// La lectura se efect�a repetidamente hasta que se introduce un valor
		// double correcto.
		
		double LeeReal (void)
		{
			string cadena;
			
			do{
				cout << titulo;
				getline(cin, cadena);
			}
			while (!EsReal(cadena));
			
			return (stod(cadena));
		}
		
		/*********************************************************************/
		// Lee un dato double.
		// La lectura est� etiquetada con "titulo"
		// PRE: menor <= mayor
		// POST: menor <= valor devuelto <= mayor
		
		double LeeRealEnRango (int menor, int mayor)
		{
			double numero;
			
			do{
				
				numero = LeeReal ();
			}
			while ((numero<menor) || (numero>mayor));
			
			return (numero);
		}

		/*********************************************************************/
		// Lee un dato double que debe ser mayor o igual que "menor" y lo 
		// devuelve. 
		// La lectura est� etiquetada con "titulo"
		
		double LeeRealMayorOIgual (int menor)
		{
			double numero;
			
			do{
				numero = LeeReal ();
			}
			while (numero < menor);
			
			return (numero);
		}

		/*********************************************************************/
	
	private:
		
		/*********************************************************************/
		// Devuelve una NUEVA cadena, resultante de eliminar los �ltimos
		// caracteres separadores de "cadena". Los caracteres separadores son
		// el espacio en blanco, el tabulador y el salto de l�nea.
		// Usaremos la funci�n isspace() para simplificar el c�lculo.
		//
		// Recibe: cadena, string sobre la que se va a trabajar.
		// Devuelve: el resultado de eliminar los �ltimos separadores de 
		// "cadena"
		/*********************************************************************/
		
		string EliminaUltimosSeparadores (string cadena)
		{
			while (cadena.length()>0 && isspace(cadena.back()))
				cadena.pop_back();
			
			return (cadena);
		}
		
		/*********************************************************************/
		// Devuelve una NUEVA cadena, resultante de eliminar los primeros
		// caracteres separadores de "cadena". Los caracteres separadores son
		// el espacio en blanco, el tabulador y el salto de l�nea.
		// Usaremos la funci�n isspace() para simplificar el c�lculo.
		//
		// Recibe: cadena, string sobre la que se va a trabajar.
		// Devuelve: el resultado de eliminar los �ltimos separadores de 
		// "cadena"
		/*********************************************************************/
		string EliminaPrimerosSeparadores (string cadena)
		{
			// Buscar el primer car�cter no espacio
			unsigned int pos = 0;
			while (pos < cadena.length() && isspace(cadena.at(pos))) pos++;
			
			string local;
			
			// Copiar todos los que quedan
			while (pos < cadena.length()) {
				local.push_back(cadena.at(pos));
				pos++;
			}
			
			return (local);
		}
		
		/*********************************************************************/
		// Devuelve una NUEVA cadena, resultante de eliminar los primeros 
		// �ltimos caracteres separadores de "cadena". Los caracteres 
		// separadores son el espacio en blanco, el tabulador y el salto de
		// l�nea
		//
		// Recibe: cadena, string sobre la que se va a trabajar.
		// Devuelve: el resultado de eliminar los primeros y los �ltimos
		//           separadores de "cadena".
		/*********************************************************************/
		
		string EliminaPrimerosYUltimosSeparadores (string cadena)
		{
			string cadena_podada = EliminaPrimerosSeparadores (cadena);
			cadena_podada = EliminaUltimosSeparadores (cadena_podada);
			
			return (cadena_podada);
		}
		
		/*********************************************************************/
		// Devuelve "true" si "cadena" es la representaci�n textual de un
		// entero
		//
		// Recibe: cadena, string sobre la que se va a trabajar.
		// Devuelve: "true" si "cadena" es la representaci�n textual de un int
		
		bool EsEntero (string cadena)
		{
			bool es_entero = true;
			
			cadena = EliminaPrimerosSeparadores (cadena);
			cadena = EliminaUltimosSeparadores (cadena);
			
			unsigned int long_cadena = cadena.length();
			
			if (long_cadena == 0) es_entero = false;
			else {
				
				// Si el primer car�cter es '+' � '-', perfecto. En ese caso
				// se pasa al siguiente car�cter (posici�n 19.
				
				unsigned int pos;
				if (cadena.at(0)=='-' || cadena.at(0) == '+') pos = 1;
				else pos = 0;
				
				while ((pos < long_cadena) && es_entero) {
					if(!isdigit(cadena.at(pos))) es_entero = false;
					else pos++;
				}
			}
			
			return (es_entero);
		}
		
		/*********************************************************************/

		bool EsReal (string cadena)
		{
			bool es_real = true;
			
			cadena = EliminaPrimerosSeparadores (cadena);
			cadena = EliminaUltimosSeparadores (cadena);
			
			unsigned int long_cadena = cadena.length();
			
			if (long_cadena == 0) es_real = false;
			else {
				
				// Si el primer car�cter es '+' � '-', perfecto. En ese caso
				// se pasa al siguiente car�cter (posici�n 19.
				
				unsigned int pos;
				if (cadena.at(0)=='-' || cadena.at(0) == '+') pos = 1;
				else pos = 0;
				
				// Bandera que se activa al encontrar un punto
				bool encontrado_un_punto = false;
				
				while ((pos < long_cadena) && es_real) {
					
					char c = cadena.at(pos);
					
					if (!isdigit(c)) {
						
						// Solo puede haber un punto.
						// Si se ha encontrado un punto y ya se hab�a
						// encontrado otro, error. Si no, activar la bandera
						// "encontrado_un_punto" (ya no puede haber m�s).
						
						if (c == '.') {
							if (encontrado_un_punto) es_real = false;
							else encontrado_un_punto = true;
						}
						
					    // Si no es un punto ni un d�gito --> error
						else es_real = false;
					}
					
					pos++;
					
				}  // while ((pos < long_cadena) && es_real)
				
			}  // else de if (long_cadena == 0)
			
			return (es_real);
		}
};

/////////////////////////////////////////////////////////////////////////////

int main() // Programa principal
{
	// Declaraci�n de datos
	
	int filas_totales;
	int columnas_por_fila;
	Lector lector;
	
	cout << "CREACI�N DE LA MATRIZ DE N�MEROS REALES" << endl << endl;
	
	cout << "Tenga en cuenta que el m�ximo de filas es 50 y el de columnas 40";
	cout << endl;
	
	TablaDentadaReales tabla;
	
	// Entrada de datos
	
	lector.SetTitulo("N� de filas de su matriz: ");
	filas_totales = lector.LeeEnteroEnRango(1, tabla.CapacidadFilas());
	
	for (int i = 0; i < filas_totales; i++){
		
		cout << endl;
		lector.SetTitulo("N� de columnas de la fila " + to_string(i) + ": ");
		columnas_por_fila = 
		lector.LeeEnteroEnRango(1, tabla.CapacidadColumnas());
		
		SecuenciaReales a_aniadir;
		lector.SetTitulo("Introduzca un n�mero real: ");
		
		cout << endl;
		
		for (int i = 0; i < columnas_por_fila; i++){
			
			a_aniadir.Aniade(lector.LeeReal());
		}
		
		tabla.Aniade(a_aniadir);
	}
	
	// Mostrar matriz dentada
	
	cout << endl;
	cout << tabla.ToString() << endl;
	
	// C�lculos
	
	TablaRectangularReales resultado (tabla.CalculoTablaRect());
	
	// Salida de datos
	
	cout << endl;
	cout << "La tabla rectangular derivada de la dentada es la siguiente: ";
	cout << endl << endl;
	
	cout << resultado.ToString() << endl;
	
	return 0;
}
