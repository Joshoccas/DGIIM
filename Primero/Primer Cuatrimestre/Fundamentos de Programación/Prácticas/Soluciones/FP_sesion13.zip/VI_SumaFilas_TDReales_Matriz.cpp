/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Programa que solicita una matriz dentada para calcular la suma de los elementos
de cada una de sus filas. La entrada de datos debe hacerse de la siguiente 
manera:

3 3 2.1 3.1 4.1 2 1.2 1.2 3 2.6 9 5.2

En este ejemplo, el primer entero indicar�a que tenemos 3 filas. El segundo
entero indicar�a que la primera fila tiene 3 columnas, por lo que los tres
reales siguientes son los elementos que se suman de la primera fila. El
sexto n�mero indica que la fila segunda tiene 2 columnas y por lo tanto, los
dos siguientes reales son los elementos de dicha fila, y as� sucesivamente.

El resultado de este programa ser� una secuencia de reales, y para el ejemplo
dado, la secuencia resultante ser�a: 9.3 2.4 16.8
*/
/*****************************************************************************/

#include <string>
#include <iostream>

using namespace std;

///////////////////////////////////////////////////////////////////////////////

class SecuenciaReales {

	private:

    	static const int TAMANIO = 40; // N�m.casillas disponibles
    	double vector_privado[TAMANIO];

    	// PRE: 0<=total_utilizados<TAMANIO

    	int total_utilizados; // N�m.casillas ocupadas

	public:

    	/*******************************************************************/
    	// Constructor sin argumentos

    	SecuenciaReales (void) : total_utilizados (0)
    	{}

    	/*******************************************************************/
    	// Devuelve el n�mero de casillas ocupadas

    	int TotalUtilizados (void)
    	{
        	return (total_utilizados);
    	}

    	/*******************************************************************/
    	// Devuelve el n�mero de casillas disponibles

    	int Capacidad (void)
    	{
        	return (TAMANIO);
    	}

    	/*******************************************************************/
    	// "Vac�a" completamente la secuencia

		void EliminaTodos()
		{
			total_utilizados = 0;
		}

    	/*******************************************************************/
    	// A�ade un elemento ("nuevo") al vector.
    	// PRE: total_utilizados < TAMANIO
    	// 		La adici�n se realiza si hay alguna casilla disponible.
    	// 		El nuevo elemento se coloca al final del vector.
    	// 		Si no hay espacio, no se hace nada.

    	void Aniade (double nuevo)
    	{
        	if (total_utilizados < TAMANIO){
            	vector_privado[total_utilizados] = nuevo;
            	total_utilizados++;
        	}	
    	}

    	/*******************************************************************/
    	// Devuelve el elemento de la casilla "indice"
    	// PRE: 0 <= indice < total_utilizados

    	double Elemento (int indice)
    	{
        	return (vector_privado[indice]);
    	}

    	/*******************************************************************/
    	// Cambia el contenido de la casilla "indice" por el valor "nuevo"
    	// PRE: 0 <= indice < total_utilizados

		void Modifica (int indice, double nuevo)
   		{
			if ((indice >= 0) && (indice < total_utilizados))
				vector_privado[indice] = nuevo;
   		}

    	/*******************************************************************/
    	// Eliminar el real de la posici�n dada por "indice".
    	// Realiza un borrado f�sico (desplazamiento y sustituci�n).
    	// PRE: 0 <= indice < total_utilizados

    	void Elimina (int indice)
    	{
        	if ((indice >= 0) && (indice < total_utilizados)) {

            	int tope = total_utilizados-1; // posic. del �ltimo

            	for (int i = indice ; i < tope ; i++)
                	vector_privado[i] = vector_privado[i+1];

            	total_utilizados--;
        	}
    	}
    
    	/*******************************************************************/
    	// Inserta el real "nuevo" en la posici�n dada por "indice".
    	// Desplaza todos los reales una posici�n a la derecha antes de 
		// copiar en "indice" en valor "nuevo".
		// PRE: 0 <= pos_insercion < total_utilizados
    	// PRE: total_utilizados < TAMANIO
    	// 		La inserci�n se realiza si hay alguna casilla disponible.
    	// 		Si no hay espacio, no se hace nada.
    
		void Inserta (int pos_insercion, double valor_nuevo)
		{
        	if ((pos_insercion >= 0) && (pos_insercion < total_utilizados) 
		   		 && (total_utilizados < TAMANIO)) {
		
				for (int i = total_utilizados; i > pos_insercion; i--)
					vector_privado[i] = vector_privado[i-1];
			
				vector_privado[pos_insercion] = valor_nuevo;
				total_utilizados++;		
			}
		}
		
		/******************************************************************/
		// Representa mediante un dato string el estado del objeto. En este 
		// caso, muestra los elementos del vector dato miembro del objeto  
		// dispuestos en una fila
		
		string ToString (void)
		{
			string cad;
			
			for (int i = 0; i < total_utilizados; i++){
				
				cad+= to_string(vector_privado[i]) + " ";
			}
			
			return (cad);
		}
};

///////////////////////////////////////////////////////////////////////////////

class TablaDentadaReales
{
	private:
		
		static const int NUM_FILS = 50;
		static const int NUM_COLS = 40;
		
		double matriz_privada[NUM_FILS][NUM_COLS];
		
		// PRE: 0 <= filas_utilizadas <= NUM_FILS
		
		int filas_utilizadas;
		
		// PRE: 0 <= num_cols_utilizadas[i] <= NUM_COLS
		//     para i = 0,1,...,filas_utilizadas-1
		// N�mero de columnas ocupadas en cada fila
		
		int num_cols_utilizadas[NUM_FILS] = {0};
		
	public:
		
		// Constructor sin argumentos
		
		TablaDentadaReales (void)
		 : filas_utilizadas(0)
		
		{}
		
		// Recibe "primera_fila" (una secuencia de reales)
		// PRE: primera_fila.TotalUtilizados() <= NUM_COLS
		
		TablaDentadaReales (SecuenciaReales primera_fila)
		 : filas_utilizadas(0)
		{
			Aniade(primera_fila); // Actualiza "filas_utilizadas"
		}
		
		/*******************************************************************/
		// M�todo de lectura: n�mero m�ximo de filas

		int CapacidadFilas (void)
		{
			return (NUM_FILS);
		}	

		/*******************************************************************/
		// M�todo de lectura: n�mero m�ximo de columnas

		int CapacidadColumnas (void)
		{
			return (NUM_COLS);
		}

		/*******************************************************************/
		// M�todo de lectura: n�mero real de filas usadas

		int FilasUtilizadas (void)
		{
			return (filas_utilizadas);
		}
		
		/*******************************************************************/
		// M�todo de lectura: n�mero real de columnas usadas en la fila "fila"
		// PRE: 0 <= fila < filas_utilizadas
		
		int ColumnasUtilizadas (int indice_fila)
		{
			return(num_cols_utilizadas[indice_fila]);
		}
		
		/*******************************************************************/
		// M�todo de lectura: devuelve el dato que ocupa la casilla 
		// de coordenadas (fila, columna)
		// PRE: 0 <= fila < filas_utilizadas
		// PRE: 0 <= columna < num_cols_utilizadas[fila]
		
		double Elemento (int fila, int columna)
		{
			return(matriz_privada[fila][columna]);
		}
		
		/*******************************************************************/
		// A�ade una fila completa (un objeto "SecuenciaReales")
		// PRE:  filas_utilizadas < NUM_FILS
		// PRE:  fila_nueva.TotalUtilizados() <= NUM_COLS
	
		void Aniade (SecuenciaReales fila_nueva)
		{
			int numero_columnas_fila_nueva = fila_nueva.TotalUtilizados();
					
			if ((filas_utilizadas < NUM_FILS) &&
				(numero_columnas_fila_nueva <= NUM_COLS)) {
				
				// El n�mero de columnas de la nueva fila se guarda en el 
				// vector que almacena el n�mero de columnas de cada fila
					
				num_cols_utilizadas[filas_utilizadas] =
				numero_columnas_fila_nueva;

				for (int col = 0; col < numero_columnas_fila_nueva; col++){
					
					matriz_privada[filas_utilizadas][col]=
					fila_nueva.Elemento(col);
				}

				filas_utilizadas++;
			}
		}
		
		/*******************************************************************/
		// M�todo que calcula la suma de los elementos de cada fila de la 
		// matriz dentada y los devuelve en una secuencia de reales
		
		SecuenciaReales SumaFilas (void)
		{
			SecuenciaReales resultado;
			double suma = 0;
			
			// Recorremos cada fila de la matriz
			
			for (int i = 0; i < filas_utilizadas; i++){
				
				// Recorremos todos los elementos de la fila y los vamos
				// sumando
				
				for (int j = 0; j < num_cols_utilizadas[i]; j++)
					suma+= Elemento(i, j);
				
				// Tras el c�lculo de la suma de los elementos de una fila,
				// a�adimos dicha suma a la secuencia de salida
				
				resultado.Aniade(suma);
				
				// Borramos la suma almacenada para poder realizar la
				// siguiente iteraci�n
				
				suma = 0;
			}
			
			return(resultado);
		}
		/*******************************************************************/
		// Representa mediante un dato string el estado del objeto. En este 
		// caso, muestra los elementos de la matriz dato miembro del objeto  
		// dispuestos por filas y columnas
		
		string ToString (void)
		{
			string cad;
		
			for (int i = 0; i < filas_utilizadas; i++){
			
				for (int j = 0; j < num_cols_utilizadas[i]; j++){
				
					cad += to_string(matriz_privada[i][j]) + " ";
				}
			
				cad+= "\n";
			}
		
			return(cad);
		}
};

//////////////////////////////////////////////////////////////////////////////

int main() // Programa principal
{
	// Declaraci�n de datos
	
	int filas;
	int columnas;
	double elemento;
	SecuenciaReales fila;
	TablaDentadaReales tabla;
	
	// Entrada de datos 
	
	cout << "C�LCULO DE LA SUMA DE LOS ELEMENTOS DE CADA FILA" << endl;
	cout << "Instrucciones. La entrada de datos debe hacerse de la siguiente" 
	 << " manera: " << endl;
	
	cout << "1. Los datos deben ser todos introducidos en una fila y separados"
	<< " por espacios" << endl;
	cout << "2. Primer n�mero: N� de filas de su matriz" << endl;
	cout << "3. Segundo n�mero: N� de columnas de la primera fila" << endl;
	cout << "4. Siguientes n�meros: Los elementos de la primera fila" << endl;
	cout << "5. N� de columnas de la siguiente fila: " << endl;
	cout << "..." << endl << endl;
	
	cin >> filas;
	
	for (int i = 0; i < filas; i++){
		
		cin >> columnas;
		
		for (int j = 0; j < columnas; j++){
			
			cin >> elemento;
			fila.Aniade(elemento);
		}
		
		tabla.Aniade(fila);
		
		fila.EliminaTodos();
	}
	
	// C�lculos
	
	SecuenciaReales sumas (tabla.SumaFilas());
	
	// Salida de datos
	
	cout << endl << endl;
	cout << "La sumas de las filas son: " << endl << endl;
	cout << sumas.ToString() << endl;
	
	return 0;
}
