/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/*
Programa que solicita una matriz rectangular (que en este programa se trata de 
una secuencia de secuencias, un vector de referencia a comparar con las  
secuencias de dicha secuencia y un vector que indica las secuencias con las que 
se va a establecer dicha comparaci�n. Dicha comparaci�n se realiza mediante el 
c�lculo de la distancia eucl�dea entre el vector referencia y cada secuencia. 
Finalmente, se presenta en pantalla la secuencia m�s similar al vector de 
referencia de acuerdo con el criterio de la distancia eucl�dea.
*/
/*****************************************************************************/

#include <iostream>
#include <string>
#include <cmath>

using namespace std;

///////////////////////////////////////////////////////////////////////////////

class SecuenciaEnteros {

	private:

    	static const int TAMANIO = 40; // N�m.casillas disponibles
    	int vector_privado[TAMANIO];

    	// PRE: 0<=total_utilizados<TAMANIO

    	int total_utilizados; // N�m.casillas ocupadas

	public:

    	/*******************************************************************/
    	// Constructor sin argumentos

    	SecuenciaEnteros (void) : total_utilizados (0)
    	{}

    	/*******************************************************************/
    	// Devuelve el n�mero de casillas ocupadas

    	int TotalUtilizados (void)
    	{
        	return (total_utilizados);
    	}

    	/*******************************************************************/
    	// Devuelve el n�mero de casillas disponibles

    	int Capacidad (void)
    	{
        	return (TAMANIO);
    	}

    	/*******************************************************************/
    	// "Vac�a" completamente la secuencia

		void EliminaTodos()
		{
			total_utilizados = 0;
		}

    	/*******************************************************************/
    	// A�ade un elemento ("nuevo") al vector.
    	// PRE: total_utilizados < TAMANIO
    	// 		La adici�n se realiza si hay alguna casilla disponible.
    	// 		El nuevo elemento se coloca al final del vector.
    	// 		Si no hay espacio, no se hace nada.

    	void Aniade (int nuevo)
    	{
        	if (total_utilizados < TAMANIO){
            	vector_privado[total_utilizados] = nuevo;
            	total_utilizados++;
        	}	
    	}

    	/*******************************************************************/
    	// Devuelve el elemento de la casilla "indice"
    	// PRE: 0 <= indice < total_utilizados

    	int Elemento (int indice)
    	{
        	return (vector_privado[indice]);
    	}

    	/*******************************************************************/
    	// Cambia el contenido de la casilla "indice" por el valor "nuevo"
    	// PRE: 0 <= indice < total_utilizados

		void Modifica (int indice, int nuevo)
   		{
			if ((indice >= 0) && (indice < total_utilizados))
				vector_privado[indice] = nuevo;
   		}

    	/*******************************************************************/
    	// Eliminar el real de la posici�n dada por "indice".
    	// Realiza un borrado f�sico (desplazamiento y sustituci�n).
    	// PRE: 0 <= indice < total_utilizados

    	void Elimina (int indice)
    	{
        	if ((indice >= 0) && (indice < total_utilizados)) {

            	int tope = total_utilizados-1; // posic. del �ltimo

            	for (int i = indice ; i < tope ; i++)
                	vector_privado[i] = vector_privado[i+1];

            	total_utilizados--;
        	}
    	}
    
    	/*******************************************************************/
    	// Inserta el real "nuevo" en la posici�n dada por "indice".
    	// Desplaza todos los reales una posici�n a la derecha antes de 
		// copiar en "indice" en valor "nuevo".
		// PRE: 0 <= pos_insercion < total_utilizados
    	// PRE: total_utilizados < TAMANIO
    	// 		La inserci�n se realiza si hay alguna casilla disponible.
    	// 		Si no hay espacio, no se hace nada.
    
		void Inserta (int pos_insercion, int valor_nuevo)
		{
        	if ((pos_insercion >= 0) && (pos_insercion < total_utilizados) 
		   		 && (total_utilizados < TAMANIO)) {
		
				for (int i = total_utilizados; i > pos_insercion; i--)
					vector_privado[i] = vector_privado[i-1];
			
				vector_privado[pos_insercion] = valor_nuevo;
				total_utilizados++;		
			}
		}
		
		/*******************************************************************/
		// Representa mediante un dato string el estado del objeto. En este 
		// caso, muestra los elementos del vector dato miembro del objeto
		// dispuestos en una fila
		
		string ToString (void)
		{
			string cad;
			
			for (int i = 0; i < total_utilizados; i++){
				
				cad+= to_string(vector_privado[i]) + " ";
			}
			
			return(cad);
		}
};

//////////////////////////////////////////////////////////////////////////////

class TablaRectangularEnteros
{

private:

    static const int MAX_FIL = 50; // "filas" disponibles
    static const int MAX_COL = 40;

    SecuenciaEnteros vector_privado[MAX_FIL];

    // PRE: 0 < filas_utilizadas <= MAX_FIL
    // PRE: 0 < cols_utilizadas <= MAX_COL
    
    int filas_utilizadas;
    int cols_utilizadas;

public:
	
	
	/***********************************************************************/
	// Constructor sin argumentos (Matriz nula)

	TablaRectangularEnteros(void): filas_utilizadas(0),cols_utilizadas(0) { }

	/***********************************************************************/
	// Constructor
	// Recibe "numero_de_columnas" que indica el n�mero de columnas
	// que deben tener TODAS las filas. 
	// PRE: numero_de_columnas <= MAX_COL


	TablaRectangularEnteros (int numero_de_columnas)
		: filas_utilizadas(0), cols_utilizadas(numero_de_columnas)
	{ }

	/***********************************************************************/
	// Constructor
	// Recibe una secuencia de enteros.  El n�mero de elementos
	// de la secuencia es el valor que se usa como "col_utilizadas"
	// PRE: primera_fila.TotalUtilizados() <= MAX_COL

	TablaRectangularEnteros (SecuenciaEnteros primera_fila)
		: filas_utilizadas(0), cols_utilizadas (primera_fila.TotalUtilizados())
	{
		Aniade(primera_fila); // Actualiza "filas_utilizadas"
	}

	/***********************************************************************/
	// M�todo de lectura: n�mero m�ximo de filas

	int CapacidadFilas (void)
	{
		return (MAX_FIL);
	}

	/*****************************************************************/
	// M�todo de lectura: n�mero m�ximo de columnas

	int CapacidadColumnas (void)
	{
		return (MAX_COL);
	}

	/*****************************************************************/
	// M�todo de lectura: n�mero real de filas usadas

	int FilasUtilizadas (void)
	{
		return (filas_utilizadas);
	}

	/*****************************************************************/
	// M�todo de lectura: n�mero real de columnas usadas

	int ColumnasUtilizadas (void)
	{
		return (cols_utilizadas);
	}

	/*****************************************************************/
	// M�todo de lectura: devuelve el dato que ocupa la casilla 
	// de coordenadas (fila, columna)
	// PRE: 0 <= fila < filas_utilizadas
	// PRE: 0 <= columna < cols_utilizadas	
	
	int Elemento (int fila, int columna)
	{
		return ((vector_privado[fila]).Elemento(columna));
	}

	/*****************************************************************/
	// Devuelve una fila completa (un objeto "SecuenciaEnteros")
	// PRE: 0 <= indice_fila < filas_utilizadas
	
	SecuenciaEnteros Fila (int indice_fila)
	{
		return (vector_privado[indice_fila]);
	}

	/*****************************************************************/
	// Devuelve una columna completa (un objeto "SecuenciaEnteros")
	// PRE: 0 <= indice_columna < cols_utilizadas
	
	SecuenciaEnteros Columna (int indice_columna)
	{
		SecuenciaEnteros columna;

		for (int fil=0; fil<filas_utilizadas; fil++)
			columna.Aniade ((vector_privado[fil]).Elemento(indice_columna));

		return (columna);
	}

	/***********************************************************************/
	// A�ade una fila completa (un objeto "SecuenciaEnteros")
	// PRE:  fila_nueva.TotalUtilizados() = cols_utilizadas
	// PRE:  filas_utilizadas < MAX_FIL
	
	void Aniade (SecuenciaEnteros fila_nueva)
	{
		int numero_columnas_fila_nueva = fila_nueva.TotalUtilizados();
					
		if ((filas_utilizadas < MAX_FIL) && 
			(numero_columnas_fila_nueva == cols_utilizadas)) {

			vector_privado[filas_utilizadas] = fila_nueva;

			filas_utilizadas++;
		}
	}


	/***********************************************************************/
	// "Vac�a" una tabla

	void EliminaTodos (void)
	{
		filas_utilizadas = 0;
	}
	
	/***********************************************************************/
	// Inserta una fila completa en una posici�n dada. 
	// La fila se porporciona en un objeto "SecuenciaEnteros".
	// 
	// Recibe: num_fila, la posici�n que ocupar� "fila_nueva" cuando se 
	//		 		inserte en la tabla.
	//		   fila_nueva, la secuencia que se va a insertar. Se trata 
	//				de un objeto de la clase SecuenciaEnteros. 
	//
	// PRE:  fila_nueva.TotalUtilizados() = cols_utilizadas
	// PRE:  filas_utilizadas < MAX_FIL
	// PRE:  0 <= num_fila <= TotalUtilizados()
	//		 Si num_fila = 0, "nueva_fila" ser� la nueva primera fila. 
	//		 Si num_fila = TotalUtilizados(), "nueva_fila" ser� la nueva 
	//		 �ltima fila (el resultado ser� equivalente al de "Aniade()" 
	
	void Inserta (int num_fila, SecuenciaEnteros fila_nueva)
	{
		int numero_columnas_fila_nueva = fila_nueva.TotalUtilizados();
					
		// Precondiciones
		
		if ((filas_utilizadas < MAX_FIL) && 
			(numero_columnas_fila_nueva == cols_utilizadas) && 
			(0<=num_fila) && (num_fila <=filas_utilizadas)) {

			// "Desplazar" las filas hacia posiciones altas. 
			// La �ltima fila se copia en una NUEVA FILA que ocupa la 
			// posici�n "filas_utilizadas", la pen�ltima se copia en 
			// "filas_utilizadas"-1, ... y se queda un "hueco" en 
			// la fila "num_fila ".
			// NOTA: no se modifica (todav�a) "filas_utilizadas" 
			
			for (int fil=filas_utilizadas; fil>num_fila; fil--) 			
				vector_privado[fil]=vector_privado[fil-1];
			
			// Copiar en el "hueco" (fila "num_fila") el contenido de 
			// la secuencia "fila_nueva"
			
			vector_privado[num_fila]=fila_nueva;	
			
			filas_utilizadas++; // Actualizaci�n del tama�o de la tabla.
		}
	}

	/*****************************************************************/
	// Elimina una fila completa, dada una posici�n. 
	// 
	// Recibe: num_fila, la posici�n de la fila a eliminar.
	// PRE:  0 <= num_fila < TotalUtilizados()
	
	void Elimina (int num_fila)
	{		
		// Precondiciones
		
		if ((0<=num_fila) && (num_fila <=filas_utilizadas)) {

			// "Desplazar" las filas hacia posiciones bajas. 
			// En la posici�n "num_fila" se copia la que est� en la posici�n
			// siguiente ("num_fila"+1), en su lugar se copia que est� en 
			// "num_fila"+2, ... y en la posici�n "total_utilizados"-2 se 
			// copia la de "total_utilizados"-1. 
			
			for (int fil=num_fila; fil<filas_utilizadas-1; fil++) 
				vector_privado[fil]=vector_privado[fil+1];
			
			filas_utilizadas--; // Actualizaci�n del tama�o de la tabla.
		}
	}
	
	/*****************************************************************/
	// M�todo que busca en el vector de secuencias del objeto la secuencia  
	// m�s parecida a un vector de referencia entre unas secuencias 
	// determinadas del vector dato miembro, que vienen dadas por la secuencia 
	// filas_a_comparar
	
	// PRE: referencia.TotalUtilizados() = cols_utilizadas
	// PRE: 0 < filas_a_comparar.TotalUtilizados <= filas_utilizadas
	// PRE: filas_a_comparar.Elemento(i) 
	// con i = 0, 1,..., filas_a_comparar.TotalUtilizados() - 1 sea >= 0 y
	// <= filas_utilizadas - 1
	
	// Recibe: SecuenciaEnteros referencia, SecuenciaEnteros filas_a_comparar
	// Devuelve: SecuenciaEnteros resultado
	
	SecuenciaEnteros VectorSimilar (SecuenciaEnteros referencia, 
	SecuenciaEnteros filas_a_comparar)
	{
		double distancia = 0;
		double distancia_min = 0;
		SecuenciaEnteros resultado;
		
		// En caso de que solo hubiese una fila con la que comparar, se 
		// establece la distancia m�nima calculando la distancia eucl�dea
		// con respecto a la primera fila y se inicializa la secuencia
		// resultado con los valores de la primera fila (en este caso por
		// fila nos referimos a secuencia)
		
		for (int i = 0; i < cols_utilizadas; i++){
			
			distancia_min += 
			pow((referencia.Elemento(i)-
			Elemento(filas_a_comparar.Elemento(0), i)), 2);
		}
		
		distancia_min = sqrt(distancia_min);
		
		for (int i = 0; i < cols_utilizadas; i++){
			
			resultado.Aniade(Elemento(filas_a_comparar.Elemento(0), i));
		}
		
		// En caso de que haya m�s de una secuencia con la que comparar, se
		// repite el proceso anterior a partir de la segunda secuencia.
		
		for (int i = 1; i < filas_a_comparar.TotalUtilizados(); i++){
			
			for (int j = 0; j < cols_utilizadas; j++){
				
				distancia += 
				pow ((referencia.Elemento(j)
				-Elemento(filas_a_comparar.Elemento(i), j)), 2);
			}
			
			distancia = sqrt(distancia);
			
			// En caso de que la distancia que se calcule sea menor que la 
			// la distancia m�nima, esta se actualiza, se borra lo que hab�a en 
			// la secuencia resultado y se le introducen los valores de la 
			// �ltima secuencia estudiada.
			
			if (distancia < distancia_min){
				
				distancia_min = distancia;
				resultado.EliminaTodos();
				
				for (int k = 0; k < cols_utilizadas; k++){
					
					resultado.Aniade(Elemento(filas_a_comparar.Elemento(i), k));
				}
			}
			
			// Tras todo este proceso, se borra la distancia calculada para
			// la siguiente iteraci�n
			
			distancia = 0;
		}
		
		return (resultado);
	}
	/*****************************************************************/
	// Representa mediante un dato string el estado del objeto. En este 
	// caso, muestra los elementos de cada secuencia del vector dato miembro
	// del objeto dispuestos por filas y columnas
	
	string ToString (void)
	{
		string cad;
		
		for (int i = 0; i < filas_utilizadas; i++){
			
			cad+= vector_privado[i].ToString() + "\n";
		}
		
		return(cad);
	}
};

//////////////////////////////////////////////////////////////////////////////

class Lector
{
	private:
		
		string titulo;
	
	public:
		
		// Constructor sin argumentos
		
		Lector (void) : titulo ("")
		{ }
		
		// Constructor con argumentos
		
		Lector (string cad) : titulo (cad)
		{ }
		
		// M�todo Set para fijar el campo "titulo"
		
		void SetTitulo (string cad)
		{
			titulo = cad;
		}
		
		/*********************************************************************/
		// Lee un dato int.
		// La lectura est� etiquetada con "titulo"
		// La lectura se efect�a repetidamente hasta que se introduce un valor
		// int correcto.
		
		int LeeEntero (void)
		{
			string cadena;
			
			do{
				cout << titulo;
				getline(cin, cadena);
			}
			while (!EsEntero(cadena));
			
			return (stoi(cadena));
		}
		
		/*********************************************************************/
		// Lee un dato int.
		// La lectura est� etiquetada con "titulo"
		// PRE: menor <= mayor
		// POST: menor <= valor devuelto <= mayor
		
		int LeeEnteroEnRango (int menor, int mayor)
		{
			int numero;
			
			do{
				
				numero = LeeEntero ();
			}
			while ((numero<menor) || (numero>mayor));
			
			return (numero);
		}
		
		/*********************************************************************/
		// Lee un dato int que debe ser mayor o igual que "menor" y lo devuelve.
		// La lectura est� etiquetada con "titulo"
		
		int LeeEnteroMayorOIgual (int menor)
		{
			int numero;
			
			do{
				numero = LeeEntero ();
			}
			while (numero < menor);
			
			return (numero);
		}
		
		/*********************************************************************/
		// Lee un dato double.
		// La lectura est� etiquetada con "titulo"
		// La lectura se efect�a repetidamente hasta que se introduce un valor
		// double correcto.
		
		double LeeReal (void)
		{
			string cadena;
			
			do{
				cout << titulo;
				getline(cin, cadena);
			}
			while (!EsReal(cadena));
			
			return (stod(cadena));
		}
		
		/*********************************************************************/
		// Lee un dato double.
		// La lectura est� etiquetada con "titulo"
		// PRE: menor <= mayor
		// POST: menor <= valor devuelto <= mayor
		
		double LeeRealEnRango (int menor, int mayor)
		{
			double numero;
			
			do{
				
				numero = LeeReal ();
			}
			while ((numero<menor) || (numero>mayor));
			
			return (numero);
		}

		/*********************************************************************/
		// Lee un dato double que debe ser mayor o igual que "menor" y lo 
		// devuelve. 
		// La lectura est� etiquetada con "titulo"
		
		double LeeRealMayorOIgual (int menor)
		{
			double numero;
			
			do{
				numero = LeeReal ();
			}
			while (numero < menor);
			
			return (numero);
		}

		/*********************************************************************/
		
		/*********************************************************************/
		// Devuelve "true" si "cadena" es la representaci�n textual de un
		// entero
		//
		// Recibe: cadena, string sobre la que se va a trabajar.
		// Devuelve: "true" si "cadena" es la representaci�n textual de un int
	
	private:
		
		/*********************************************************************/
		// Devuelve una NUEVA cadena, resultante de eliminar los �ltimos
		// caracteres separadores de "cadena". Los caracteres separadores son
		// el espacio en blanco, el tabulador y el salto de l�nea.
		// Usaremos la funci�n isspace() para simplificar el c�lculo.
		//
		// Recibe: cadena, string sobre la que se va a trabajar.
		// Devuelve: el resultado de eliminar los �ltimos separadores de 
		// "cadena"
		/*********************************************************************/
		
		string EliminaUltimosSeparadores (string cadena)
		{
			while (cadena.length()>0 && isspace(cadena.back()))
				cadena.pop_back();
			
			return (cadena);
		}
		
		/*********************************************************************/
		// Devuelve una NUEVA cadena, resultante de eliminar los primeros
		// caracteres separadores de "cadena". Los caracteres separadores son
		// el espacio en blanco, el tabulador y el salto de l�nea.
		// Usaremos la funci�n isspace() para simplificar el c�lculo.
		//
		// Recibe: cadena, string sobre la que se va a trabajar.
		// Devuelve: el resultado de eliminar los �ltimos separadores de 
		// "cadena"
		/*********************************************************************/
		string EliminaPrimerosSeparadores (string cadena)
		{
			// Buscar el primer car�cter no espacio
			unsigned int pos = 0;
			while (pos < cadena.length() && isspace(cadena.at(pos))) pos++;
			
			string local;
			
			// Copiar todos los que quedan
			while (pos < cadena.length()) {
				local.push_back(cadena.at(pos));
				pos++;
			}
			
			return (local);
		}
		
		/*********************************************************************/
		// Devuelve una NUEVA cadena, resultante de eliminar los primeros 
		// �ltimos caracteres separadores de "cadena". Los caracteres 
		// separadores son el espacio en blanco, el tabulador y el salto de
		// l�nea
		//
		// Recibe: cadena, string sobre la que se va a trabajar.
		// Devuelve: el resultado de eliminar los primeros y los �ltimos
		//           separadores de "cadena".
		/*********************************************************************/
		
		string EliminaPrimerosYUltimosSeparadores (string cadena)
		{
			string cadena_podada = EliminaPrimerosSeparadores (cadena);
			cadena_podada = EliminaUltimosSeparadores (cadena_podada);
			
			return (cadena_podada);
		}
		
		/*********************************************************************/

		bool EsReal (string cadena)
		{
			bool es_real = true;
			
			cadena = EliminaPrimerosSeparadores (cadena);
			cadena = EliminaUltimosSeparadores (cadena);
			
			unsigned int long_cadena = cadena.length();
			
			if (long_cadena == 0) es_real = false;
			else {
				
				// Si el primer car�cter es '+' � '-', perfecto. En ese caso
				// se pasa al siguiente car�cter (posici�n 19.
				
				unsigned int pos;
				if (cadena.at(0)=='-' || cadena.at(0) == '+') pos = 1;
				else pos = 0;
				
				// Bandera que se activa al encontrar un punto
				bool encontrado_un_punto = false;
				
				while ((pos < long_cadena) && es_real) {
					
					char c = cadena.at(pos);
					
					if (!isdigit(c)) {
						
						// Solo puede haber un punto.
						// Si se ha encontrado un punto y ya se hab�a
						// encontrado otro, error. Si no, activar la bandera
						// "encontrado_un_punto" (ya no puede haber m�s).
						
						if (c == '.') {
							if (encontrado_un_punto) es_real = false;
							else encontrado_un_punto = true;
						}
						
					    // Si no es un punto ni un d�gito --> error
						else es_real = false;
					}
					
					pos++;
					
				}  // while ((pos < long_cadena) && es_real)
				
			}  // else de if (long_cadena == 0)
			
			return (es_real);
		}
		
		bool EsEntero (string cadena)
		{
			bool es_entero = true;
			
			cadena = EliminaPrimerosSeparadores (cadena);
			cadena = EliminaUltimosSeparadores (cadena);
			
			unsigned int long_cadena = cadena.length();
			
			if (long_cadena == 0) es_entero = false;
			else {
				
				// Si el primer car�cter es '+' � '-', perfecto. En ese caso
				// se pasa al siguiente car�cter (posici�n 19.
				
				unsigned int pos;
				if (cadena.at(0)=='-' || cadena.at(0) == '+') pos = 1;
				else pos = 0;
				
				while ((pos < long_cadena) && es_entero) {
					if(!isdigit(cadena.at(pos))) es_entero = false;
					else pos++;
				}
			}
			
			return (es_entero);
		}
};

int main() // Programa principal
{
	// Declaraci�n de datos
	
	int filas_utilizadas;
	int cols_utilizadas;
	const int MAX_FIL = 50;
	const int MAX_COL = 40;
	Lector lector;
	int tamanio_posiciones;
	
	// Entrada de datos
	
	cout << "B�SQUEDA DE LA FILA M�S PR�XIMA A UN VECTOR DE REFERENCIA DADO";
	cout << endl << endl;
	
	lector.SetTitulo("N� de filas de su matriz: ");
	filas_utilizadas = lector.LeeEnteroEnRango(1, MAX_FIL);
	
	lector.SetTitulo("N� de columnas de su matriz: ");
	cols_utilizadas = lector.LeeEnteroEnRango(1, MAX_COL);
	
	TablaRectangularEnteros tabla (cols_utilizadas);
	
	lector.SetTitulo("Introduzca un n�mero real: ");
	SecuenciaEnteros a_aniadir;
	
	for (int i = 0; i < filas_utilizadas; i++){
		
		cout << endl;
		cout << "Introduzca los valores de la fila " + to_string(i) + ": ";
		cout << endl;
		
		for (int j = 0; j < cols_utilizadas; j++){
			
			a_aniadir.Aniade(lector.LeeEntero());
		}
		
		tabla.Aniade(a_aniadir);
		
		a_aniadir.EliminaTodos();
	}
	
	// Mostrar matriz
	
	cout << endl;
	cout << tabla.ToString() << endl;
	
	// Entrada del vector de referencia a comparar
	
	cout << "Introduzca el vector a comparar en la matriz: " << endl;
	lector.SetTitulo("Introduzca un n�mero entero: ");
	
	SecuenciaEnteros referencia;
	
	for (int i = 0; i < cols_utilizadas; i++)
		referencia.Aniade(lector.LeeEntero());
	
	cout << endl;
	
	// Entrada del vector de filas a comparar
	
	cout << "Introduzca el n� de filas entre las que se va a buscar: " << endl;
	tamanio_posiciones = lector.LeeEnteroEnRango(1, filas_utilizadas);
	lector.SetTitulo("Introduzca la posici�n: ");
	
	SecuenciaEnteros posiciones;
	
	for (int i = 0; i < tamanio_posiciones; i++){
		
		posiciones.Aniade(lector.LeeEnteroEnRango(0, filas_utilizadas-1));
	}
	
	// C�lculos
	
	SecuenciaEnteros fila_similar (tabla.VectorSimilar(referencia, posiciones));
	
	// Salida de resultados
	
	cout << endl << endl;
	cout << "La fila m�s similar al vector introducido es: " << 
	fila_similar.ToString() << endl << endl;
	
	return 0;
}
