/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa se encarga de calcular la velocidad, el ritmo y las horas, minutos
y segundos que emplea un corredor en una determinada carrera. Los datos de 
entrada en este caso son la distancia a recorrer en la carrera, las horas,
minutos y segundos del inicio, el dorsal del corredor y las horas, minutos y 
segundos de llegada. 

Para asegurarme de que el usuario introduce los segundos, minutos, horas y 
distancia en su rango correspondiente, he creado funciones antes del programa
principal que solicitan nuevamente los datos si est�n fuera de su rango. Tras
esto, el siguiente dato a introducir es el dorsal y caben 3 posibilidades:

1. El dorsal sea negativo. En ese caso el bucle no se ejecuta y se imprime en
pantalla el mensaje "el programa ha finalizado".
2. El dorsal sea positivo, por lo que el corredor desea saber sus estad�sticas.
Entonces se solicitan las horas, minutos y segundos de llegada (con sus 
respectivas funciones como filtros, son las mismas que las empleadas para las 
horas, minutos y segundos de inicio) y ya se toman en cuenta 3 posibilidades, 
las cuales he a�adido mediante estructuras condicionales simples:

2.1. El corredor ha empezado y llegado el mismo d�a.
2.2. El corredor ha empezado y llegado en d�as distintos, por lo que se deben
reajustar algunos c�lculos.
2.3. El corredor ha introducido el mismo instante de inicio que de salida.

Finalmente, se imprimen los datos en pantalla y se solicita un nuevo dorsal, y 
en funci�n de si este es negativo o de si es 0 o positivo, el programa 
finalizar� o se llevar�n a cabo todas las acciones anteriormente mencionadas.
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recursos de E/S

using namespace std;

// Creaci�n de funciones que filtran horas, minutos y segundos

void HorasBien (int dato){
	while(dato < 0 || dato > 23){
		cout << "Vuelva a introducir las horas: ";
		cin >> dato;
	}
}

void MinutosBien (int dato){
	while (dato < 0 || dato > 59){
		cout << "Vuelva a introducir los minutos: ";
		cin >> dato;
	}
}

void SegundosBien (int dato){
	while (dato < 0 || dato > 59){
		cout << "Vuelva a introducir los segundos: ";
	}
}

int main () // Programa principal
{
		// Declaraci�n de datos
	
	int horas1;
	int minutos1;
	int segundos1;
	int segundos_iniciales; // Segundos totales del momento de inicio
	double distancia;
	int dorsal;
	int horas2;
	int minutos2;
	int segundos2;
	int segundos_finales; // Segundos totales del momento de llegada
	int segundos_totales; // Diferencia en segundos entre el inicio y la llegada
	double minutos_totales; // Minutos entre el inicio y la llegada, los uso
	                        // para hallar el ritmo
	double horas_totales; // Horas entre el inicio y la llegada, las uso
	                      // para hallar la velocidad
	int segundos_salida;
	int minutos_salida;
	int horas_salida;
	double velocidad; // km/h
	double ritmo; // min/km
	
	// Entrada del dato horas1 y filtro
	
	cout << "Introduzca las horas del inicio de la carrera: ";
	cin >> horas1;
	
	HorasBien (horas1);
	
	// Entrada del dato minutos1 y filtro
	
	cout << "Introduzca los minutos del inicio de la carrera: ";
	cin >> minutos1;
	
	MinutosBien (minutos1);
	
	// Entrada del dato segundos1 y filtro
	
	cout << "Introduzca los segundos del inicio de la carrera: ";
	cin >> segundos1;
	
	SegundosBien (segundos1);
	
	// Entrada del dato distancia y filtro
	
	do{
		cout << "Introduzca la distancia a recorrer en la carrera: ";
		cin >> distancia;
	}
	while (distancia <= 0);
	
	// Entrada del dato dorsal
	
	cout << "Introduzca el n� de su dorsal: ";
	cin >> dorsal;
	
	// 
	
	bool dorsal_bien = dorsal>= 0;
	
	while (dorsal_bien){
		
		// Entrada de horas2, minutos2 y segundos2 con filtros
		
		cout << "Introduzca las horas de llegada: ";
		cin >> horas2;
		
		HorasBien (horas2);
		
		cout << "Introduzca los minutos de llegada: ";
		cin >> minutos2;
		
		MinutosBien (minutos2);
		
		cout << "Introduzca los segundos de llegada: ";
		cin >> segundos2;
		
		SegundosBien (segundos2);
	
		// C�lculos 
		
		segundos_iniciales = horas1*3600 + minutos1*60 + segundos1;
		segundos_finales = horas2*3600 + minutos2*60 + segundos2;
		segundos_totales = segundos_finales - segundos_iniciales;
		
		// Consideraci�n de tres casos posibles
		
		// 1. Empieza y termina la carrera el mismo d�a
		
		if (segundos_totales > 0){
			
			// C�lculo de datos de salida
			
			segundos_salida = segundos_totales%60;
			minutos_salida = (segundos_totales/60)%60;
			horas_salida = ((segundos_totales/60)/60)%24;
			
			minutos_totales = segundos_totales/60.0;
			ritmo = minutos_totales/distancia;
			
			horas_totales = (segundos_totales/60.0)/60.0;
			velocidad = distancia/horas_totales;
			
			// Salida de datos
			
			cout << endl;
			cout << "Ha completado la carrera en " << horas_salida << " horas "
			<< minutos_salida << " minutos " << segundos_salida << " segundos";
			cout << endl;
			cout << "Su ritmo ha sido de " << ritmo << " min/km";
			cout << endl;
			cout << "Su velocidad ha sido de " << velocidad << " km/h";
		}
		
		// 2. Empieza y termina la carrera en d�as distintos
		
		if (segundos_totales < 0){
			
			// C�lculo de los segundos totales transcurridos en realidad
			
			int SEGS_DIA = 86400;
			segundos_totales=(SEGS_DIA - segundos_iniciales) + segundos_finales;
			
			// C�lculo de datos de salida
			
			segundos_salida = segundos_totales%60;
			minutos_salida = (segundos_totales/60)%60;
			horas_salida = ((segundos_totales/60)/60)%24;
			
			minutos_totales = segundos_totales/60.0;
			ritmo = minutos_totales/distancia;
			
			horas_totales = (segundos_totales/60.0)/60.0;
			velocidad = distancia/horas_totales;
			
			// Salida de datos
			
			cout << endl;
			cout << "Ha completado la carrera en " << horas_salida << " horas "
			<< minutos_salida << " minutos " << segundos_salida << " segundos";
			cout << endl;
			cout << "Su ritmo ha sido de " << ritmo << " min/km";
			cout << endl;
			cout << "Su velocidad ha sido de " << velocidad << " km/h";
		}
		
		// 3. El instante inicial y final son el mismo
		
		if (segundos_totales == 0){
			
			cout << endl;
			cout << "Acaba de empezar la carrera";
		}
		
		// Se introduce un nuevo dorsal
		
		cout << endl;
		cout << "Introduzca el n� de su dorsal: ";
		cin >> dorsal;
		
		// Actualizaci�n de la condici�n
		
		dorsal_bien = dorsal>= 0;
		
	}
	
	if (!dorsal_bien){
		cout << endl;
		cout << "El programa ha finalizado";
	}
	
	return 0;
	
}
