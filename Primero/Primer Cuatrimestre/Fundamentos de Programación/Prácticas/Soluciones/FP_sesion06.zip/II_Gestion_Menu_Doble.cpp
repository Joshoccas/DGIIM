/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/*
Este programa consiste en un men� de m�ltiple opci�n cuya funci�n principal es
el c�lculo de una operaci�n elemental (suma, resta, multiplicaci�n o divisi�n)
de dos valores introducidos por el usuario. En el men� principal se presentan
3 opciones:

1. A (Adici�n): Si se elige esta opci�n, aparecer� un men� secundario que 
muestra otras tres opciones:

    1.1. S (Suma): Si se elige esta operaci�n, se piden dos n�meros y se halla
    su suma. Tras esto, se vuelve a mostrar el men� secundario de adici�n.
    
    1.2. R (Resta): Si se elige esta operaci�n, se piden dos n�meros y se halla
    su resta. Tras esto, se vuelve al men� secundario de adici�n.
    
    1.3. X (Salir): Si se elige esta opci�n, se vuelve al men� principal.
    
2. P (Producto): Aparecer� un men� secundario que muestra otras tres opciones:

    2.1. M (Multiplicaci�n): Si se elige esta operaci�n, se piden dos n�meros
    y se halla su multiplicaci�n. Tras esto, se vuelve al men� secundario de
    producto.
    
    2.2. D (Divisi�n): Si se elige esta operaci�n, se piden dos n�meros
    y se halla su divisi�n. Tras esto, se vuelve al men� secundario de
    producto.
    
    2.3. X (Salir): Si se elige esta opci�n, se vuelve al men� principal.
    
3. X (Salir): El programa finaliza al escoger esta opci�n.
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recursos de E/S
#include <string> 

using namespace std;

int main() // Programa principal
{
	// Declaraci�n de datos
	
	double valor1; // Son los n�meros que introduce el usuario y con los que
	double valor2; // opera el programa
	
	char selecciona; // Son datos de tipo char con los que se selecciona el
	char selecciona2; // men� secundario y la operaci�n a realizar
	
	double suma;    // Son las cuatro operaciones que puede realizar el programa
	double resta;   // y en este caso son los datos de salida
	double multiplicacion;
	double division;
	
	// Bucle principal 
	
	do{
		cout << endl;
		cout << "MEN� PRINCIPAL";
		cout << endl;
		cout << "A -> Calcular adici�n";
		cout << endl;
		cout << "P -> Calcular producto";
		cout << endl;
		cout << "X -> Salir";
		cout << endl;
		cout << "Seleccione la opci�n que desea ejecutar: ";
		cin >> selecciona;
		
		// Filtro
		
		while (!((selecciona == 'A') || (selecciona == 'P') || 
		(selecciona == 'X'))){
			cout << "Vuelva a seleccionar la opci�n: ";
			cin >> selecciona;
		}
		
		// Se consideran las tres opciones con una estructura condicional 
		// m�ltiple
		
		switch (selecciona){
			
			// 1er caso: Se ha elegido adici�n
			
			case ('A'):
				
				do{
					cout << endl;
					cout << "MEN� SECUNDARIO";
					cout << endl;
					cout << "S -> Calcular suma";
					cout << endl;
					cout << "R -> Calcular resta";
					cout << endl;
					cout << "X -> Salir";
					cout << endl;
					cout << "Seleccione la operaci�n que desea ejecutar: ";
					cin >> selecciona2;
					cout << endl;
					
					// Filtro
					
					while (!((selecciona2 == 'S') || (selecciona2 == 'R') || 
		            (selecciona2 == 'X'))){
			            cout << "Vuelva a seleccionar la operaci�n: ";
			            cin >> selecciona2;
		            }
		            
		            // Consideraci�n de las tres opciones
		            
		            switch (selecciona2){
		            	
		            	// Suma
		            	
		            	case ('S'):
		            		
		            		// Entrada de datos
		            		
		            		cout << "Introduzca el primer n�mero: ";
		            		cin >> valor1;
		            		cout << "Introduzca el segundo n�mero: ";
		            		cin >> valor2;
		            		
		            		// C�lculos
		            		
		            		suma = valor1 + valor2;
		            		
		            		// Salida de datos
		            		
		            		cout << endl;
		            		cout << "La suma es " << suma;
		            		cout << endl;
		            		
		            	break;
		            	
		            	// Resta
		            	
		            	case ('R'):
		            		
		            		// Entrada de datos
		            		
		            		cout << "Introduzca el primer n�mero: ";
		            		cin >> valor1;
		            		cout << "Introduzca el segundo n�mero: ";
		            		cin >> valor2;
		            		
		            		// C�lculos
		            		
		            		resta = valor1 - valor2;
		            		
		            		// Salida de datos
		            		
		            		cout << endl;
		            		cout << "La resta es " << resta;
		            		cout << endl;
		            		
		            	break;
		            	
		            	// Salir
		            	
		            	case ('X'):
		            		
		            	break;
		            }
		        }
		    
			// Este men� secundario de adici�n seguir� mostr�ndose hasta que 
			// se seleccione X. Es por ello que la condici�n del siguiente bucle
			// es que se ejecute mientras que no se haya escogido X en el men�
			// secundario de adici�n. De esa forma, se logra volver al men� 
			// principal sin que se ejecute el men� secundario del producto.
			    
		    while (selecciona2 != 'X');
		    
			// Si en el men� principal se ha elegido P, selecciona2 estar� 
			// vac�o, por lo que la condici�n de este bucle se cumplir� siempre
			// y siempre se entrar� al bucle
			    
		    while (selecciona2 != 'X'){
		        
				// 2o caso: Se ha elegido el producto
					
		        case ('P'):
		      	
		        	do{
		        		cout << endl;
		        		cout << "MEN� SECUNDARIO";
		        		cout << endl;
		        		cout << "M -> Calcular multiplicaci�n";
		        		cout << endl;
		        		cout << "D -> Calcular divisi�n";
		        		cout << endl;
		        		cout << "X -> Salir";
		        		cout << endl;
		        		cout << "Seleccione la operaci�n que desea ejecutar: ";
		        		cin >> selecciona2;
		        		cout << endl;
		        		
		        		// Filtro
		        		
		        		while (!((selecciona2 == 'M') || (selecciona2 == 'D') || 
		                (selecciona2 == 'X'))){
			            cout << "Vuelva a seleccionar la operaci�n: ";
			            cin >> selecciona2;
		                }
		        		
		        		// Consideraci�n de las tres opciones
		        		
		        		switch (selecciona2){
		        			
		        			// Multiplicaci�n
		        			
		        			case ('M'):
		        				
		        				// Entrada de datos
		        				
		        				cout << "Introduzca el primer n�mero: ";
		        				cin >> valor1;
		        				cout << "Introduzca el segundo n�mero: ";
		        				cin >> valor2;
		        				
		        				// C�lculos
		        				
		        				multiplicacion = valor1 * valor2;
		        				
		        				// Salida de datos
		        				
		        				cout << "El multiplicaci�n es " 
								<< multiplicacion;
								cout << endl;
		        			
		        			break;
		        			
		        			// Divisi�n
		        			
		        			case ('D'):
		        				
		        				// Entrada de datos
		        				
		        				cout << "Introduzca el primer n�mero: ";
		        				cin >> valor1;
		        				cout << "Intoduzca el segundo n�mero: ";
		        				cin >> valor2;
		        				
		        				// Filtro
		        				
		        				while (valor2 == 0){
		        					cout << "Vuelva a introducir el segundo "
		        					<< "n�mero: ";
		        					cin >> valor2;
		        				}
		        				
		        				// C�lculos
		        				
		        				division = valor1 / valor2;
		        				
		        				// Salida de datos
		        				
		        				cout << "La divisi�n es " << division;
		        				cout << endl;
		        				
		        			break;
		        			
		        			// Salir
		        			
		        			case ('X'):
		        				
		        			break;
		        		}
		        	}
		        	
		        	// La condici�n del bucle tiene la misma explicaci�n que 
		        	// para el bucle del men� secundario de adici�n. Solo 
		        	// dejar� de mostrarse el men� secundario del producto 
		        	// cuando se seleccione X. Entonces, el caso cuando se elige
		        	// P en el men� principal habr� finalizado y se volver� a
		        	// mostrar el men� principal
		        	
		        	while (selecciona2 != 'X');
		    }
		 
		// 3er caso: Se ha elegido salir del men� principal 
		    
		case ('X'):
		
		break;       
		}
	}
	
	// El bucle principal que comienza mostrando el men� principal se dejar�
	// de ejecutar cuando se haya elegido X en el men� principal
	
	while (selecciona != 'X');
	
	// Si se ha elegido salir del men� principal, se muestra en pantalla que
	// el programa ha finalizado
	
	if ((selecciona = 'X')){
		cout << "El programa ha finalizado";
	}
	
	return 0;
}
		        	
		        	
		        	
		        				
		        				
		        	
		        	
		        
		        
		            
		            
	
