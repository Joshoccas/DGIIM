/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa pide la media y la desviaci�n t�pica de una funci�n gaussiana y
lleva a cabo tres c�lculos:

1. Calcula todos los valores de x que toma la funci�n en el intervalo 
[media - 3*desv_tipica, media + 3*desv_tipica]

2. Calcula la distribuci�n acumulada CDF mediante el c�lculo del �rea bajo la
curva mediante la suma de �reas de rect�ngulos, basada en la integral de menos
infinito hasta x.

3. Calcula distribuci�n acumulada CDF mediante un m�todo de aproximaci�n.

Para cada tarea que realiza he creado una funci�n .
*/
/*****************************************************************************/

#include <iostream>   // Inclusi�n de los recursos de E/S
#include <cmath>      // Inclusi�n de los recursos matem�ticos
#include <iomanip>

using namespace std; 


// Creaci�n de las funciones necesarias

// 1. C�lculo del valor que toma la funci�n gaussiana en un valor de abscisa

double Gaussiana(double x, double media, double desv_tipica){
	
	const double PI =  6 * asin(0.5);
	
	double exponente_de_e = -0.5*(pow((x-media)/desv_tipica,2));
	
	return ((1/(desv_tipica*sqrt(2*PI)))*exp(exponente_de_e));
}
	
// 2. C�lculo de CDF (para el apartado B), basado en el programa de la 
// semana pasada

double CDF_B(double desv_tipica, double media, double SALTO){
	
	double cdf = 0; // El �rea inicialmente es 0, y es el valor que debe 
	                // calcular esta funci�n
	double x_inicial = media - 3 * desv_tipica;
	double x_final = media + 3 * desv_tipica;
	double x = x_inicial; // El �rea se empieza a calcular desde x_inicial
	bool sigue = true; // Lo inicializamos con true para que entre al menos
	                   // una vez al bucle
	double area;
	
	while (sigue){
		
		// CDF se puede calcular como la suma de todos los rect�ngulos de 
		// ancho SALTO y de altura el valor de la gaussiana para cada valor
		// de abscisa desde x_inicial hasta x_final
		
		area = Gaussiana(x, media, desv_tipica) * SALTO;
		cdf = cdf + area;
		
		x = x + SALTO;
		
		sigue = x <= x_final;
	}

	return (cdf);
}

// 3. C�lculo de CDF (para el apartado C), basado en la f�rmula proporcionada
// en el ejercicio 29 del gui�n de pr�cticas

double CDF_C(double x, double media, double desv_tipica){
	
	const double b0 = 0.2316419;
	const double b1 = 0.319381530;
	const double b2 = -0.356563782;
	const double b3 = 1.781477937;
	const double b4 = -1.821255978;
	const double b5 = 1.330274429;	
	double x_estandarizada;
	
	double t = 1/(1+b0*fabs(x));
	x_estandarizada = ((x - media)/desv_tipica);
	double g_x = Gaussiana(fabs(x_estandarizada), 0, 1);
	
	double cdf;
	
	cdf = 1-g_x*(b1*t+b2*pow(t,2)+b3*pow(t,3)+b4*pow(t,4)+b5*pow(t,5));
	
	// En caso de que CDF sea negativa
	
	if (cdf<0)
		cdf = 1 - cdf;	
	
	
	return (cdf);
}

int main()
{
	
	//Declaraci�n de datos
	
	double media;
	double desv_tipica;
	double x;
	double g_x; // Se imprimir� en pantalla muchas veces, es el dato de salida
	            // del apartado a
	double cdf_b; // Es el dato de salida del apartado b
	double cdf_c; // Es el dato de salida del apartado c
	const double SALTO = 0.25;
	double x_inicial;
	double x_final;
	
	//Entrada de datos
	
	cout << "Introduzca el valor de la media: ";
	cin >> media;
	
	// Filtro para la desviaci�n t�pica
	
	do{
		
		cout << endl;
		cout << "Introduzca el valor de la desviacion tipica: ";
		cin >> desv_tipica;
		
	}while (desv_tipica <= 0);
	
	
	x_inicial = media - 3*desv_tipica;
	x_final = media + 3*desv_tipica;
	x = x_inicial;
	
	// C�lculos y salida de datos para el apartado a
	
	while (x <= x_final){
		
		g_x = Gaussiana(x,media, desv_tipica);
		cout << "g(" << x << ") = " << g_x;
		cout << endl;
		x = x + SALTO;
	}
	
	
	cdf_b = CDF_B(desv_tipica,media,SALTO);
	cdf_c = CDF_C(x,media,desv_tipica);
	
	// Salida de datos de los apartados b y c
	
	cout << endl;
	cout << "La CDF(" << x << ") es igual a " << cdf_b ;
	cout << endl;
	cout << "La aproximacion a CDF(" << x << ") es igual a " << cdf_c;
	
	
	return 0;
}
