/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa consiste en un juego de adivinar un n�mero. El programa genera un
n�mero aleatorio entre el 1 y el 100 y el usuario introduce un n�mero 
cualquiera. Entonces, caben 4 posibilidades:

1. El usuario no quiere jugar y por ello introduce -1, que es nuestro 
terminador. En este caso, el bucle no se ejecuta y se avisa de que se ha
abandonado el juego. Se preguntar� si desea jugar de nuevo.
2. El usuario introduce un n�mero v�lido, y caben tres posibilidades:

2.1. Que haya acertado, por lo que no entra al bucle y directamente se
imprime el mensaje de acierto, en el que se descubre el n�mero adivinado.
Tras esto, se pregunta si quiere jugar de nuevo.
2.2. Que el n�mero sea menor que la inc�gnita, se informe al usuario e 
introduzca un nuevo n�mero, que ser� sometido al mismo proceso que el �ltimo
n�mero introducido.
2.3. Que el n�mero sea mayor que la inc�gnita, se informe al usuario e 
introduzca un nuevo n�mero, que ser� sometido al mismo proceso que el �ltimo
n�mero introducido.

La �nica diferencia con la anterior versi�n del programa es que la opci�n de 
volver a jugar tras finalizar el juego se implementa mediante una funci�n que
devuelve un dato de tipo bool que es la condici�n del bucle principal. Si ese
dato es true, el bucle se vuelve a ejecutar y se inicia el juego. Si es false, 
no se entra al bucle y el programa finaliza su ejecuci�n.
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recursos de E/S
#include <ctime>
#include <cstdlib>

using namespace std;

// Creaci�n de la funci�n que devuelve el dato de tipo bool que determina la
// condici�n de la que depende el bucle

bool LeeOpcion2Alternativas (char dato){
	
	do{
		cout << endl;
		cout << "�Quiere jugar? Si la respuesta es s�, pulse S o s. "
		<< "Si la respuesta es no, pulse N o n: ";
		cin >> dato;
	}
	while ((dato != 'S') && (dato != 's') && (dato != 'N') && (dato != 'n'));
	
	bool jugar_otra_vez = ((dato == 'S') || (dato == 's'));
	
	return (jugar_otra_vez);
}

int main() // Programa principal
{
	// Declaraci�n de datos
	
	int numero;
	int incognita; // N�mero aleatorio a generar
	const int MIN = 1;
	const int MAX = 100;
	const int NUM_VALORES = MAX - MIN + 1;
	const int TERMINADOR = -1;
	char respuesta; // Podr� ser 'S', 'N', 's' 0 'n'. Si se pulsa S o s, se
	                // vuelve a iniciar el juego. Si se pulsa N o n, finaliza
	                // el programa
	
	while (LeeOpcion2Alternativas (respuesta)){
		
		    // Se establecen los datos de tipo bool que determinan las 
		    // condiciones de mis bucles
		    
		    bool rango_bien;
		    bool numero_bien;
		
			// Entrada de datos
	
	        time_t t;
	        srand(time(&t)); // Inicializa el generador de n�ms.aleatorios
	                         // con el reloj del sistema (hora actual)
	
	        // Generaci�n de la inc�gnita (MIN <= incognita <= MAX)
	
	        incognita = (rand() % NUM_VALORES) + MIN;
	
	        // Entrada del dato n�mero
	        
	        // Filtro para que el programa pida el n�mero nuevamente si en 
	        // la primera ejecuci�n se ha introducido un n�mero fuera del
	        // intervalo o distinto del terminador
	
	        do{
	        	cout << "Introduzca un n�mero: ";
	        	cin >> numero;
	        	
	        	// Inicializo las condiciones de las que depende el bucle
	        	
	        	rango_bien = ((numero >= MIN) && (numero <= MAX));
	        	numero_bien = ((rango_bien) || (numero == TERMINADOR));
	        }	
	        while (!numero_bien);
	        
	        // El siguiente bucle se ejecutar� hasta que se adivine el n�mero
	        // o se haya introducido el terminador para salir del juego
	        
	        while ((numero != incognita) && (numero != TERMINADOR)){
	        	
	        	if (numero < incognita){
	        		cout << "Su n�mero es menor que el que debe adivinar, "
	        		<< "pruebe otra vez";
	        	}
	        	
	        	if (numero > incognita){
	        		cout << "Su n�mero es mayor que el que debe adivinar, "
	        		<< "pruebe otra vez";
	        	}
	        	
	        	// Se pide un n�mero nuevo. He hecho un filtro para que el 
	        	// programa no deje avanzar hasta que se haya introducido
	        	// un n�mero del intervalo o se haya introducido el terminador
	        	
	        	do{
	        		cout << endl;
	        		cout << "Introduzca un n�mero nuevo: ";
	        		cin >> numero;
	        		
	        		// Inicializo las condiciones de las que depende el bucle
	        		
	        		rango_bien = ((numero >= MIN) && (numero <= MAX));
	        		numero_bien = ((rango_bien) || (numero == TERMINADOR));
	        	}	        		
	        	while (!numero_bien);
	        }
	        
	        // Salida de resultados
	        
	        if (numero == incognita){
	        	cout << endl;
	        	cout << "Ha acertado el n�mero a adivinar";
	        }
	        
	        else{
	        	cout << endl;
	        	cout << "Usted ha abandonado el juego";
	        }
	
	}
	
	return 0;
	        
}
	
