/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa tiene como funci�n principal el c�lculo de la aproximaci�n del
n�mero �ureo a una cota de error indicada por el usuario y que debe ser menor
que 1 (lo cual se regula mediante un filtro). Tambi�n imprime en pantalla el
menor valor de n necesario para llegar a la aproximaci�n de la precisi�n 
indicada que se calcula como el cociente de dos t�rminos de la sucesi�n
de Fibonacci de la siguiente forma:


                                T�rmino (n+1) de la sucesi�n
             Aproximacion(n) = -------------------------------
                                T�rmino n de la sucesi�n
                                
                    
Para resolverlo me he basado en el ejercicio resuelto del n�mero �ureo 
proporcionado por el profesor esta semana. Solo le he tenido que quitar aquellos
bucles en los que se efectuaban los c�lculos y los he metido en funciones
antes de el programa principal. Dichas funciones las he metido donde estaban
anteriormente los bucles de c�lculos y el efecto es el mismo.
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recursos de E/S
#include <cmath> // Inclusi�n de los recursos matem�ticos
#include <iomanip>

using namespace std;

// Creaci�n de las funciones necesarias para el programa

// 1. C�lculo del t�rmino n de la sucesi�n de Fibonacci (TerminoFibonacci)

int TerminoFibonacci (int n){
	
	int termino_ant;
	int termino_ant_ant;
	int resultado;
	
	// Los dos primeros t�rminos de la sucesi�n valen 1 ambos
	
	termino_ant_ant = 1; // T�rmino 1
	termino_ant = 1; // T�rmino 2
	
	for (int i = 2; i <= n; i++){
		
		resultado = termino_ant_ant + termino_ant;
		
		// Actualizamos los t�rminos para el c�lculo de la siguiente iteraci�n
		
		termino_ant_ant = termino_ant;
		termino_ant = resultado;
	}
	
	return (termino_ant_ant);
}

// 2. C�lculo de la aproximaci�n al n�mero �ureo como el cociente de dos 
// t�rminos de la sucesi�n de Fibonacci consecutivos

double Aproximacion (int n){
	
	return ((double)TerminoFibonacci(n+1) / TerminoFibonacci(n));
}

// 3. C�lculo de la diferencia entre la aproximaci�n calculado y el valor real
// del n�mero �ureo

double Diferencia (double n, double aureo){
	
    // |a(n) - PHI|
	
	return (fabs(Aproximacion(n) - aureo));
}

/*****************************************************************************/

int main() // Programa principal
{
	// Valor "real" de Phi: 1,6180339887...
	const double PHI = (1 + sqrt(5.0)) / 2.0; 

	cout.setf(ios::fixed);		// Notaci�n de punto fijo para los reales
	cout.setf(ios::showpoint);	// Mostrar siempre decimales 


	// Lectura de datos
	
	double Delta;	// Precisi�n de la aproximaci�n 	
	
	cout << "Calculando la aproximacion al numero Aureo = "
		 << setw(15) << setprecision(13) << PHI << endl << endl;
	
	// Filtro
	
	do {
		cout << "Introduzca la precision (< 1) deseada para la aproximacion: ";
		cin >> Delta;
	} while (Delta>=1);

	cout << endl; 
	
	
	// C�lculos
	
	// Inicializamos "sigo" con true para que entre al menos una vez al bucle
	// El primer valor a probar es n = 1, que se ir� aumentando hasta que la
	// condici�n del bucle sea falsa, es decir, hasta que la diferencia entre
	// la aproximaci�n y el n�mero �ureo sea inferior o igual a la diferencia
	// introducida
	
	
	double 	diferencia_anterior; 
	int n = 1;	// Resultado: �ndice del t�rmino buscado (1,2,3...)
	bool sigo = true; 

	while (sigo) {
				
		// Mensajes -optativos- 
		cout << "a_" << setw(3) << n << " = "
		     << setw(15) << setprecision(13) << Aproximacion(n);
		cout << " (Dif = " << setw(15) <<setprecision(13)
		     << Diferencia(n, PHI) << ")" << endl;
		
		// Evaluar criterio de parada
		
		if (Diferencia(n, PHI) <= Delta)
			sigo = false;
		else {
			
			// Si la diferencia es mayor que delta, se prueba con la siguiente
			// aproximaci�n para n + 1, por eso sumamos a n una unidad. Tambi�n
			// actualizamos la diferencia anterior 
			
			diferencia_anterior = Diferencia (n, PHI);
			n++;
		}
		
	} 
	
	// Salida de datos

	cout << endl;
	cout << "Valor buscado   = "
		 << setw(15) << setprecision(13) << PHI << endl;
	cout << "Valor calculado = "
		 << setw(15) << setprecision(13) << Aproximacion(n) << endl << endl;
	cout << endl;
	
	cout << "Menor valor de n = " << setw(3) << n << endl << endl; 
	cout << "Diferencia actual =   " << setw(15) << setprecision(8) 
		 << Diferencia (n, PHI) << endl;
	cout << "Precision =           " << setw(15) << setprecision(8)
		 << Delta << endl;;
	cout << "Diferencia anterior = " << setw(15) << setprecision(8) 
	     << diferencia_anterior << endl;	
	cout << endl << endl;
	
	return 0;
}

