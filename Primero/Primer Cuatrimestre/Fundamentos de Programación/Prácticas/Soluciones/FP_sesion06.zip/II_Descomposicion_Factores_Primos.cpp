/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa halla la descomposici�n en factores primos de un entero que es 
introducido por el usuario. Muestra dicha descomposici�n de dos formas:

Ejemplo
1. 9 = 3 * 3
2. 9 = 3^2

Para poder realizar este programa he hecho uso de anidamiento de bucles y 
estructuras condicionales. El primer bucle es un filtro para asegurar que el
usuario introduce un entero mayor que 1. Una vez introducido el entero, el
valor de ese entero se copia en otro dato que va a ser dividido todas las veces
posibles por 2, luego por 3 y as� sucesivamente hasta que n sea igual a 1 tras
las sucesivas divisiones. Seg�n se vaya pudiendo dividir por un factor primo,
ese primo se ir� imprimiendo en pantalla (en el caso del apartado B se ir�
sumando 1 al valor del exponente que luego se imprimir� en pantalla). Para 
que no apareciese delante del primer factor "*", he establecido una estructura
condicional que se ejecuta cuando contador = 0 y que imprime el primer factor
sin ir precedido de "*". Tras la primera impresi�n en pantalla, contador pasa
a valer 1 y ya siempre aparecer� cada nuevo factor precedido de "*".

*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recursos de E/S

using namespace std;

int main() // Programa prinicipal
{
	// APARTADO A
	
	// Declaraci�n de datos
	
	int entero;
	int n; // En �l copiamos el valor de entero
	int primo;
	int contador = 0; // Dato auxiliar que evita que aparezca "*" antes del 
	                  // primer factor
	
	// Entrada de datos
	
	// Filtro para asegurar que el entero introducido es mayor que 1
	
	do{
		cout << "Introduzca el entero cuya descomposici�n en factores "
		<< "primos desea saber: ";
		cin >> entero;
	}
	while (entero <= 1);
	
	// Inicializamos "primo" con el valor 2 ya que es el primer factor primo
	// que debemos probar
	
	primo = 2;
	
	// Copiamos el valor de "entero" en "n", dato con el que se trabaja
	
	n = entero;
	
	// Bucle principal con c�lculos
	
	while (n>1){
		
		// Mientras que el entero sea divisible por un primo en concreto, se
		// imprimir� en pantalla ese factor primo el n� de veces que sea
		// el entero introducido divisible por �l. Cuando ya no sea divisible,
		// se prueba con el siguiente factor y as� sucesivamente. El programa
		// finalizar� cuando n sea igual a 1
		
		while (n % primo == 0){
			
			// Si es la primera vez que se divide (es el primer factor), se
			// evita que aparezca "*" al principio con una estructura 
			// condicional. Se actualiza contador sum�ndole 1 para que a partir 
			// del pr�ximo factor en adelante, aparezca "*" al principio
			
			if (contador == 0){
				cout << primo;
			}
			
			else{
				cout << " * " << primo;
			}
			
			// Actualizamos el valor de n tras la primera divisi�n
			// Sumamos 1 al contador 
			
			n = n / primo;
			contador++;
		}
		
		primo++;
	}
	
	// APARTADO B
	
	// Declaraci�n de datos
	
	int exponente;
	int contador2 = 0; // Dato auxiliar que evita imprimir "*" en la primera
	                   // potencia
	int n2; // En �l copiamos el valor de entero
	int primo2;
	
	// La entrada de datos se omite ya que el entero ya fue introducido
	
	// Inicializamos el valor de exponente
	
	exponente = 0;
	
	// Inicializamos "primo" con el valor 2 ya que es el primer factor primo
	// que debemos probar
	
	primo2 = 2;
	
	// Copiamos el valor de "entero" en "n2", dato con el que se trabaja
	
	n2 = entero;
	
	// Metemos un salto de l�nea para que el resultado de este apartado no
	// salga en la misma l�nea que el anterior apartado
	
	cout << endl;
 
	// Bucle principal con c�lculos
	
	while (n2>1){
	
		while (n2 % primo2 == 0){
			
			// Si es divisible por "primo", sumamos 1 a "exponente". As�, si
			// es divisible 3 veces, exponente ser� igual a 3 y podremos 
			// imprimir en pantalla primo ^ exponente
			
			exponente++;
			
			// Actualizamos el valor de n tras la primera divisi�n
			
			n2 = n2 / primo2;
		}
		
		// Si n no se ha podido dividir ni una vez (exponente = 0), en pantalla
		// no imprimiremos nada, solo ""
		
		if (exponente ==  0){
			cout << "";
		}
		
		else{
			
			// Si se ha podido dividir alguna vez por primo, debemos tener en
			// cuenta de si es la primera potencia que se imprime en pantalla
			// o no. Si lo es (contador == 0), se imprime la potencia sin
			// ir precedida de "*" y se suma 1 al contador, para que en las
			// siguientes iteraciones s� se imprima al principio "*"
			
			if (contador2 == 0){
				cout << primo2 << "^" << exponente;
			    contador2++;
			}
			
			else{
				cout << " * " << primo2 << "^" << exponente;
			}
		}
		
		// Borramos el valor de exponente ya que se va a probar con un nuevo
		// factor primo y la base de la siguiente potencia a imprimir ser�
		// distinta. Sumamos 1 a primo para repetir todo el proceso anterior
		
		exponente = 0;
		primo2++;
	}
	
	return 0;
	
}
				
	

	

