/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/*
Este programa calcula el dinero que un usuario del p�rking debe de pagar en
funci�n de los minutos que ha permanecido su coche en dicho p�rking. Para 
ello se le piden los instantes de entrada y de salida, los cuales se dan
especificando las horas, minutos y segundos de cada instante. 

Para resolver el problema planteado he hecho uso de estructuras condicionales
simples con anidamientos mediante las cuales he establecido restricciones
en los datos de entrada. Dichas restricciones consisten en que si los segundos 
(de 0 a 59), los minutos (de 0 a 59) y las horas (de 0 a 23) no son dados
dentro de su rango (su rango es el que he especificado en los anteriores 
par�ntesis), el programa muestre en pantalla que los datos introducidos no
son v�lidos.

Despu�s de solucionar el problema de los rangos temporales, he usado otras 
estructuras condicionales que me han permitido considerar varios casos tras 
haber realizado los siguientes c�lculos:

         segundos_totales_1 = (segundos_1+minutos_1*60+horas_1*3600)
         segundos_totales_2 = (segundos_2+minutos_2*60+horas_2*3600)
         diferencia_en_segundos = segundos_totales_2-segundos_totales_1
         minutos_estancia = diferencia_en_segundos / 60
         
Dichas estructuras condicionales han sido 3:

1. Si los minutos de estancia son 0, eso significa que los instantes de entrada
y salida son el mismo, por lo que el usuario ha usado un d�a completo (que es
el tiempo m�ximo) el p�rking, por lo que deber� pagar 24�.

2. Si los minutos de estancia son positivos, eso significa que el usuario ha
entrado y salido del p�rking en el mismo d�a, por lo que se proceden a realizar
los c�lculos oportunos, que ser�n unos u otros dependiendo de cu�nto tiempo
haya estado el usuario en el p�rking (para ello he usado muchas estructuras
condicionales simples).

3. El �ltimo caso es que los minutos de estancia sean negativos, lo que quiere 
decir que entr� un d�a y sali� al siguiente. Por ello, para que los minutos de
estancia sean positivos habr� que realizar nuevos c�lculos:

                SEGUNDOS_DIA = 86400;
				diferencia_en_segundos = (SEGUNDOS_DIA - segundos_totales_1) +
				segundos_totales_2;
				minutos_estancia = diferencia_en_segundos / 60;
				
Finalmente se calcula el precio a pagar en funci�n de los minutos de estancia
reci�n calculados. Dicho precio depender� como en el anterior caso de cu�nto
tiempo se haya estado en el p�rking (para ello he utilizado otra serie de 
estructuras condicionales simples que abordan todos los casos posibles).
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recursos de E/S

using namespace std;

int main() // Programa principal
{
	// Declaraci�n de datos
	
	int segundos_1;
	int minutos_1;
	int horas_1;
	int segundos_2;
	int minutos_2;
	int horas_2;
	int segundos_totales_1;
	int segundos_totales_2;
	int diferencia_en_segundos;
	int minutos_estancia;
	const double TARIFA_0_A_30 = 0.0412;
	const double TARIFA_31_A_90 = 0.0370;
	const double TARIFA_91_A_120 = 0.0311;
	const double TARIFA_121_A_660 = 0.0305;
	double precio;
	
	// Entrada de datos
	
	cout << "Introduzca los segundos del momento de entrada: ";
	cin >> segundos_1;
	cout << "Introduzca los minutos del momento de entrada: ";
	cin >> minutos_1;
	cout << "Introduzca las horas del momento de entrada: ";
	cin >> horas_1;
	cout << "Introduzca los segundos del momento de salida: ";
	cin >> segundos_2;
	cout << "Introduzca los minutos del momento de salida: ";
	cin >> minutos_2;
	cout << "Introduzca las horas del momento de salida: ";
	cin >> horas_2;
	
	// Estructuras condicionales + C�lculos + Salida de datos
	
	// Comprobaci�n rangos temporales
	
	if ((segundos_1 < 0) || (minutos_1 < 0) || (horas_1 < 0) || (segundos_2 < 0)
	|| (minutos_2 < 0) || (horas_2 < 0)){
		
		cout << "Los datos introducidos son incorrectos por ser negativos, "
		<< "vuelva a iniciar el programa";
	}
	
	if ((segundos_1 >= 0) && (minutos_1 >= 0) && (horas_1 >= 0) && 
	(segundos_2 >= 0) && (minutos_2 >= 0) && (horas_2 >= 0)){
		
		if ((segundos_1 >= 60) || (minutos_1 >= 60) || (horas_1 > 23)
		|| (segundos_2 >= 60) || (minutos_2 >= 60) || (horas_2 > 23)){
			
			cout << "Los datos introducidos son incorrectos ya que no est�n "
			<< "dentro de su rango";
		}
		
		if ((segundos_1 <= 59) && (minutos_1 <= 59) && (horas_1 <= 23)
		&& (segundos_2 <= 59) && (minutos_1 <= 59) && (horas_2 <= 23)){
			
			// C�lculos
			
			segundos_totales_1 = segundos_1 + 60*minutos_1 + 3600*horas_1;
			segundos_totales_2 = segundos_2 + 60*minutos_2 + 3600*horas_2;
			diferencia_en_segundos = segundos_totales_2 - segundos_totales_1;
			minutos_estancia = diferencia_en_segundos / 60;
			
			// 1er caso: Ha permanecido un d�a entero
			
			if (minutos_estancia == 0){
				
				/* Esta situaci�n se produce cuando el usuario entra en un 
				instante concreto y sale en el mismo instante al siguiente 
				d�a, es decir, que ha permanecido el m�ximo tiempo posible,
				el cual es de 24 horas */
				
				cout << "La cantidad a pagar es 24 euros";
			}
			
			// 2o caso: Entra y sale el mismo d�a
			
			if (minutos_estancia > 0){
				
				if (minutos_estancia <= 30){
					precio = minutos_estancia*TARIFA_0_A_30;
					cout << "La cantidad a pagar es " << precio << " euros";
				}
				
				if ((minutos_estancia >= 31) && (minutos_estancia <= 90)){
					precio = 30*TARIFA_0_A_30 + (minutos_estancia - 30) *
					TARIFA_31_A_90;
					cout << "La cantidad a pagar es " << precio << " euros";
				}
				
				if ((minutos_estancia >= 91) && (minutos_estancia <= 120)){
					precio = 30*TARIFA_0_A_30 + 60*TARIFA_31_A_90 +
					(minutos_estancia - 90)*TARIFA_91_A_120;
					cout << "La cantidad a pagar es " << precio << " euros";
				}
				
				if ((minutos_estancia >= 121) && (minutos_estancia <= 660)){
					precio = 30*TARIFA_0_A_30 + 60*TARIFA_31_A_90 + 
					30*TARIFA_91_A_120 + (minutos_estancia - 120) *
					TARIFA_121_A_660;
					cout << "La cantidad a pagar es " << precio << " euros";
				}
				
				if ((minutos_estancia >= 661) && (minutos_estancia <= 1440)){
					cout << "La cantidad a pagar es 24 euros";
				}
				
			}
			
			// 3er caso: Entra un d�a y sale al siguiente
			
			if (minutos_estancia < 0){
				
				// Nuevos c�lculos
				
				const int SEGUNDOS_DIA = 86400;
				diferencia_en_segundos = (SEGUNDOS_DIA - segundos_totales_1) +
				segundos_totales_2;
				minutos_estancia = diferencia_en_segundos / 60;
				
				if (minutos_estancia <= 30){
					precio = minutos_estancia*TARIFA_0_A_30;
					cout << "La cantidad a pagar es " << precio << " euros";
				}
				
				if ((minutos_estancia >= 31) && (minutos_estancia <= 90)){
					precio = 30*TARIFA_0_A_30 + (minutos_estancia - 30) *
					TARIFA_31_A_90;
					cout << "La cantidad a pagar es " << precio << " euros";
				}
				
				if ((minutos_estancia >= 91) && (minutos_estancia <= 120)){
					precio = 30*TARIFA_0_A_30 + 60*TARIFA_31_A_90 +
					(minutos_estancia - 90)*TARIFA_91_A_120;
					cout << "La cantidad a pagar es " << precio << " euros";
				}
				
				if ((minutos_estancia >= 121) && (minutos_estancia <= 660)){
					precio = 30*TARIFA_0_A_30 + 60*TARIFA_31_A_90 + 
					30*TARIFA_91_A_120 + (minutos_estancia - 120) *
					TARIFA_121_A_660;
					cout << "La cantidad a pagar es " << precio << " euros";
				}
				
				if ((minutos_estancia >= 661) && (minutos_estancia <= 1440)){
					cout << "La cantidad a pagar es 24 euros";
				}
				
			}
			
		}
		
	}
	
	return 0;
	
}	
