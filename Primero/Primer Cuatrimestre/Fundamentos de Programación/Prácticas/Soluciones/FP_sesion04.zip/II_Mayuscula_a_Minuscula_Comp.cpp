/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa transforma una letra introducida en may�scula a min�scula. Para 
ello, primero he declarado un dato de tipo char que ser�a la letra en may�scula 
que introduce el usuario. El segundo dato que he declarado ha sido una constante 
entera que es la distancia a la que se encuentra una letra may�scula de su
min�scula (esto lo he hecho fij�ndome en la tabla ASCII de la p�gina 82 de los
apuntes de la asignatura). Dicha distancia la he definido con 'a'-'A' ya que
es la misma para todas las letras (A se corresponde con 65 y a con 97, por lo
que la diferencia es 32; B se corresponde con 66 y b con 98, siendo su 
diferencia tambi�n 32. Es por ello que he sabido que 'a' - 'A' es una diferencia
v�lida para todas las letras may�sculas con respecto de sus min�sculas). 

En esta actualizaci�n del programa que entregu� en la sesi�n de pr�cticas 3 
he tenido que utilizar una estructura condicional doble que hace que se lea 
en pantalla un error en el caso de que el usuario no haya introducido una letra
may�scula y que permite que se realicen los c�lculos en caso de que la letra 
introducida sea may�scula.

El c�lculo consiste en la suma de la diferencia entre una may�scula y su 
min�scula que hab�amos definido como 'a'-'A' y el car�cter introducido por el
usuario (ya que se puede operar con datos de tipo char), de manera que el 
programa finaliza imprimiendo en pantalla la letra min�scula que se esperaba.
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recurss de E/S

using namespace std;

int main() // Programa principal
{
	// Declaraci�n de datos
	
	char letra;
	const int DIFERENCIA_MAYUS_MINUS = 'a'-'A';
	
	// Entrada de datos
	
	cout << "Introduzca una letra may�scula: ";
	cin >> letra;
	
	// Estructuras condicionales + C�lculos + Salida de datos
	
	if ((letra >= 'A') && (letra <= 'Z')){
		cout << endl;
		letra = letra + DIFERENCIA_MAYUS_MINUS;
		cout << "La letra introducida en min�scula es: " << letra;
	}
	
	else{
		cout << endl;
		cout << "La letra que ha introducido no es may�scula, vuelva a "
		<< "iniciar el programa";
	}
	
	return 0;
	
}
