/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa calcula el valor que toma la funci�n gaussiana en el valor de 
abscisa que el usuario indique. Del usuario se espera que introduzca los 
coeficientes desviaci�n t�pica, esperanza y el valor de abscisa para el que 
quiere calcular el valor que toma la funci�n gaussiana.

Entradas: (esperanza)(desviacion_tipica)(abscisa)
Salidas: (valor_gaussiana)

La actualizaci�n que he realizado de este programa con respecto al que entregu�
en la sesi�n de pr�cticas 2 consiste en cubrir el caso de que al usuario se le
ocurra introducir una desviaci�n t�pica igual a 0 o negativa, ya que dicho
dato debe ser siempre un real positivo. Para asegurarme de que el usuario cumple
las normas, he usado una estructura condicional doble que muestra en pantalla
el mensaje "No se admite la desviaci�n t�pica introducida, vuelva a iniciar el 
programa" cuando la desviaci�n t�pica introducida no sea un real positivo. Si
los datos introducidos son correctos, dicha estructura permite que se realicen
los c�lculos para saber el valor de la funci�n gaussiana.
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recursos de E/S
#include <cmath> // Inclusi�n de los recursos matem�ticos

using namespace std;

int main() // Programa principal
{
	// Declaraci�n de datos
	
	double esperanza;
	double desviacion_tipica;
	double abscisa;
	const double PI = 3.14159;
	double exponente_de_e;
	double valor_gaussiana;
	
	// Entrada de datos
	
	cout << "Introduzca la esperanza: ";
	cin >> esperanza;
	cout << "Introduzca la desviaci�n t�pica: ";
	cin >> desviacion_tipica;
	
	
	// Estructuras condicionales + C�lculos + Salida de datos
	
	if (desviacion_tipica > 0){
		
		cout << "Introduzca el valor de la abscisa: ";
	    cin >> abscisa;
	    
		exponente_de_e = -0.5*pow(((abscisa-esperanza)/desviacion_tipica),2);
		valor_gaussiana = 1/(desviacion_tipica*sqrt(2*PI))*exp(exponente_de_e);
		
		cout << endl;
		cout << "El valor de la gaussiana para ese valor de abscisa es "
		<< valor_gaussiana;
	}
	
	else{
		cout << endl;
		cout << "No se admite la desviaci�n t�pica introducida, vuelva a "
		<< "iniciar el programa";
	}
	
	return 0;
	
}
