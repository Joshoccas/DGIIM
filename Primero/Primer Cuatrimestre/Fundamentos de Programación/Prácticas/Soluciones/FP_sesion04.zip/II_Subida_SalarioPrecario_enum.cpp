/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/*
Este programa permite al usuario conocer qu� subidas se le aplicar�n a su 
salario y el valor de su salario una vez aplicadas dichas subidas en funci�n
de su edad y su salario. Es decir, si es menor de 35 a�os o mayor de 65 a�os,
se le aplica una subida del 4%, mientras que si es mayor de 35 y menor de 65,
no se le aplican subidas por edad. Tras evaluar la edad, si el salario 
introducido era menor a 300�, se le aplica otra subida del 3% sobre el salario
ya afectado por las subidas de edad. Si est� entre 300� y 900�, la subida
ser� de 1.5%, y si es mayor de 900�, no se le aplicar� ninguna subida.

Al combinar todos los casos resultan 6 combinaciones distintas:

1. Que sea menor de 35 o mayor de 65 y su salario sea menor de 300�
2. Que sea menor de 35 o mayor de 65 y su salario est� entre 300� y 900�
3. Que sea menor de 35 o mayor de 65 y su salario sea superior a 900�
4. Que sea mayor de 35 y menor de 65 y su salario sea menor de 300�
5. Que sea mayor de 35 y menor de 65 y su salario est� entre 300� y 900�
6. Que sea mayor de 35 y menor de 65 y su salario sea superior a 900�

Primero que todo, en mis estructuras condicionales he introducido una 
restricci�n para que se muestre en pantalla un mensaje de error en caso de
que se introduzcan edades o salarios negativos. Tras esto, he hecho uso de
los datos de tipo enumerado que hab�a declarado, a los que les he asignado
su tipo correspondiente mediante unas estructuras condicionales cuyas 
condiciones eran la edad y el salario. Tras esto, he usado los datos de tipo
enumerado ya asignados en una estructura condicional m�ltiple (switch) en la
que he tenido en cuenta los 6 casos anteriormente mencionados y les he
aplicado a los salarios las subidas pertinentes en funci�n de cada caso.
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recursos de E/S

using namespace std;

int main() // Programa principal
{
	// Declaraci�n de datos
	
	int edad;
	double salario;
	double SUBIDA_EDAD = 1.04;
	double SUBIDA_SALARIO_BAJO = 1.03;
	double SUBIDA_SALARIO_INTERMEDIO = 1.015;
	
	// Uso del tipo enumerado
	
	enum class TipoEdad {bonificado, no_bonificado};
	enum class TipoSalario {bajo, intermedio, elevado};
	
	// Declaraci�n de datos de tipo enumerado
	
	TipoSalario es_salario;
	TipoEdad es_edad;
	
	// Entrada de datos
	
	cout << "Introduzca su edad: ";
	cin >> edad;
	cout << "Introduzca su salario en euros: ";
	cin >> salario;
	
	// Comprobaci�n rango de los datos
	
	if ((salario <= 0) || (edad <= 0)){
		
		cout << endl;
		cout << "Los datos introducidos no son correctos, vuelva a iniciar "
		<< "el programa";
	}
	
	else{
		
		// Determinaci�n del tipo de edad en funci�n del dato edad
		
		if ((edad < 35) || (edad > 65)){	
			es_edad = TipoEdad::bonificado;
		}
		
		if ((edad >= 35) && (edad <= 65)){
			es_edad = TipoEdad::no_bonificado;
		}
		
		// Determinaci�n del tipo de salario en funci�n del dato salario
		
		if (salario < 300){
			es_salario = TipoSalario::bajo;
		}
		
		if (salario > 900){
			es_salario = TipoSalario::elevado;
		}
		
		if ((salario >= 300) && (salario <= 900)){
			es_salario = TipoSalario::intermedio;
		}
		
		// Consideraci�n de todos los casos posibles
		// Estructura condicional m�ltiple + C�lculos + Salida de datos
		
		switch (es_edad){
			
			case (TipoEdad::bonificado) :
				
				switch (es_salario){
					
					case (TipoSalario::bajo) :
						
						salario = (salario*SUBIDA_EDAD) * SUBIDA_SALARIO_BAJO;
						cout << endl;
						cout << "Su salario es de " << salario << " euros";
						cout << endl;
						cout << "Se le han aplicado dos subidas: un 4% por "
						<< "su edad y un 3% por su salario bajo";
						break;
						
					case (TipoSalario::intermedio) :
						
						salario = (salario*SUBIDA_EDAD) * 
						SUBIDA_SALARIO_INTERMEDIO;
						cout << endl;
						cout << "Su salario es de " << salario << " euros";
						cout << endl;
						cout << "Se le han aplicado dos subidas: un 4% por "
						<< "su edad y un 1.5% por su salario intermedio";
						break;
						
					case (TipoSalario::elevado) :
						
						salario = salario*SUBIDA_EDAD;
						cout << endl;
						cout << "Su salario es de " << salario << " euros";
						cout << endl;
						cout << "Se le ha aplicado la subida del 4% por "
						<< "su edad";
						break;
				}
					
		    	break;
					
			case (TipoEdad::no_bonificado) :
				
				switch (es_salario){
					
					case (TipoSalario::bajo) :
						
						salario = salario*SUBIDA_SALARIO_BAJO;
						cout << endl;
						cout << "Su salario es de " << salario << " euros";
						cout << endl;
						cout << "Se le ha aplicado la subida del 3% por su "
						<< "salario bajo";
						break;
						
					case (TipoSalario::intermedio) :
						
						salario = salario*SUBIDA_SALARIO_INTERMEDIO;
						cout << endl;
						cout << "Su salario es de " << salario << " euros";
						cout << endl;
						cout << "Se le ha aplicado la subida del 1.5% por su "
						<< "salario intermedio";
						break;
						
					case (TipoSalario::elevado) :
						
						cout << endl;
						cout << "Su salario es de " << salario << " euros";
						cout << endl;
						cout << "No se le ha aplicado ninguna subida";
						break;
					
				}
				
				break;
				
			}
			
		}
		
		return 0;
		
	}
	
				
	
	
