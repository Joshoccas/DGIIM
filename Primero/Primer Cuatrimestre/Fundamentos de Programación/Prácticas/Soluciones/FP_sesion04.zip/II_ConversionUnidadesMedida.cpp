/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/*
Este programa permite al usuario convertir una distancia dada en una unidad de
medida determinada en otra unidad de medida. Por ejemplo, si se introducen 
8 km y se quieren pasar a metros, al final se mostrar� el mensaje 8 km = 8000 m.

Para resolverlo he hecho uso de datos string, un dato de tipo char y uno de
tipo double para que el usuario pueda introducir en una frase la conversi�n
que desea realizar. Por ejemplo: "8 km a m". He hecho uso de estructuras 
condicionales para asegurarme de que el usuario no introduce una distancia
negativa, introduce la preposici�n "a" en el mensaje (ese ser�a el dato de tipo
char) y las unidades que introduce son mm, cm, m o km. En caso de que no siga
alguna de estas reglas, se mostrar� un mensaje de error en pantalla.

Finalmente, mediante estructuras condicionales dobles he considerado todas 
las conversiones posibles y he asignado a mis datos exponente1 y exponente2 
los valores pertinentes. Dichos exponentes son usados al final para el
c�lculo central del programa:

                  valor_final = valor * pow(10, exponente1 - exponente2)
                  
Este c�lculo es f�cil de razonar. Cuando convertimos unas unidades a otras,
siempre lo hacemos multiplicando o dividiendo por potencias de 10. He fijado
mi valor 0 en los metros como referencia. As�, al hacer la diferencia entre
los exponentes sabemos por qu� potencia de 10 debemos multiplicar el valor
inicial. Si el exponente total es negativo, eso es que la unidad a la que
se quiere convertir es m�s peque�a que la inicial, mientras que si sale 
positivo, eso significa que la unidad final es mayor que la unidad inicial.
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recursos de E/S
#include <string>
#include <cmath> // Inclusi�n de los recursos matem�ticos

using namespace std;

int main() // Programa principal
{
	// Declaraci�n de datos
	
	string unidad_inicial;
	string unidad_final;
	char preposicion;
	double valor;
	int exponente1;
	int exponente2;
	double valor_final;
	
	// Entrada de datos
	
	cout << "Introduzca la conversi�n que desea realizar en una l�nea. "
	<< "Por ejemplo, 9mm a km";
	cout << endl;
	cout << "> ";
	cin >> valor >> unidad_inicial >> preposicion >> unidad_final;
	
	// Estructuras condicionales 
	
	// Comprobaci�n de la validez de los datos
	
	if ((valor > 0) && (preposicion == 'a') && ((unidad_inicial == "mm") 
	|| (unidad_inicial == "cm") || (unidad_inicial == "m") ||
	(unidad_inicial == "km")) && ((unidad_final == "mm") ||
	(unidad_final == "cm") || (unidad_final == "m") || (unidad_final == "km"))){
		
		// Determinaci�n del exponente seg�n la unidad inicial introducida
		
		if (unidad_inicial == "mm"){
			
			exponente1 = -3; // Se deduce de la conversi�n de metros a mm
			
		}
		
		else{
			
			if (unidad_inicial == "cm"){
				
				exponente1 = -2; // Se deduce de la conversi�n de metros a cm
				
			}
			
			else{
				
				if (unidad_inicial == "m"){
					
					exponente1 = 0; 
					
				}
				
				else{
					
					if (unidad_inicial == "km"){
						
						exponente1 = 3; // Se deduce de la convertir metros a km
						
					}
					
				}
				
			}
			
		}
		
		// Determinaci�n del exponente seg�n la unidad final introducida
		
		if (unidad_final == "mm"){
			
			exponente2 = -3; // Se deduce de la conversi�n de metros a mm
			
		}
		
		else{
			
			if (unidad_final == "cm"){
				
				exponente2 = -2; // Se deduce de la conversi�n de metros a cm
				
			}
			
			else{
				
				if (unidad_final == "m"){
					
					exponente2 = 0; 
					
				}
				
				else{
					
					if (unidad_final == "km"){
						
						exponente2 = 3; // Se deduce de la convertir metros a km
						
					}
					
				}
				
			}
			
		}
		
		// C�lculos + Salida de datos
		
		valor_final = valor * pow(10, exponente1 - exponente2);
		cout << endl;
		cout << valor << " " << unidad_inicial << " = " << valor_final << " "
		<< unidad_final;
		
	}
	
	else{
		
		cout << "Los datos introducidos no son v�lidos, vuelva a iniciar "
		<< "el programa";
	}
	
	return 0;
	
}
