/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/*
Este programa calcula la diferencia de tiempo en segundos que hay entre dos 
instantes de tiempo expresados en horas, minutos y segundos, y que el usuario
debe introducir manualmente. Los c�lculos que se realizan para obtener la
diferencia en segundos no requieren explicaci�n ya que son b�sicos.

Tambi�n calcula la diferencia dada en horas, minutos y segundos, y los c�lculos
realizados para ello son los que cre� en el ejercicio I_AjusteTiempo de la 
sesi�n de pr�cticas 2, pero los he tenido que remodelar, ya que en este caso
tengo que transformar la diferencia en segundos en una diferencia dada en 
horas, minutos y segundos. Para lograrlo he jugado con la divisi�n, 
declaraci�n de datos de tipo int y m�dulo: he dividido la diferencia de 
segundos totales por 60 y el resto de dicha divisi�n se lo he asignado a los
segundos_salida que se mostrar�n en pantalla. Para los minutos me he quedado
con la parte entera de la divisi�n anterior y esa parte entera la he dividido 
por 60, qued�ndome con el resto, que ser�an los minutos_salida que se muestran
en pantalla. Finalmente, para las horas he tomado la parte entera de la anterior
divisi�n y he calculado el resto al dividirla por 24, para as� obtener las
horas_salida que aparecen en pantalla.

He hecho uso de estructuras condicionales simples con anidamiento para poder
mostrar en pantalla un mensaje de error en caso de que los segundos, los 
minutos o las horas introducidas no est�n dentro de su rango. Tambi�n he
necesitado las estructuras condicionales para que una vez comprobados los
rangos de los datos introducidos, se eval�en tres posibilidades distintas:

1. La diferencia en segundos es 0, por lo que los dos instantes introducidos
son iguales.

2. La diferencia en segundos es positiva, por lo que se efect�an sin problema
los c�lculos explicados previamente.

3. La diferencia en segundos es negativa, por lo que los dos instantes 
introducidos pertenecen a d�as distintos y se efect�a un  c�lculo nuevo
para obtener la diferencia en segundos real de esos dos instantes.
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recursos de E/S

using namespace std;

int main() // Programa principal
{
	// Declaraci�n de datos
	
	int segundos_1;
	int minutos_1;
	int horas_1;
	int segundos_2;
	int minutos_2;
	int horas_2;
	int segundos_totales_1;
	int segundos_totales_2;
	int diferencia_en_segundos;
	
	// Entrada de datos
	
	cout << "Introduzca los segundos del instante 1: ";
	cin >> segundos_1;
	cout << "Introduzca los minutos del instante 1: ";
	cin >> minutos_1;
	cout << "Introduzca las horas del instante 1: ";
	cin >> horas_1;
	cout << "Introduzca los segundos del instante 2: ";
	cin >> segundos_2;
	cout << "Introduzca los minutos del instante 2: ";
	cin >> minutos_2;
	cout << "Introduzca las horas del instante 2: ";
	cin >> horas_2;
	
	// Estructuras condicionales + C�lculos + Salida de datos
	
	// Comprobaci�n de los rangos temporales
	
	if ((segundos_1 < 0) || (minutos_1 < 0) || (horas_1 < 0) || (segundos_2 < 0)
	|| (minutos_2 < 0) || (horas_2 < 0)){
		
		cout << endl;
		cout << "Los datos introducidos son incorrectos por ser negativos, "
		<< "vuelva a iniciar el programa";
	}
	
	if ((segundos_1 >= 0) && (minutos_1 >= 0) && (horas_1 >= 0) && 
	(segundos_2 >= 0) && (minutos_2 >= 0) && (horas_2 >= 0)){
		
		if ((segundos_1 >= 60) || (minutos_1 >= 60) || (horas_1 > 23)
		|| (segundos_2 >= 60) || (minutos_2 >= 60) || (horas_2 > 23)){
			
			cout << endl;
			cout << "Los datos introducidos son incorrectos ya que no est�n "
			<< "dentro de su rango";
		}
		
		if ((segundos_1 <= 59) && (minutos_1 <= 59) && (horas_1 <= 23)
		&& (segundos_2 <= 59) && (minutos_1 <= 59) && (horas_2 <= 23)){
			
			// C�lculos
			
			segundos_totales_1 = (segundos_1+minutos_1*60+horas_1*3600);
	        segundos_totales_2 = (segundos_2+minutos_2*60+horas_2*3600);
	        diferencia_en_segundos = (segundos_totales_2-segundos_totales_1);
	        
	        // 1er caso: Los dos instantes introducidos pertenecen al mismo d�a
	        
	        if (diferencia_en_segundos > 0){
	        	
	        	int segundos_salida = diferencia_en_segundos%60;
	            int minutos_salida = (diferencia_en_segundos/60)%60;
	            int horas_salida = ((diferencia_en_segundos/60)/60)%24;
	        	
	        	cout << endl;
	        	cout << "La diferencia en segundos entre esos dos instantes "
	        	<< "es de " << diferencia_en_segundos << " segundos";
	        	
	        	cout << endl;
	        	cout << "La diferencia entre los dos instantes de tiempo "
	        	<< "introducidos es de " << horas_salida << "h " 
	        	<< minutos_salida << "min " << segundos_salida << "s";
	        }
	        
	        // 2o caso: Los instantes introducidos son iguales
	        
	        if (diferencia_en_segundos == 0){
	        	
	        	cout << endl;
	        	cout << "La diferencia en segundos entre esos dos instantes "
	        	<< " es de 0 segundos ya que son el mismo instante, a no ser "
	        	<< "que sean de d�as distintos, por lo que la diferencia ser�a "
	        	<< "de 24 horas";
	        }
	        
	        // 3er caso: Los instantes introducidos pertenecen a d�as distintos
	        
	        if (diferencia_en_segundos < 0){
	        	
	        	// Nuevo c�lculo de la diferencia en segundos
	        	
	        	const int SEGUNDOS_DIA = 86400;
	        	diferencia_en_segundos = (SEGUNDOS_DIA - segundos_totales_1) +
	        	segundos_totales_2;
	        	
	        	int segundos_salida = diferencia_en_segundos%60;
	            int minutos_salida = (diferencia_en_segundos/60)%60;
	            int horas_salida = ((diferencia_en_segundos/60)/60)%24;
	        	
	        	cout << endl;
	        	cout << "La diferencia en segundos entre esos dos instantes "
	        	<< "es de " << diferencia_en_segundos << " segundos";
	        	
	        	cout << endl;
	        	cout << "La diferencia entre los dos instantes de tiempo "
	        	<< "introducidos es de " << horas_salida << "h " 
	        	<< minutos_salida << "min " << segundos_salida << "s";
	        	
	        	cout << endl;
	        	cout << "Los dos instantes de tiempo introducidos pertenecen "
	        	<< "a d�as distintos";
	        }
	        
	    }
	    
	}
	
	return 0;
	
}
