/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/*
Este programa nos permite saber el n�mero de bits necesario para poder expresar
en binario un n�mero entero introducido por el usuario. Para poder solucionarlo
primero he hecho varias divisiones de n�meros enteros entre 2 repetidamente 
hasta no poder dividir por 2. Tras varios c�lculos, me he percatado de que si el
entero era mayor que 1 y menor que 4, necesitaba 2 bits, si era mayor que 4 y 
menor que 8 necesitaba 3 bits, si era mayor que 8 y menor que 16 necesitaba 4 
bits, y as� sucesivamente. Por decirlo as�, los l�mites vienen dados por 
potencias de 2. Por esto, he empleado logaritmos en base 2 para este ejercicio 
(por ejemplo, si log2(33) es 5.0444, necesito 6 bits. Si log2(25) es 4.64386, 
necesito 5 bits, es decir, a la parte entera del resultado del logaritmo le 
tendr� que sumar 1 siempre para obtener los bits necesarios). 

El 0 presenta un problema, y es que cualquier logaritmo cuyo argumento es 0 no 
est� definido. Sin embargo, para representar el 0 en binario necesitamos 1 bit. 
Para resolver este problema se me ha ocurrido sumar al entero que el usuario 
introduce 0.9. As�, si el usuario introduce un 0, tendremos log2(0.9) que es 
-0.152003, pero como luego le aplico un cast, me quedo con la parte entera que 
es 0, y al sumarle 1 obtengo 1 bit. Ese 0.9 no modifica para nada el resultado 
del programa para los enteros distintos de 0, ya que la parte entera del 
resultado del logaritmo, que es lo que nos importa, sigue siendo la misma.

En la actualizaci�n de este programa que entregu� en la sesi�n de pr�cticas 3
he hecho uso de una estructura condicional doble, de manera que si el usuario
introduce un entero negativo, los c�lculos no se realizar�n y se mostrar� en 
pantalla un mensaje de que se ha producido un error. En caso de que el entero 
introducido sea 0 o mayor, esta estructura permitir� que se realicen los
c�lculos que he explicado en los dos p�rrafos superiores y obtendremos el n� de
bits necesarios para representar en binario el entero introducido.
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recursos de E/S
#include <cmath> // Inclusi�n de los recursos matem�ticos

using namespace std;

int main() // Programa principal
{
	// Declaraci�n de datos
	
	int entero;
	int bits_necesarios;
	
	// Entrada de datos
	
	cout << "Introduzca el entero del cual desea saber cu�ntos bits son" 
	<< " necesarios para representarlo en binario: ";
	cin >> entero;
	
	// Estructura condicional + C�lculos + Salida de datos
	
	if (entero >= 0){
		cout << endl;
		bits_necesarios = static_cast<int>(log2(entero + 0.9)) + 1;
		cout << "Los bits necesarios para representar " << entero << " son "
		<< bits_necesarios << " bit(s)";
	}
	
	else{
		cout << endl;
		cout << "El entero que ha introducido no es positivo, vuelva a " 
		<< "iniciar el programa";
	}
	
	return 0;
	
}

