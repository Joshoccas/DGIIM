/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/*
Este programa informa al usuario sobre el precio de su billete de avi�n en 
funci�n de la distancia a la que se encuentre el destino del usuario y los
puntos acumulados en la tarjeta de fidelizaci�n. Si el destino se encuentra 
a menos de 300 kil�metros, el precio ser� el de la tarifa base (150�). Si est�
a m�s de 300 kil�metros, entonces entran en juego dos datos:

1. Si el destino est� a m�s de 700 km, se le aplica un descuento del 2% al 
precio final.

2. Si los puntos acumulados est�n entre 100 y 200, se aplica un descuento del
3%. Si los puntos son superiores a 200, se aplica un descuento del 4%.

Como los descuentos son acumulables, el descuento final puede ser de 0%, 2%, 3%,
4%, 5% o 6% teniendo en cuenta todas las combinaciones posibles, las cuales he
tenido en cuenta en este programa haciendo uso de varios condicionales simples.
Quiero que quede constancia de que no he utilizado los "else", los cuales ayudan
a no violar el principio de una �nica vez, porque en los objetivos de este 
ejercicio se especificaba solo el uso de estructuras condicionales simples, por
lo que no me ha quedado m�s remedio.

Tambi�n he de mencionar que dentro de mis estructuras condicionales he incluido
que el programa no se ejecute en caso de que la distancia introducida por el 
usuario sea negativa o que los puntos de la tarjeta de fidelizaci�n sean
negativos.
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recursos de E/S

using namespace std;

int main() // Programa principal
{
	// Declaraci�n de datos
	
	const int TARIFA_BASE = 150;
	double distancia;
	double puntos;
	double precio_final;
	
	// Entrada del dato "distancia"
	
	cout << "Introduzca la distancia a la que se encuentra su destino en km: ";
	cin >> distancia;
	
	// Estructura condicional + C�lculos + Salida de datos
	
	if (distancia <= 0){
		cout << endl;
		cout << "La distancia de su destino no es v�lida, vuelva a inciar el "
		<< "programa";
	}
	
	if ((distancia > 0) && (distancia <= 300)){
		precio_final = TARIFA_BASE;
		cout << endl;
		cout << "Su billete cuesta " << precio_final << " euros";
	}
	
	if (distancia > 300){
		precio_final = TARIFA_BASE + 0.10*(distancia - 300);
		
		// Entrada del dato "puntos"
		
		cout << "Introduzca el n� de puntos de su tarjeta de fidelizaci�n: ";
		cin >> puntos;
		
		if (puntos < 0){
			cout << endl;
			cout << "La cantidad de puntos de su tarjeta de fidelizaci�n no "
			<< "es v�lida, vuelva a iniciar el programa";
		}
		
		if (puntos >= 0){
			
			if ((distancia <= 700) && (puntos <= 100)){
				cout << endl;
				cout << "Su billete cuesta " << precio_final << " euros";
			}
			
			if ((distancia <= 700) && ((puntos > 100) && (puntos <= 200))){
				precio_final = precio_final * 0.97;
				cout << endl;
				cout << "Su billete cuesta " << precio_final << " euros";
			}
			
			if ((distancia <= 700) && (puntos > 200)){
				precio_final = precio_final * 0.96;
				cout << endl;
				cout << "Su billete cuesta " << precio_final << "euros";
			}
			
			if ((distancia > 700) && (puntos <= 100)){
				precio_final = precio_final * 0.98;
				cout << endl;
				cout << "Su billete cuesta " << precio_final << " euros";
			}
			
			if ((distancia > 700) && ((puntos > 100) && (puntos <= 200))){
				precio_final = precio_final * 0.95;
				cout << endl;
				cout << "Su billete cuesta " << precio_final << " euros";
			}
			
			if ((distancia > 700) && (puntos > 200)){
				precio_final = precio_final * 0.94;
				cout << endl;
				cout << "Su billete cuesta " << precio_final << " euros";
			}
		}
	}
	
	return 0;
	
}
