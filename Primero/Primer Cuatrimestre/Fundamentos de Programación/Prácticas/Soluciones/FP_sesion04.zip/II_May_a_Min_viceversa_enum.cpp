/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/*
Este programa permite convertir una letra a may�scula o min�scula dependiendo
de si la letra que se ha introducido es may�scula o min�scula. Si es may�scula,
la pasar� a min�scula, y si es min�scula, la pasar� a may�scula.

Antes de mencionar las estructuras condicionales quiero explicar la constante de
tipo entero que he declarado. Dicha constante es la distancia a la que se 
encuentra una letra may�scula de su min�scula (esto lo he hecho fij�ndome en la 
tabla ASCII de la p�gina 82 de los apuntes de la asignatura). Dicha distancia la 
he definido con 'a'-'A' ya que es la misma para todas las letras (A se 
corresponde con 65 y a con 97, por lo que la diferencia es 32; B se corresponde 
con 66 y b con 98, siendo su diferencia tambi�n 32. Es por ello que he sabido 
que 'a' - 'A' es una diferencia v�lida para todas las letras may�sculas con 
respecto de sus min�sculas).

Tras la explicaci�n del origen de dicha constante, tambi�n he de mencionar que
he usodo el tipo enumerado para clasificar los caracteres que se introduzcan en
may�sculas, min�sculas u otros (siendo esos otros la �, letras con tilde o 
di�resis y d�gitos). Al dato caracter de tipo TipoCaracter le he asignado su
clasificaci�n en funci�n de si el dato letra_original es may�scula, min�scula
u otro tipo de car�cter. Una vez hechas las clasificaciones, he creado otra
estructura condicional (en este caso m�ltiple) con la que he considerado los 
tres casos posibles:

1. La letra introducida es may�scula.
2. La letra introducida es min�scula.
3. El dato introducido es un d�gito, �, letras con tilde o con di�resis.

Para el primer caso a letra_original le he sumado la constante ya explicada. En
el segundo caso, a letra_original se le resta la constante ya que los n�meros
con los que se corresponden las min�sculas son mayores que los de las 
may�sculas, es decir, las min�sculas se encuentran a la derecha de las 
may�sculas en la tabla ASCII. En el �ltimo caso simplemente se muestra un
mensaje en pantalla de que el caracter introducido no es v�lido.
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recursos de E/S

using namespace std;

int main() // Programa principal
{
	// Declaraci�n de datos
	
	char letra_original;
	const int DIFERENCIA_MAYUS_MINUS = 'a'-'A';

	// Uso del tipo enumerado
	
	enum class TipoCaracter {mayuscula, minuscula, otro};
	
	// Declaraci�n de datos de tipo enumerado
	
	TipoCaracter caracter;
	
	// Entrada de datos
	
	cout << "Introduzca una letra may�scula o min�scula: ";
	cin >> letra_original;
	
	// Determinaci�n del tipo de car�cter en funci�n del dato letra_entrada
	
	if ((letra_original >= 'A') && (letra_original <= 'Z')){
		caracter = TipoCaracter::mayuscula;
	}
	
	else{
		
		if ((letra_original >= 'a') && (letra_original <= 'z')){
			caracter = TipoCaracter::minuscula;
		}
		
		else{
			caracter = TipoCaracter::otro;
		}
		
	}
	
	// Estructuras condicionales + C�lculos + Salida de datos
	
	switch (caracter){
		
		case (TipoCaracter::mayuscula) :
			
			letra_original = letra_original + DIFERENCIA_MAYUS_MINUS;
			cout << endl;
			cout << "La letra era una may�scula. Una vez convertida es "
			<< letra_original;
			break;
		
		case (TipoCaracter::minuscula) :
			
			letra_original = letra_original - DIFERENCIA_MAYUS_MINUS;
			cout << endl;
			cout << "La letra era una min�scula. Una vez convertida es "
			<< letra_original;
			break;
			
		case (TipoCaracter::otro) :
			
			letra_original = letra_original;
			cout << endl;
			cout << "El car�cter no era una letra";
			break;
			
	}
	
	return 0;
	
}
