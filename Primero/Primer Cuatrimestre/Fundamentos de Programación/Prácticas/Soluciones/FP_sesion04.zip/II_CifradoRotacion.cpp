/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa permite al usuario desplazar un n�mero de posiciones deseado
una letra ma�uscula introducida por este. Primero que todo me he asegurado de 
que el usuario lea en pantalla que hay un error en caso de que introduzca una
letra min�scula u otro tipo de car�cter y tambi�n en caso de que la clave de
desplazamiento sea mayor que el n�mero de las letras del abecedario, el cual es
26 (sin contar la �). Para resolver este problema he hecho uso de estructuras
condicionales simples, estando unas dentro de otras para asegurarme de que
se avise al usuario de un error si este desobedece las normas para los datos
de entrada. 

Tambi�n quiero explicar la operaci�n en caso de que la letra 
introducida se salga del intervalo de las letras may�sculas al aplicarle la 
clave: a dicha car�cter se le resta el valor de 'Z', que es la �ltima letra
may�scula, para as� obtener la posici�n de la letra desplazada dentro del 
intervalo de las letras may�sculas. Finalmente, a dicha posici�n se le suma
el valor de 'A' - 1 para obtener la letra desplazada (ese -1 se incluye para
que el car�cter 'A' cuente como una posici�n a considerar).
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recursos de E/S

using namespace std;

int main() // Programa principal
{
	// Declaraci�n de datos
	
	char letra_a_desplazar;
	int clave;
	char letra_desplazada;
	
	// Entrada de datos
	
	cout << "Introduzca la letra may�scula a desplazar: ";
	cin >> letra_a_desplazar;
	cout << "Introduzca el n� de posiciones que la desea desplazar: ";
	cin >> clave;
	
	// Estructuras condicionales + C�lculos + Salida de datos
	
	if ((clave < 0) || (clave > 26)){
		cout << endl;
		cout << "Dicha clave no es v�lida, vuelva a iniciar el programa";
	}
	
	if ((clave >= 1) && (clave <= 26)){
		
		if ((letra_a_desplazar < 'A') || (letra_a_desplazar > 'Z')){
			cout << endl;
			cout << "La letra introducida no es may�scula, vuelva a iniciar"
			<< " el programa";
		}
		
		if ((letra_a_desplazar >= 'A') && (letra_a_desplazar <= 'Z')){
			letra_desplazada = letra_a_desplazar + clave;
			
			if ((letra_desplazada >= 'A') && (letra_desplazada <= 'Z')){
				cout << endl;
				cout << "La letra desplazada es " << letra_desplazada;
			}
			
			if (letra_desplazada > 'Z'){
				letra_desplazada = (letra_desplazada - 'Z') + 'A' - 1;
				cout << "La letra desplazada es " << letra_desplazada;
			}
		}
	}
	
	return 0;
	
}

