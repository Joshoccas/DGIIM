/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa separa los d�gitos de un n�mero de 3 cifras que es introducido por
el usuario. Por ejemplo, si el n�mero introducido es 345, en pantalla se 
mostrar� "3   4   5". Para ello, he hecho uso de la soluci�n proporcionada
por el profesor del ejercicio 26 y he aprovechado un dato de tipo string.
A la actualizaci�n de este programa le he a�adido una estructura condicional
doble que permite separar los d�gitos cuando el n�mero introducido est� 
comprendido entre el 100 y el 999 (es decir, tiene 3 cifras) y que muestra en
pantalla un mensaje de error en caso de que el n�mero introducido no cumpla
la condici�n anteriormente mencionada.
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recursos de E/S
#include <string>

using namespace std;

int main() // Programa principal
{
	// Declaraci�n de datos
	
	string cad_3digitos;
	int numero_3dig; // N�mero inicial con centenas, decenas y unidades
	int numero_2dig; // N�mero que resulta de restarle las centenas al inicial
	int centenas; // Cifra de las centenas
	int decenas; // Cifra de las decenas
	int unidades; // Cifra de las unidades
	
	// Entrada de datos
	
	cout << "Introduzca un n�mero de tres d�gitos: ";
	cin >> cad_3digitos;
	
	// Transformaci�n de cad_3digitos en un int "numero_3dig"
	
	numero_3dig = stoi(cad_3digitos);
	
	// Estructuras condicionales + C�lculos + Salida de datos
	
	if ((numero_3dig >= 100) && (numero_3dig <= 999)){
		
		centenas = numero_3dig / 100; 
		numero_2dig = numero_3dig % 100;
		
		decenas = numero_2dig / 10;
		unidades = numero_2dig % 10;
		
		const string SEPARADOR = "   ";
		string cad_resultado = SEPARADOR + to_string(centenas) +
		                       SEPARADOR + to_string(decenas) +
		                       SEPARADOR + to_string(unidades);
		
		cout << endl;
		cout << cad_resultado << endl;
	}
	
	else{
		cout << endl;
		cout << "El n�mero que ha introducido no es de 3 d�gitos, vuelva a "
		<< "iniciar el programa";
	}
	
	return 0;
	
}
		                       
		
	
