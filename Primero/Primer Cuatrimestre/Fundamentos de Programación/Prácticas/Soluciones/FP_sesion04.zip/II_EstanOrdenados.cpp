/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/*
Este programa nos informa de si tres n�meros enteros que introduce el usuario
est�n ordenados (ya sea de menor a mayor o de mayor a menor) o no. Para ello
he hecho uso de una estructura condicional doble que contiene a otra (esto es lo
que se conoce como anidamiento) ya que quer�a que mi programa especificase
el tipo de orden de los enteros introducidos.
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recursos de E/S

using namespace std;

int main() // Programa principal
{
	// Declaraci�n de datos
	
	int entero1;
	int entero2;
	int entero3;
	
	// Entrada de datos
	
	cout << "Introduzca el primer n�mero entero: ";
	cin >> entero1;
	cout << "Introdizca el segundo n�mero entero: ";
	cin >> entero2;
	cout << "Introduzca el tercer n�mero entero: ";
	cin >> entero3;
	
	// Estructuras condicionales + Salida de datos
	
	if ((entero1 < entero2) && (entero2 < entero3)){
		cout << endl;
		cout << "Los enteros introducidos est�n ordenados de menor a mayor";
	}
	
	else{
		
		if ((entero1 > entero2) && (entero2 > entero3)){
			cout << endl;
			cout << "Los enteros introducidos est� ordenados de mayor a menor";
		}
		
		else{
			cout << endl;
			cout << "Los enteros introducidos no est�n ordenados";
		}
		
	}
	
	return 0;
}

