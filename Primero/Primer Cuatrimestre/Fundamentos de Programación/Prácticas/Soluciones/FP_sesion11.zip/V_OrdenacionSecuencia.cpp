/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa trabaja sobre objetos de la clase SecuenciaEnteros. Se inicializa
el vector dato miembro del objeto "secuencia" con enteros aleatorios entre
0 y 1000 y tras esto, se ejecutan 4 m�todos de ordenaci�n distintos con el fin
de ordenar la secuencia que contiene 10000 enteros aleatorios:

		1. Por selecci�n
		2. Por inserci�n
		3. Por intercambio 
		4. Por intercambio mejorado	
		
Como al ejecutar un m�todo de los mencionados la secuencia ya estaba ordenada,
me he visto obligado a borrar el contenido de la secuencia ordenada y poner
nuevos enteros aleatorios desordenados para que el siguiente m�todo a ejecutar
tambi�n tenga que ordenar. El funcionamiento de cada uno de los cuatro m�todos
est� explicado en la propia clase.
*/
/*****************************************************************************/

#include <iostream>
#include <string>
#include <random>  // Para la generaci�n de n�meros pseudoaleatorios
#include <chrono>  // Para la semilla

using namespace std;

///////////////////////////////////////////////////////////////////////////////

class SecuenciaEnteros {

private:

    static const int TAMANIO = 10000; // N�m.casillas disponibles
    int vector_privado[TAMANIO];

    // PRE: 0<=total_utilizados<=TAMANIO

    int total_utilizados; // N�m.casillas ocupadas

public:

    /***********************************************************************/
    // Constructor sin argumentos

    SecuenciaEnteros (void) : total_utilizados (0)
    {}

    /***********************************************************************/
    // Devuelve el n�mero de casillas ocupadas

    int TotalUtilizados (void)
    {
        return (total_utilizados);
    }

    /***********************************************************************/
    // Devuelve el n�mero de casillas disponibles

    int Capacidad (void)
    {
        return (TAMANIO);
    }

    /***********************************************************************/
    // "Vac�a" completamente la secuencia

	void EliminaTodos()
	{
		total_utilizados = 0;
	}
	
	/***********************************************************************/
	// M�todo que busca la posici�n del m�nimo entre dos posiciones del vector
	// PRE: 0 <= izda <= dcha < total_utilizados
	
	int PosicionMinimoEntre(int izda, int dcha)
	{
		int posicion_minimo = -1;
		int minimo;
		
		minimo = vector_privado[izda]; // Se comienza asignando el m�nimo
		posicion_minimo = izda;        // a la posici�n izda
		
		// A continuaci�n se recorren todas las posiciones desde izda a dcha
		// y m�nimo y posicion_minimo se van actualizando en caso de encontrar
		// en dicho recorrido una componente del vector menor que la �ltima
		// registrada en minimo
		
		for (int i = izda+1 ; i <= dcha ; i++){
			if (vector_privado[i] < minimo){
				minimo = vector_privado[i];
				posicion_minimo = i;
			}
		}
		
		return posicion_minimo;
	}


    /***********************************************************************/
    // A�ade un elemento ("nuevo") al vector.
    // PRE: total_utilizados < TAMANIO
    // 		La adici�n se realiza si hay alguna casilla disponible.
    // 		El nuevo elemento se coloca al final del vector.
    // 		Si no hay espacio, no se hace nada.

    void Aniade (int nuevo)
    {
        if (total_utilizados < TAMANIO){
            vector_privado[total_utilizados] = nuevo;
            total_utilizados++;
        }
    }

    /***********************************************************************/
    // Devuelve el elemento de la casilla "indice"
    // PRE: 0 <= indice < total_utilizados

    int Elemento (int indice)
    {
        return (vector_privado[indice]);
    }

    /***********************************************************************/
    // Cambia el contenido de la casilla "indice" por el valor "nuevo"
    // PRE: 0 <= indice < total_utilizados

   void Modifica (int indice, int nuevo)
   {
		if ((indice >= 0) && (indice < total_utilizados))
			vector_privado[indice] = nuevo;
   }


    /***********************************************************************/
    // Eliminar el car�cter de la posici�n dada por "indice".
    // Realiza un borrado f�sico (desplazamiento y sustituci�n).
    // PRE: 0 <= indice < total_utilizados

    void Elimina (int indice)
    {
        if ((indice >= 0) && (indice < total_utilizados)) {

            int tope = total_utilizados-1; // posic. del �ltimo

            for (int i = indice ; i < tope ; i++)
                vector_privado[i] = vector_privado[i+1];

            total_utilizados--;
        }
    }
 

    /***********************************************************************/
    // Inserta el car�cter "nuevo" en la posici�n dada por "indice".
    // Desplaza todos los caracteres una posici�n a la derecha antes de 
	// copiar en "indice" en valor "nuevo".
	// PRE: 0 <= indice < total_utilizados
    // PRE: total_utilizados < TAMANIO
    // 		La inseerci�n se realiza si hay alguna casilla disponible.
    // 		Si no hay espacio, no se hace nada.
    
	void Inserta (int indice, int valor_nuevo)
	{
        if ((indice >= 0) && (indice < total_utilizados) 
		    && (total_utilizados < TAMANIO)) {
		
			for (int i = total_utilizados ; i > indice ; i--)
				vector_privado[i] = vector_privado[i-1];
			
			vector_privado[indice] = valor_nuevo;
			total_utilizados++;		
		}
	}
   
    /***********************************************************************/
    // Compone un string con todos los caracteres que est�n
    // almacenados en la secuencia y lo devuelve.

    string ToString()
    {
        string cadena;

        for (int i=0; i<total_utilizados; i++)
            cadena = cadena + to_string(vector_privado[i]);

        return (cadena);
    }
    
    /***********************************************************************/
    // 1. ORDENACI�N POR SELECCI�N
    // Primer m�todo de ordenaci�n para la secuencia de enteros
    
    void OrdenaSeleccion()
    {
    	
		int pos_min;
		
		// Se comienza buscando el la posici�n del m�nimo de todo el vector
		// y se intercambia su contenido con el de la primera posici�n. 
		// Se avanza una posici�n y entonces se vuelve a buscar el m�nimo
		// pero de las casillas restantes, pues en la primera ya se tiene
		// el m�nimo de todo el vector. Una vez se encuentra el m�nimo de
		// las casillas restantes, se procede a hacer el intercambio y se
		// vuelve a buscar el m�nimo de las casillas restantes, y as� 
		// sucesivamente hasta llegar al final del vector
		
		for (int izda = 0 ; izda < total_utilizados ; izda++){
			
			pos_min = PosicionMinimoEntre (izda, total_utilizados-1);
			IntercambiaComponentes_en_Posiciones (izda, pos_min);
		}
	}
	
	// 2. ORDENACI�N POR INSERCI�N
	// Segundo m�todo de ordenaci�n para la secuencia de enteros
	
	// Este m�todo consiste en comenzar por la segunda casilla del vector e
	// ir comparando su contenido con el de todas las casillas anteriores. 
	// Entonces, se desplazan hacia la derecha todos los contenidos de las
	// casillas con valor menor que el que se est� evaluando. As�, se 
	// copia el valor de la casilla que se est� evaluando justo detr�s de 
	// todas las que se han desplazado a la derecha. 
	
	// Se vuelve a repetir el proceso con la tercera casilla y as� hasta
	// llegar al final del vector, quedando todas las componentes ordenadas.
	
	void OrdenaInsercion()
	{
		
		int izda, i;
		int a_desplazar;
		
		for (izda = 1; izda < total_utilizados; izda++){
			a_desplazar = vector_privado[izda];
			
			for (i = izda; i > 0 && a_desplazar < vector_privado[i-1]; i--)
				vector_privado[i] = vector_privado[i-1];
				
			vector_privado[i] = a_desplazar;
		}
	}
	
	// 3. ORDENACI�N POR INTERCAMBIO 
	// Tercer m�todo de ordenaci�n para la secuencia de enteros
	
	void OrdenaIntercambio()
	{
		
		// Se comienza comparando las casillas desde la �ltima posici�n
		// del vector. Si el contenido de una es menor que el de la 
		// anterior, se intercambian sus contenidos. Si no, no se hace
		// nada, y dicha comparaci�n se realiza entre cada par de casillas
		// consecutivas hasta llegar al inicio del vector. As�, se logra
		// tener el dato de menor valor en la primera casilla tras la 
		// primera iteraci�n. 
		
		// A continuaci�n se vuelve a repetir el proceso anterior pero
		// considerando el inicio del vector como la posici�n 1 y as�
		// sucesivamente hasta que se hallan ordenado todas las 
		// componentes

		int izda, i;
		
		for (izda = 0; izda < total_utilizados; izda++){
			
			for (i = total_utilizados-1 ; i > izda ; i--){
				
				if (vector_privado[i] < vector_privado[i-1]){
					
					IntercambiaComponentes_en_Posiciones(i, i-1);
				}
			}
		}
	}
	
	// 4. ORDENACI�N POR INTERCAMBIO MEJORADO
	// Cuarto m�todo de ordenaci�n para la secuencia de enteros
	
	// Este m�todo funciona de la misma forma que el anterior pero con la
	// diferencia de que en caso de que haya un momento en el que los 
	// valores de las casillas que est�n a la derecha de izda est�n ordenadas,
	// entonces finaliza el bucle ya que no es necesario seguir iterando
	
	void OrdenaIntercambioMejorado()
	{
		
		int izda, i;
		bool cambio;
		
		cambio = true;
		
		for (izda = 0; izda < total_utilizados && cambio; izda++){
			
			cambio = false;
			
			for (i = total_utilizados-1; i > izda; i--){
				
				if (vector_privado[i] < vector_privado[i-1]){
					
					IntercambiaComponentes_en_Posiciones(i, i-1);
					cambio = true;
				}
			}
		}
	}

	
private:
	
	// M�todo que intercambia el contenido de dos posiciones dadas de un
	// vector
	
	void IntercambiaComponentes_en_Posiciones(int pos_izda, int pos_dcha)
	{
		int intercambia;
		
		intercambia = vector_privado[pos_izda];
		vector_privado[pos_izda] = vector_privado[pos_dcha];
		vector_privado[pos_dcha] = intercambia;
	}
};

///////////////////////////////////////////////////////////////////////////////

class Cronometro
{
	
private:
	
   typedef std::chrono::time_point<std::chrono::steady_clock>
           Punto_en_el_Tiempo;
   typedef chrono::duration <double, nano> IntervaloTiempo;

   Punto_en_el_Tiempo inicio;
   Punto_en_el_Tiempo final;

public:
	
	/***********************************************************************/
	void Reset() { 
		inicio = chrono::steady_clock::now();
	}
	
	/************************************************************************/
	double NanoSegundosTranscurridos() {
		final = chrono::steady_clock::now();		
		IntervaloTiempo diferencia = final - inicio;
		return (diferencia.count());
	}
	
	/************************************************************************/
	double MiliSegundosTranscurridos() {
		final = chrono::steady_clock::now();		
		IntervaloTiempo diferencia = final - inicio;
		return (diferencia.count()/1e6);
	}
	/************************************************************************/  
};

///////////////////////////////////////////////////////////////////////////////

class GeneradorAleatorioEnteros
{  
private:
	
	mt19937 generador_mersenne;    // Mersenne twister
	uniform_int_distribution<int>  distribucion_uniforme;
	
	/************************************************************************/
	
	long long Nanosec(){
		return (chrono::high_resolution_clock::now().time_since_epoch().count());
	}
	
	/************************************************************************/ 
	
public:
	
	/************************************************************************/
		
	GeneradorAleatorioEnteros() : GeneradorAleatorioEnteros(0, 1) 
	{ }
	
	/************************************************************************/  
	GeneradorAleatorioEnteros(int min, int max) {
	
		const int A_DESCARTAR = 70000;
		// ACM TOMS Volume 32 Issue 1, March 2006
		
		auto semilla = Nanosec();
		generador_mersenne.seed(semilla);
		generador_mersenne.discard(A_DESCARTAR);
		distribucion_uniforme = uniform_int_distribution<int> (min, max);
	}
	
	/************************************************************************/
	
	int Siguiente(){
	  return (distribucion_uniforme(generador_mersenne));
	}
	
	/************************************************************************/

};

int main() // Programa principal
{
	// Creaci�n de objetos
	
	Cronometro cronometro;
	GeneradorAleatorioEnteros generador (0, 1000);
	SecuenciaEnteros secuencia;
	int LIMITE = 100;
	
	// Comentario: Como mostrar los 10000 enteros aleatorios ser�a demasiado,
	// solo mostrar� los 100 primeros ordenados para asegurar que los 4 
	// algoritmos funcionan adecuadamente.
	
	// Introducimos una secuencia de enteros aleatorios en la secuencia
	
	for(int i = 0; i < secuencia.Capacidad(); i++)
		secuencia.Aniade(generador.Siguiente());
		
	// Creamos tres secuencias adicionales y copiamos los valores desordenados 
	// de la primera en las otras tres
	
	SecuenciaEnteros secuencia1(secuencia);
	SecuenciaEnteros secuencia2(secuencia);
	SecuenciaEnteros secuencia3(secuencia);
	
	// 1er algoritmo: ORDENACI�N POR SELECCI�N
	
	cout << "1. ORDENACI�N POR SELECCI�N";
	cout << endl;
	
	cronometro.Reset();
	secuencia.OrdenaSeleccion();
	cout << "Milisegundos transcurridos: " << 
	cronometro.MiliSegundosTranscurridos();
	cout << endl;
	
	for(int i = 0; i < LIMITE; i++)
		cout << secuencia.Elemento(i) << " ";
	cout << endl << endl;

	// 2� algoritmo: ORDENACI�N POR INSERCI�N
	
	cout << "2. ORDENACI�N POR INSERCI�N";
	cout << endl;
	
	cronometro.Reset();
	secuencia1.OrdenaInsercion();
	cout << "Milisegundos transcurridos: " << 
	cronometro.MiliSegundosTranscurridos();
	cout << endl;
	
	for(int i = 0; i < LIMITE; i++)
		cout << secuencia1.Elemento(i) << " ";
	cout << endl << endl;
	
	// 3er algoritmo: ORDENACI�N POR INTERCAMBIO

	cout << "3. ORDENACI�N POR INTERCAMBIO";
	cout << endl;
	
	cronometro.Reset();
	secuencia2.OrdenaIntercambio();
	cout << "Milisegundos transcurridos: " << 
	cronometro.MiliSegundosTranscurridos();
	cout << endl;
	
	for(int i = 0; i < LIMITE; i++)
		cout << secuencia2.Elemento(i) << " ";
	cout << endl << endl;
	
	// 4� algoritmo: ORDENACI�N POR INTERCAMBIO MEJORADO
	
	cout << "4. ORDENACI�N POR INTERCAMBIO MEJORADO";
	cout << endl;
	
	cronometro.Reset();
	secuencia3.OrdenaIntercambioMejorado();
	cout << "Milisegundos transcurridos: " << 
	cronometro.MiliSegundosTranscurridos();
	cout << endl;
	
	for(int i = 0; i < LIMITE; i++)
		cout << secuencia3.Elemento(i) << " ";
	cout << endl << endl;
	
	return 0;
}
