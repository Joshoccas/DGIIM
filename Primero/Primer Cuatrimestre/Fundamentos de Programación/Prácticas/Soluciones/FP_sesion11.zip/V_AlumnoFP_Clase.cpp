/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa consiste en la creaci�n de la clase AlumnoFP para su posterior
utilizaci�n en el int main. Se proporciona el nombre y apellidos de un alumno,
su DNI y sus 4 notas respectivas de programaci�n. A partir de estos datos,
se calcula la nota final del alumno teniendo en cuenta el peso que tiene 
cada nota:

             1. Examen de teor�a: 60%
             2. Examen Pr�ctico 1: 10%
             3. Examen Pr�ctico 2: 20%
             4. Evaluaci�n continua: 10%
             
En la clase creada se incluyen dos m�todos, uno para a�adir notas y otro para
calcular la nota media final del alumno una vez introducidas todas las notas.
En caso de que el examen de teor�a est� por debajo del 4, la nota media final
ser� justo la de dicho examen. Si se saca un 4 o una nota mayor, la nota
media final se calcular� como una media aritm�tica.

Adem�s, el m�todo que calcula la nota media final informa sobre qu� partes
de la asignatura est�n suspensas.
*/
/*****************************************************************************/

#include <iostream>
#include <string>

using namespace std;

class AlumnoFP
{
	private:
		
		static const int NUM_NOTAS = 4;
		static const int PORCENTAJES[NUM_NOTAS];
		double NOTAS[NUM_NOTAS] = {0};
		
		const string NOMBRE_Y_APELLIDOS;
		const int DNI;
	
	public:
		
		// Creamos el constructor
		
		AlumnoFP (string nombre, string ap_1, string ap_2, int dni) :
			NOMBRE_Y_APELLIDOS (nombre + " " + ap_1 + " " + ap_2), DNI (dni)
		{}
		
		// Ahora se necesitan dos m�todos: uno que permita a�adir notas y
		// otro que calcule la nota media del alumno
		
		// PRE: 0 <= nota <= 10 
		
		void AniadeNota (double nota, int indice)
		{
			NOTAS[indice] = nota;
		}
		
		// PRE: El vector NOTAS debe tener todas sus componentes inicializadas
		
		double NotaMedia (void)
		{
			
			double nota_media = 0;
			int primera_nota = 0;
			
			if (NOTAS[primera_nota] < 4){
				
				nota_media = NOTAS[primera_nota];
			}
			
			else{
				
				for (int i = 0; i < NUM_NOTAS; i++)
					nota_media = nota_media + NOTAS[i]*(PORCENTAJES[i]/100.0);
			}
				
			return (nota_media);
		}
		
		// M�todo que muestra aquellas componentes que est�n suspensas
		
		string Suspensos (void)
		{
			string resultado = "Partes de la asignatura suspensas:\n\n";
			
			for(int i = 0; i < NUM_NOTAS; i++){
				
				if(NOTAS[i] < 5){
					
					char examen = '1' + i;
					
					resultado = resultado + "Examen " + examen + " suspenso"
					+ " con un " + to_string(NOTAS[i]) + "\n";
				}
			}
			
			return (resultado);
		}
		
		// M�todo Get para mostrar el nombre y apellidos del alumno
		
		string GetNombreApellidos (void)
		{
			return (NOMBRE_Y_APELLIDOS);
		}
		
		// M�todo Get para mostrar el DNI del alumno
		
		string GetDNI (void)
		{
			return (to_string(DNI));
		}
};

const int AlumnoFP::PORCENTAJES[] = {60, 10, 20, 10};

///////////////////////////////////////////////////////////////////////////////

class Lector
{
	private:
		
		string titulo;
	
	public:
		
		// Constructor sin argumentos
		
		Lector (void) : titulo ("")
		{ }
		
		// Constructor con argumentos
		
		Lector (string cad) : titulo (cad)
		{ }
		
		// M�todo Set para fijar el campo "titulo"
		
		void SetTitulo (string cad)
		{
			titulo = cad;
		}
		
		/*********************************************************************/
		// Lee un dato int.
		// La lectura est� etiquetada con "titulo"
		// La lectura se efect�a repetidamente hasta que se introduce un valor
		// int correcto.
		
		int LeeEntero (void)
		{
			string cadena;
			
			do{
				cout << titulo;
				getline(cin, cadena);
			}
			while (!EsEntero(cadena));
			
			return (stoi(cadena));
		}
		
		/*********************************************************************/
		// Lee un dato int.
		// La lectura est� etiquetada con "titulo"
		// PRE: menor <= mayor
		// POST: menor <= valor devuelto <= mayor
		
		int LeeEnteroEnRango (int menor, int mayor)
		{
			int numero;
			
			do{
				
				numero = LeeEntero ();
			}
			while ((numero<menor) || (numero>mayor));
			
			return (numero);
		}
		
		/*********************************************************************/
		// Lee un dato int que debe ser mayor o igual que "menor" y lo devuelve.
		// La lectura est� etiquetada con "titulo"
		
		int LeeEnteroMayorOIgual (int menor)
		{
			int numero;
			
			do{
				numero = LeeEntero ();
			}
			while (numero < menor);
			
			return (numero);
		}
		
		/*********************************************************************/
		// Lee un dato double.
		// La lectura est� etiquetada con "titulo"
		// La lectura se efect�a repetidamente hasta que se introduce un valor
		// double correcto.
		
		double LeeReal (void)
		{
			string cadena;
			
			do{
				cout << titulo;
				getline(cin, cadena);
			}
			while (!EsReal(cadena));
			
			return (stod(cadena));
		}
		
		/*********************************************************************/
		// Lee un dato double.
		// La lectura est� etiquetada con "titulo"
		// PRE: menor <= mayor
		// POST: menor <= valor devuelto <= mayor
		
		double LeeRealEnRango (int menor, int mayor)
		{
			double numero;
			
			do{
				
				numero = LeeReal ();
			}
			while ((numero<menor) || (numero>mayor));
			
			return (numero);
		}

		/*********************************************************************/
		// Lee un dato double que debe ser mayor o igual que "menor" y lo 
		// devuelve. 
		// La lectura est� etiquetada con "titulo"
		
		double LeeRealMayorOIgual (int menor)
		{
			double numero;
			
			do{
				numero = LeeReal ();
			}
			while (numero < menor);
			
			return (numero);
		}

		/*********************************************************************/
	
	private:
		
		/*********************************************************************/
		// Devuelve una NUEVA cadena, resultante de eliminar los �ltimos
		// caracteres separadores de "cadena". Los caracteres separadores son
		// el espacio en blanco, el tabulador y el salto de l�nea.
		// Usaremos la funci�n isspace() para simplificar el c�lculo.
		//
		// Recibe: cadena, string sobre la que se va a trabajar.
		// Devuelve: el resultado de eliminar los �ltimos separadores de 
		// "cadena"
		/*********************************************************************/
		
		string EliminaUltimosSeparadores (string cadena)
		{
			while (cadena.length()>0 && isspace(cadena.back()))
				cadena.pop_back();
			
			return (cadena);
		}
		
		/*********************************************************************/
		// Devuelve una NUEVA cadena, resultante de eliminar los primeros
		// caracteres separadores de "cadena". Los caracteres separadores son
		// el espacio en blanco, el tabulador y el salto de l�nea.
		// Usaremos la funci�n isspace() para simplificar el c�lculo.
		//
		// Recibe: cadena, string sobre la que se va a trabajar.
		// Devuelve: el resultado de eliminar los �ltimos separadores de 
		// "cadena"
		/*********************************************************************/
		string EliminaPrimerosSeparadores (string cadena)
		{
			// Buscar el primer car�cter no espacio
			unsigned int pos = 0;
			while (pos < cadena.length() && isspace(cadena.at(pos))) pos++;
			
			string local;
			
			// Copiar todos los que quedan
			while (pos < cadena.length()) {
				local.push_back(cadena.at(pos));
				pos++;
			}
			
			return (local);
		}
		
		/*********************************************************************/
		// Devuelve una NUEVA cadena, resultante de eliminar los primeros 
		// �ltimos caracteres separadores de "cadena". Los caracteres 
		// separadores son el espacio en blanco, el tabulador y el salto de
		// l�nea
		//
		// Recibe: cadena, string sobre la que se va a trabajar.
		// Devuelve: el resultado de eliminar los primeros y los �ltimos
		//           separadores de "cadena".
		/*********************************************************************/
		
		string EliminaPrimerosYUltimosSeparadores (string cadena)
		{
			string cadena_podada = EliminaPrimerosSeparadores (cadena);
			cadena_podada = EliminaUltimosSeparadores (cadena_podada);
			
			return (cadena_podada);
		}
		
		/*********************************************************************/
		// Devuelve "true" si "cadena" es la representaci�n textual de un
		// entero
		//
		// Recibe: cadena, string sobre la que se va a trabajar.
		// Devuelve: "true" si "cadena" es la representaci�n textual de un int
		
		bool EsEntero (string cadena)
		{
			bool es_entero = true;
			
			cadena = EliminaPrimerosSeparadores (cadena);
			cadena = EliminaUltimosSeparadores (cadena);
			
			unsigned int long_cadena = cadena.length();
			
			if (long_cadena == 0) es_entero = false;
			else {
				
				// Si el primer car�cter es '+' � '-', perfecto. En ese caso
				// se pasa al siguiente car�cter (posici�n 19.
				
				unsigned int pos;
				if (cadena.at(0)=='-' || cadena.at(0) == '+') pos = 1;
				else pos = 0;
				
				while ((pos < long_cadena) && es_entero) {
					if(!isdigit(cadena.at(pos))) es_entero = false;
					else pos++;
				}
			}
			
			return (es_entero);
		}
		
		/*********************************************************************/

		bool EsReal (string cadena)
		{
			bool es_real = true;
			
			cadena = EliminaPrimerosSeparadores (cadena);
			cadena = EliminaUltimosSeparadores (cadena);
			
			unsigned int long_cadena = cadena.length();
			
			if (long_cadena == 0) es_real = false;
			else {
				
				// Si el primer car�cter es '+' � '-', perfecto. En ese caso
				// se pasa al siguiente car�cter (posici�n 19.
				
				unsigned int pos;
				if (cadena.at(0)=='-' || cadena.at(0) == '+') pos = 1;
				else pos = 0;
				
				// Bandera que se activa al encontrar un punto
				bool encontrado_un_punto = false;
				
				while ((pos < long_cadena) && es_real) {
					
					char c = cadena.at(pos);
					
					if (!isdigit(c)) {
						
						// Solo puede haber un punto.
						// Si se ha encontrado un punto y ya se hab�a
						// encontrado otro, error. Si no, activar la bandera
						// "encontrado_un_punto" (ya no puede haber m�s).
						
						if (c == '.') {
							if (encontrado_un_punto) es_real = false;
							else encontrado_un_punto = true;
						}
						
					    // Si no es un punto ni un d�gito --> error
						else es_real = false;
					}
					
					pos++;
					
				}  // while ((pos < long_cadena) && es_real)
				
			}  // else de if (long_cadena == 0)
			
			return (es_real);
		}
};

int main () // Programa principal
{
	// Declaraci�n de datos
	
	const int NUM_NOTAS = 4;
	
	string nombre, ap_1, ap_2;
	int dni;
	double nota; // Es un dato de entrada 
	double nota_media; // Es un dato de salida
	
	// Creamos un objeto de la clase lector que nos ayude a filtrar las 
	// notas que se introducen del alumno y su DNI
	
	Lector lector;
	
	// Entrada de datos
	
	cout << "Introduzca el nombre del alumno: ";
	getline(cin, nombre);
	
	cout << "Introduzca el primer apellido del alumno: ";
	getline(cin, ap_1);
	
	cout << "Introdyzca el segundo apellido del alumno: ";
	getline(cin, ap_2);
	
	lector.SetTitulo("Introduzca el DNI del alumno: ");
	dni = lector.LeeEnteroEnRango(00000001, 99999999);
	
	AlumnoFP alumno (nombre, ap_1, ap_2, dni);
	
	cout << endl;
	cout << "En lo que sigue se debe tener en cuenta esta identificaci�n: ";
	cout << endl;
	cout << "Examen 1: Examen de teor�a";
	cout << endl;
	cout << "Examen 2: Examen pr�ctico 1";
	cout << endl;
	cout << "Examen 3: Examen pr�ctico 2";
	cout << endl;
	cout << "Examen 4: Evaluaci�n continua";
	cout << endl << endl;
	
	lector.SetTitulo("Introduzca la nota pertinente: ");
	
	for (int i = 0; i < NUM_NOTAS; i++){
		
		cout << "Examen " << i + 1 << ": ";
		cout << endl;
		
		nota = lector.LeeRealEnRango(0, 10);
		alumno.AniadeNota(nota, i);
		
		cout << endl;
	}
	
	// Salida de datos
	
	nota_media = alumno.NotaMedia();
	cout << endl;
	
	cout << "La nota media del alumno " << alumno.GetNombreApellidos()
	<< " con DNI " << alumno.GetDNI() << " es " << nota_media;
	cout << endl << endl;
	cout << alumno.Suspensos();
	
	return 0;
}
