/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa consiste en la creaci�n de un m�todo que se a�ade a la clase
SecuenciaCaracteres proporcionada por el profesor. Dicho m�todo tiene como
objetivo principal eliminar del vector dato miembro de un objeto de dicha
clase un caracter indicado por el usuario.
*/
/*****************************************************************************/

#include <iostream>
#include <string>

using namespace std;

class SecuenciaCaracteres {

	private:

    	static const int TAMANIO = 50; // N�m.casillas disponibles
    	char vector_privado[TAMANIO];

    	// PRE: 0<=total_utilizados<=TAMANIO

    	int total_utilizados; // N�m.casillas ocupadas

	public:

    	/*********************************************************************/
    	// Constructor sin argumentos

    	SecuenciaCaracteres (void) : total_utilizados (0)
    	{}
    	
    	/*********************************************************************/
    	// Constructor con argumentos
    	
    	SecuenciaCaracteres (string cadena) : total_utilizados (0)
    	{
    		StringACaracteres (cadena);
    	}

    	/*********************************************************************/
    	// Devuelve el n�mero de casillas ocupadas

    	int TotalUtilizados (void)
    	{
        	return (total_utilizados);
    	}

    	/*********************************************************************/
    	// Devuelve el n�mero de casillas disponibles

    	int Capacidad (void)
    	{
        	return (TAMANIO);
    	}

    	/*********************************************************************/
    	// "Vac�a" completamente la secuencia

		void EliminaTodos()
		{
			total_utilizados = 0;
		}

    	/*********************************************************************/
    	// A�ade un elemento ("nuevo") al vector.
    	// PRE: total_utilizados < TAMANIO
    	// 		La adici�n se realiza si hay alguna casilla disponible.
    	// 		El nuevo elemento se coloca al final del vector.
    	// 		Si no hay espacio, no se hace nada.

    	void Aniade (char nuevo)
    	{
        	if (total_utilizados < TAMANIO){
            	vector_privado[total_utilizados] = nuevo;
            	total_utilizados++;
        	}
    	}

    	/*********************************************************************/	
    	// Devuelve el elemento de la casilla "indice"
    	// PRE: 0 <= indice < total_utilizados

    	char Elemento (int indice)
    	{
        	return (vector_privado[indice]);
    	}

    	/*********************************************************************/
    	// Cambia el contenido de la casilla "indice" por el valor "nuevo"
    	// PRE: 0 <= indice < total_utilizados

		void Modifica (int indice, char nuevo)
   		{
			if ((indice >= 0) && (indice < total_utilizados))
				vector_privado[indice] = nuevo;
   		}


    	/*********************************************************************/
    	// Eliminar el car�cter de la posici�n dada por "indice".
    	// Realiza un borrado f�sico (desplazamiento y sustituci�n).
    	// PRE: 0 <= indice < total_utilizados

    	void Elimina (int indice)
    	{
        	if ((indice >= 0) && (indice < total_utilizados)) {

            	int tope = total_utilizados-1; // posic. del �ltimo

            	for (int i = indice ; i < tope ; i++)
                	vector_privado[i] = vector_privado[i+1];

            	total_utilizados--;
        	}
    	}
 

    	/*********************************************************************/
    	// Inserta el car�cter "nuevo" en la posici�n dada por "indice".
    	// Desplaza todos los caracteres una posici�n a la derecha antes de 
		// copiar en "indice" en valor "nuevo".
		// PRE: 0 <= indice < total_utilizados
    	// PRE: total_utilizados < TAMANIO
    	// 		La inserci�n se realiza si hay alguna casilla disponible.
    	// 		Si no hay espacio, no se hace nada.
    
		void Inserta (int indice, char valor_nuevo)
		{
        	if ((indice >= 0) && (indice < total_utilizados) 
		    && (total_utilizados < TAMANIO)) {
		
				for (int i = total_utilizados ; i > indice ; i--)
					vector_privado[i] = vector_privado[i-1];
			
				vector_privado[indice] = valor_nuevo;
				total_utilizados++;		
			}
		}
   
    	/*********************************************************************/
    	// Compone un string con todos los caracteres que est�n
    	// almacenados en la secuencia y lo devuelve.

    	string ToString()
    	{
        	string cadena;

        	for (int i=0; i<total_utilizados; i++)
            	cadena = cadena + vector_privado[i];

        	return (cadena);
    	}

		/*********************************************************************/
	
		// M�todo que borra de la secuencia de caracteres un caracter dado por
		// el usuario. Se tienen dos apuntadores: uno de lectura y otro de 
		// escritura. Ambos empiezan en la posici�n 0. En caso de que el
		// caracter de la pos_lectura sea distinto del car�cter a borrar, 
		// dicho caracter se escribe en el caracter de la pos_escritura, la 
		// cual solo avanza cuando se encuentran caracteres distintos del que
		// se quiere borrar. As�, el total de casillas utilizadas del vector
		// del objeto secuencia pasar� a ser justo la posici�n de escritura,
		// pues es hasta ah� donde se han escrito todos los caracteres de
		// la secuencia inicial distintos del que se quer�a borrar
	
		void EliminaOcurrencias (char a_borrar)
		{
			int pos_lectura = 0;
			int pos_escritura = 0;
		
			while (pos_lectura < total_utilizados){
			
				if (vector_privado[pos_lectura] != a_borrar){
				
					vector_privado[pos_escritura] = vector_privado[pos_lectura];
					pos_escritura++;
				}
			
				pos_lectura++;
			}
		
			total_utilizados = pos_escritura;
		}
	
	private:
		
		// M�todo que rellena el vector privado del objeto a partir de un
		// dato string
		
		void StringACaracteres (string cadena)
		{
			for(int i = 0; i < cadena.length(); i++){
				
				Aniade(cadena.at(i));
			}
		}

};

/////////////////////////////////////////////////////////////////////////////

int main() // Programa principal
{
	// Declaraci�n de datos
	
	string cadena;
	char a_eliminar; // Es el dato que vamos a usar para ir inicializando las 
	                 // casillas del vector dato miembro del objeto secuencia
	
	// Entrada de datos
	
	cout << "Introduzca una secuencia de caracteres cualquiera: ";
	getline(cin, cadena);
	
	SecuenciaCaracteres secuencia(cadena);
	
	cout << "La secuencia introducida es: " << secuencia.ToString();
	cout << endl << endl;
	
	cout << "Introduzca la letra que desea eliminar: ";
	cin >> a_eliminar;
	
	// Operaciones
	
	secuencia.EliminaOcurrencias(a_eliminar);
	
	// Salida de datos
	
	cout << endl;
	cout << "La secuencia final es: " << secuencia.ToString();
	
	return 0;
}
