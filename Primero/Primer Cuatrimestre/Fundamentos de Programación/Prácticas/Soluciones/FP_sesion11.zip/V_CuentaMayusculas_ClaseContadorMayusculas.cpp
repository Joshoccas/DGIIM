/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa lee una secuencia de caracteres y determina el n�mero de 
apariciones de cada letra may�scula. Adem�s, se ha creado la clase
ContadorMayusculas que consta de un vector de datos de tipo entero como
dato miembro (en dicho vector tendr�amos 26 contadores, uno para cada
letra).

La lectura de la secuencia introducida concluye cuando se lee un '.' en
dicha secuencia, al cual hemos llamado TERMINADOR.
*/
/*****************************************************************************/

#include <iostream>
#include <string>

using namespace std;

class ContadorMayusculas
{
	private:
		
		static const int NUM_LETRAS = 26;
		int contador[NUM_LETRAS] = {0};
		
	public:
		
		void IncrementaCuenta (char letra)
		{
			if(EsMayuscula(letra))
				contador[letra - 'A']++;
		}
		
		//PRE: Se debe introducir una may�scula y ning�n otro tipo de caracter
		
		int CuantasHay (char letra)
		{
			int numero;
			
			numero = contador[letra - 'A'];
			
			return (numero);
		}
		
		// M�todo que muestra en pantalla las apariciones de cada may�scula
		
		string ToString (void)
		{
			string resultado = "Apariciones de cada may�scula: \n\n";
			
			for(int i = 0; i < NUM_LETRAS; i++){
				
				char letra = 'A' + i;
				resultado = resultado + "Letra " + letra + ": " +
				to_string(CuantasHay(letra)) + "\n";
			}
			
			return (resultado);
		}
		
	private:
		
		// M�todo que comprueba si un dato char introducido es una letra
		
		bool EsLetra (char letra)
		{
			bool es_letra = false;
			
			letra = toupper(letra);
			
			if('A' <= letra && letra <= 'Z')
				es_letra = true;
			
			return (es_letra);
		}
		
		// M�todo que comprueba si un dato char introducido es una may�scula
		
		bool EsMayuscula (char letra)
		{
			bool es_mayuscula = false;
			
			if(EsLetra (letra)){
				
				es_mayuscula = (letra == toupper(letra));
			}
			
			return (es_mayuscula);
		}
};

int main() // Programa principal
{
	// Declaraci�n de datos
	
	const char TERMINADOR = '.';
	char letra;
	ContadorMayusculas recuento;
	
	cout << "Introduzca una secuencia de caracteres para hallar las apariciones"
	<< " de cada may�scula. Si desea acabar, escriba " << TERMINADOR << ": ";
	cout << endl;
	
	letra = cin.get();
	
	while(letra != TERMINADOR){
		
		recuento.IncrementaCuenta(letra);
		
		// Preparamos la siguiente lectura
		
		letra = cin.get();
	}
	
	// Salida de datos
	
	cout << endl;
	cout << recuento.ToString() << endl << endl;
	
	return 0;
}
