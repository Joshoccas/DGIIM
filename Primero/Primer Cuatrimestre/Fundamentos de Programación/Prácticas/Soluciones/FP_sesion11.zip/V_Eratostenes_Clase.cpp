/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa calcula los primos menores que un natural dado (introducido por
el usuario) mediante la criba de Eratostenes, la cual consiste en escribir 
todos los naturales comprendidos entre 2 y n y eliminar aquellos que no son
primos de la siguiente manera:

    El primero (el 2) se declara primo y se tachan todos sus m�ltiplos;
	se busca el siguiente n�mero entero que no ha sido tachado, 
	se declara primo y se procede a tachar todos sus m�ltiplos, y as� 
	sucesivamente. El proceso termina cuando el cuadrado del n�mero entero es 
	mayor o igual que el valor de n.
	
Esta vez el vector en el que se almacenan los primos menores que n es un 
dato miembro de la clase Eratostenes, la cual hemos creado en este ejercicio.
*/
/*****************************************************************************/

#include <iostream>
#include <string>

using namespace std;

class Eratostenes 
{
	private:
		
		static const int TAMANIO = 500;
		int vector_privado[TAMANIO] = {0};
		
		//PRE: 0 <= total_utilizados <= TAMANIO
		int total_utilizados; // N�mero de casillas ocupadas
		
	public:
		
		Eratostenes (void): total_utilizados (0)
		{}
		
		// M�todo que calcula los primos menores que n para almacenarlos en el
		// vector dato miembro de la clase
		//PRE: 1 <= n <= TAMANIO
		
		void CalculaHasta (int n)
		{
			bool es_primo[TAMANIO+1];
			
			for (int i=0; i < n; i++) 
			es_primo[i] = true;

			// Criba 
	
			for (int num=2; num*num <= n; num++){ 
										        			
				if (es_primo[num]) {

					for (int k=2; k*num <= n; k++) {    
						es_primo[k*num] = false;		  
					}
				} 
			} 
		
			// Ya est�n "tachados" los n�meros no-primos en "es_primo".  
			// Ahora recorremos "es_primo" completamente y copiamos a 
			// "primos" �nicamente los que permacenen a "true". 
		
			for (int i = 1; i <= n; i++) { 
										
					if (es_primo[i]) {			 
						vector_privado[total_utilizados] = i;
						total_utilizados++;  		   		  
					}
			}
		}
		
		// Devuelve cu�ntos primos hay almacenados actualmente
		
		int TotalCalculados (void)
		{
			return (total_utilizados);
		}
		
		// Devuelve el k-�simo primo
		
		int Elemento (int k)
		{
			return (vector_privado[k]);
		}
		
		// Devuelve el primo de mayor valor almacenado tras la criba
		
		int GetMaximo ()
		{
			return (vector_privado[total_utilizados-1]);
		}
};

///////////////////////////////////////////////////////////////////////////////

class Lector
{
	private:
		
		string titulo;
	
	public:
		
		// Constructor sin argumentos
		
		Lector (void) : titulo ("")
		{ }
		
		// Constructor con argumentos
		
		Lector (string cad) : titulo (cad)
		{ }
		
		// M�todo Set para fijar el campo "titulo"
		
		void SetTitulo (string cad)
		{
			titulo = cad;
		}
		
		/*********************************************************************/
		// Lee un dato int.
		// La lectura est� etiquetada con "titulo"
		// La lectura se efect�a repetidamente hasta que se introduce un valor
		// int correcto.
		
		int LeeEntero (void)
		{
			string cadena;
			
			do{
				cout << titulo;
				getline(cin, cadena);
			}
			while (!EsEntero(cadena));
			
			return (stoi(cadena));
		}
		
		/*********************************************************************/
		// Lee un dato int.
		// La lectura est� etiquetada con "titulo"
		// PRE: menor <= mayor
		// POST: menor <= valor devuelto <= mayor
		
		int LeeEnteroEnRango (int menor, int mayor)
		{
			int numero;
			
			do{
				
				numero = LeeEntero ();
			}
			while ((numero<menor) || (numero>mayor));
			
			return (numero);
		}
		
		/*********************************************************************/
		// Lee un dato int que debe ser mayor o igual que "menor" y lo devuelve.
		// La lectura est� etiquetada con "titulo"
		
		int LeeEnteroMayorOIgual (int menor)
		{
			int numero;
			
			do{
				numero = LeeEntero ();
			}
			while (numero < menor);
			
			return (numero);
		}
	
	private:
		
		/*********************************************************************/
		// Devuelve una NUEVA cadena, resultante de eliminar los �ltimos
		// caracteres separadores de "cadena". Los caracteres separadores son
		// el espacio en blanco, el tabulador y el salto de l�nea.
		// Usaremos la funci�n isspace() para simplificar el c�lculo.
		//
		// Recibe: cadena, string sobre la que se va a trabajar.
		// Devuelve: el resultado de eliminar los �ltimos separadores de 
		// "cadena"
		/*********************************************************************/
		
		string EliminaUltimosSeparadores (string cadena)
		{
			while (cadena.length()>0 && isspace(cadena.back()))
				cadena.pop_back();
			
			return (cadena);
		}
		
		/*********************************************************************/
		// Devuelve una NUEVA cadena, resultante de eliminar los primeros
		// caracteres separadores de "cadena". Los caracteres separadores son
		// el espacio en blanco, el tabulador y el salto de l�nea.
		// Usaremos la funci�n isspace() para simplificar el c�lculo.
		//
		// Recibe: cadena, string sobre la que se va a trabajar.
		// Devuelve: el resultado de eliminar los �ltimos separadores de 
		// "cadena"
		/*********************************************************************/
		string EliminaPrimerosSeparadores (string cadena)
		{
			// Buscar el primer car�cter no espacio
			unsigned int pos = 0;
			while (pos < cadena.length() && isspace(cadena.at(pos))) pos++;
			
			string local;
			
			// Copiar todos los que quedan
			while (pos < cadena.length()) {
				local.push_back(cadena.at(pos));
				pos++;
			}
			
			return (local);
		}
		
		/*********************************************************************/
		// Devuelve una NUEVA cadena, resultante de eliminar los primeros 
		// �ltimos caracteres separadores de "cadena". Los caracteres 
		// separadores son el espacio en blanco, el tabulador y el salto de
		// l�nea
		//
		// Recibe: cadena, string sobre la que se va a trabajar.
		// Devuelve: el resultado de eliminar los primeros y los �ltimos
		//           separadores de "cadena".
		/*********************************************************************/
		
		string EliminaPrimerosYUltimosSeparadores (string cadena)
		{
			string cadena_podada = EliminaPrimerosSeparadores (cadena);
			cadena_podada = EliminaUltimosSeparadores (cadena_podada);
			
			return (cadena_podada);
		}
		
		/*********************************************************************/
		// Devuelve "true" si "cadena" es la representaci�n textual de un
		// entero
		//
		// Recibe: cadena, string sobre la que se va a trabajar.
		// Devuelve: "true" si "cadena" es la representaci�n textual de un int
		
		bool EsEntero (string cadena)
		{
			bool es_entero = true;
			
			cadena = EliminaPrimerosSeparadores (cadena);
			cadena = EliminaUltimosSeparadores (cadena);
			
			unsigned int long_cadena = cadena.length();
			
			if (long_cadena == 0) es_entero = false;
			else {
				
				// Si el primer car�cter es '+' � '-', perfecto. En ese caso
				// se pasa al siguiente car�cter (posici�n 19.
				
				unsigned int pos;
				if (cadena.at(0)=='-' || cadena.at(0) == '+') pos = 1;
				else pos = 0;
				
				while ((pos < long_cadena) && es_entero) {
					if(!isdigit(cadena.at(pos))) es_entero = false;
					else pos++;
				}
			}
			
			return (es_entero);
		}
};

///////////////////////////////////////////////////////////////////////////////

int main() // Programa principal
{
	// Declaraci�n de datos
	
	const int MAX_PRIMOS = 500;
	Lector lector;
	int numero;
	
	// Entrada de datos
	
	lector.SetTitulo("Introduzca un n�mero entero positivo: ");
	numero = lector.LeeEnteroEnRango(1, MAX_PRIMOS);
	
	// Creamos el objeto primos de la clase Eratostenes
	
	Eratostenes primos;
	
	// C�lculos
	
	primos.CalculaHasta(numero);
	int tope = primos.TotalCalculados();
	
	// Salida de datos
	
	cout << endl;
	cout << "Existen " << tope << " primos menores o iguales que " << numero;
	cout << endl;
	cout << "Dichos primos son: ";
	
	for(int i = 0; i < tope; i++)
		cout << primos.Elemento(i) << " ";
	
	cout << endl;
	cout << "El m�ximo de dichos primos es " << primos.GetMaximo();
	cout << endl;
	
	return 0;
}
