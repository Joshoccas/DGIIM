/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Programa que lee un string y elimina el exceso de caracteres en blanco, 
es decir, que sustituye todas las secuencias de espacios en blanco por un 
s�lo espacio. Por ejemplo:


         Introducimos: 'La   vida   es    compleja   '
         El programa nos devolver�: 'La vida es compleja'
         
He usado la clase SecuenciaCaracteres proporcionada por el profesor y en
ella he creado el m�todo EliminaExcesoBlancos, el cual est� explicado en
la propia clase.
*/
/*****************************************************************************/

#include <iostream>
#include <string>

using namespace std;

class SecuenciaCaracteres {

	private:

    	static const int TAMANIO = 50; // N�m.casillas disponibles
    	char vector_privado[TAMANIO];

    	// PRE: 0<=total_utilizados<=TAMANIO

    	int total_utilizados; // N�m.casillas ocupadas

	public:

    	/*********************************************************************/
    	// Constructor sin argumentos

    	SecuenciaCaracteres (void) : total_utilizados (0)
    	{}
    	
    	/*********************************************************************/
    	// Constructor con argumentos
    	
    	SecuenciaCaracteres (string cadena) : total_utilizados (0)
    	{
    		StringACaracteres (cadena);
    	}

    	/*********************************************************************/
    	// Devuelve el n�mero de casillas ocupadas

    	int TotalUtilizados (void)
    	{
        	return (total_utilizados);
    	}

    	/*********************************************************************/
    	// Devuelve el n�mero de casillas disponibles

    	int Capacidad (void)
    	{
        	return (TAMANIO);
    	}

    	/*********************************************************************/
    	// "Vac�a" completamente la secuencia

		void EliminaTodos()
		{
			total_utilizados = 0;
		}

    	/*********************************************************************/
    	// A�ade un elemento ("nuevo") al vector.
    	// PRE: total_utilizados < TAMANIO
    	// 		La adici�n se realiza si hay alguna casilla disponible.
    	// 		El nuevo elemento se coloca al final del vector.
    	// 		Si no hay espacio, no se hace nada.

    	void Aniade (char nuevo)
    	{
        	if (total_utilizados < TAMANIO){
            	vector_privado[total_utilizados] = nuevo;
            	total_utilizados++;
        	}
    	}

    	/*********************************************************************/	
    	// Devuelve el elemento de la casilla "indice"
    	// PRE: 0 <= indice < total_utilizados

    	char Elemento (int indice)
    	{
        	return (vector_privado[indice]);
    	}

    	/*********************************************************************/
    	// Cambia el contenido de la casilla "indice" por el valor "nuevo"
    	// PRE: 0 <= indice < total_utilizados

		void Modifica (int indice, char nuevo)
   		{
			if ((indice >= 0) && (indice < total_utilizados))
				vector_privado[indice] = nuevo;
   		}


    	/*********************************************************************/
    	// Eliminar el car�cter de la posici�n dada por "indice".
    	// Realiza un borrado f�sico (desplazamiento y sustituci�n).
    	// PRE: 0 <= indice < total_utilizados

    	void Elimina (int indice)
    	{
        	if ((indice >= 0) && (indice < total_utilizados)) {

            	int tope = total_utilizados-1; // posic. del �ltimo

            	for (int i = indice ; i < tope ; i++)
                	vector_privado[i] = vector_privado[i+1];

            	total_utilizados--;
        	}
    	}
 

    	/*********************************************************************/
    	// Inserta el car�cter "nuevo" en la posici�n dada por "indice".
    	// Desplaza todos los caracteres una posici�n a la derecha antes de 
		// copiar en "indice" en valor "nuevo".
		// PRE: 0 <= indice < total_utilizados
    	// PRE: total_utilizados < TAMANIO
    	// 		La inserci�n se realiza si hay alguna casilla disponible.
    	// 		Si no hay espacio, no se hace nada.
    
		void Inserta (int indice, char valor_nuevo)
		{
        	if ((indice >= 0) && (indice < total_utilizados) 
		    && (total_utilizados < TAMANIO)) {
		
				for (int i = total_utilizados ; i > indice ; i--)
					vector_privado[i] = vector_privado[i-1];
			
				vector_privado[indice] = valor_nuevo;
				total_utilizados++;		
			}
		}
   
    	/*********************************************************************/
    	// Compone un string con todos los caracteres que est�n
    	// almacenados en la secuencia y lo devuelve.

    	string ToString()
    	{
        	string cadena;

        	for (int i=0; i<total_utilizados; i++)
            	cadena = cadena + vector_privado[i];

        	return (cadena);
    	}
    	
    	/*********************************************************************/
    	// M�todo que elimina todos los espacios de una secuencia de espacios
    	// excepto uno (el primero en mi caso)
    	
    	void EliminaExcesoBlancos (void)
    	{
    		int pos_lect = 0;
    		int pos_escrit = 0;
    		int contador_espacios = 0;
    		
    		// Recorremos el vector desde el principio hasta su �ltima casilla
    		// ocupada
    		
    		while (pos_lect < total_utilizados){
    			
    			// Si el contenido de la casilla pos_lect no es un espacio,
    			// se copia en la casilla pos_escrit y se aumenta pos_escrit.
    			// Adem�s, se reinicia contador_espacios por haber encontrado
    			// un caracter distinto del espacio
    			
    			if(vector_privado[pos_lect] != ' '){
    				
    				vector_privado[pos_escrit] = vector_privado[pos_lect];
    				pos_escrit++;
    				contador_espacios = 0;
    			}
    			
    			else{
    				
    				// Si se lee un espacio y el contador est� a 0, copiamos
    				// dicho espacio en la pos_escrit y aumentamos pos_escrit
    				// y el contador en una unidad
    				
    				if (contador_espacios == 0){
    					
    					vector_privado[pos_escrit] = vector_privado[pos_lect];
    					pos_escrit++;
    					contador_espacios++;
    				}
    				
    				// Si se lee un espacio y no es el primero, solo aumentamos
    				// el contador ya que en la pos_escrit se debe escribir
    				// un caracter distinto de un espacio
    				
    				else{
    					
    					contador_espacios++;
    				}
    			}
    			
    			// Independientemente de lo ocurrido, pos_escrit aumenta a cada
    			// iteraci�n
    			
    			pos_lect++;
    		}
    		
    		// Finalmente, total_utilizados = pos_escrit ya que es hasta ah�
    		// hasta donde se ha copiado la secuencia inicial pero con los
    		// espacios en exceso eliminados
    		
    		total_utilizados = pos_escrit;
    	}
    	
    private:
    	
    	// M�todo que rellena el vector privado del objeto a partir de un
		// dato string
		
		void StringACaracteres (string cadena)
		{
			for(int i = 0; i < cadena.length(); i++){
				
				Aniade(cadena.at(i));
			}
		}
};

///////////////////////////////////////////////////////////////////////////////

int main() // Programa principal
{
	// Declaraci�n de datos
	
	string cadena;
	
	// Entrada de datos
	
	cout << "Introduzca una secuencia de caracteres cualquiera: ";
	getline(cin, cadena);
	
	SecuenciaCaracteres secuencia(cadena);
	
	cout << "La secuencia introducida es: " << secuencia.ToString();
	cout << endl << endl;
	
	// Operaciones
	
	secuencia.EliminaExcesoBlancos();
	
	// Salida de datos
	
	
	// Comentario: He a�adido en cout una coma inicial y una coma final para
	// que en caso de que se introduzca una cadena en blanco o muchos espacios
	// en blanco al final de la cadena, las comas muestren en el mensaje de
	// salida que realmente se han eliminado todos los espacios excepto uno
	
	
	cout << endl;
	cout << "La secuencia final es: '" << secuencia.ToString() << "'";
	
	return 0;
}
