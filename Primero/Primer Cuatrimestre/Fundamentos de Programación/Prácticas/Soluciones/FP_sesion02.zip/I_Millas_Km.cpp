/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa consiste en un conversor de millas a kil�metros, y de kil�metros 
a millas, de manera que al introducir un valor determinado de millas, el 
programa nos devolver� el valor de kil�metros que se corresponden con lo 
introducido y viceversa.

Entradas: n�mero de millas que queremos convertir (millas) y n�mero de km que
queremos convertir (kilometros_2)
Salidas: n�mero de kil�metros a los que equivalen esas millas (kil�metros) y
n�mero de millas a las que equivalen esos kil�metros (millas_2)

                  kilometros = milla_en_km*millas
                  millas_2 = km_en_millas*kilometros_2
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de recursos de E/S

using namespace std;

int main() // Programa principal
{
	// Declaraci�n de datos
	
	const double milla_en_km = 1.609;
	const double km_en_millas = 1/1.609; 
	double millas;
	double kilometros;
	double kilometros_2;
	double millas_2;
	
	// Entrada de datos (millas)
	
	cout << "Introduzca el n� de millas a convertir: ";
	cin >> millas;
	
	// C�lculos
	
	kilometros = milla_en_km*millas;
	
	// Salida de datos (kil�metros)
	
	cout << endl;
	cout << "Esas millas equivalen a: " << kilometros << " km " << endl;
	
	// Entrada de datos (kilometros_2)
	
	cout << endl;
	cout << "Introduzca el n� de kil�metros a convertir: ";
	cin >> kilometros_2;
	
	// C�lculos
	
	millas_2 = km_en_millas*kilometros_2;
	
	// Salida de datos (millas_2)
	
	cout << endl;
	cout << "Esos kil�metros equivalen a: " << millas_2 << " millas " << endl;
	
	return 0;
}
	

