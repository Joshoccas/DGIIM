/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/*
Este programa calcula el valor que toma la funci�n gaussiana en el valor de 
abscisa que el usuario indique. Del usuario se espera que introduzca los 
coeficientes desviaci�n t�pica, esperanza y el valor de abscisa para el que 
quiere calcular el valor que toma la funci�n gaussiana.

Entradas: (esperanza)(desviacion_tipica)(abscisa)
Salidas: (valor_gaussiana)
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recursos de E/S
#include <cmath> // Inclusi�n de los recursos matem�ticos

using namespace std;

int main() // Programa principal
{
	// Declaraci�n de datos
	
	double esperanza;
	double desviacion_tipica;
	double abscisa;
	const double PI = 3.14159;
	double exponente_de_e;
	double valor_gaussiana;
	
	// Entrada de datos
	
	cout << "Introduzca la esperanza: ";
	cin >> esperanza;
	cout << "Introduzca la desviaci�n t�pica: ";
	cin >> desviacion_tipica;
	cout << "Introduzca el valor de la abscisa: ";
	cin >> abscisa;
	
	// C�lculos
	
	exponente_de_e = -0.5*pow(((abscisa-esperanza)/desviacion_tipica),2);
	valor_gaussiana = 1/(desviacion_tipica*sqrt(2*PI))*exp(exponente_de_e);
	
	// Salida de datos
	
	cout << endl;
	cout << "El valor de la gaussiana para ese valor de abscisa es " 
	<< valor_gaussiana;
	
	return 0;
}
