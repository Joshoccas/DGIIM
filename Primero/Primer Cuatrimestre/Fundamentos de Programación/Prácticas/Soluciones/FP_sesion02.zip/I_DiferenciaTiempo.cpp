/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/*
Este programa calcula la diferencia de tiempo en segundos que hay entre dos 
instantes de tiempo expresados en horas, minutos y segundos, y que el usuario
debe introducir manualmente:

Entradas: horas, minutos y segundos del primer instante (segundos_1)(minutos_1)
(horas_1) y horas, minutos y segundos del segundo instante (segundos_2)
(minutos_2)(horas_2)
Salidas: diferencia en segundos entre los dos instantes dados 
(diferencia_en_segundos)
 
         segundos_totales_1 = (segundos_1+minutos_1*60+horas_1*3600)
         segundos_totales_2 = (segundos_2+minutos_2*60+horas_2*3600)
         diferencia_en_segundos = abs(segundos_totales_2-segundos_totales_1)
         
Al calcular la diferencia en segundos, he empleado el valor absoluto dado que
el usuario del programa podr�a introducir los dos instantes en cualquier orden,
y la diferencia de segundos podr�a salir negativa si el dato segundos_totales_2 
es menor que segundos_totales_1. Es por eso que he incluido los recursos
matem�ticos al principio
         
                

*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recursos de E/S
#include <cmath> // Inclusi�n de los recursos matem�ticos

using namespace std;

int main() // Programa principal
{
	// Declaraci�n de datos
	
	int segundos_1;
	int minutos_1;
	int horas_1;
	int segundos_2;
	int minutos_2;
	int horas_2;
	int segundos_totales_1;
	int segundos_totales_2;
	int diferencia_en_segundos;
	
	// Entrada de datos
	
	cout << "Introduzca los segundos del instante 1: ";
	cin >> segundos_1;
	cout << "Introduzca los minutos del instante 1: ";
	cin >> minutos_1;
	cout << "Introduzca las horas del instante 1: ";
	cin >> horas_1;
	cout << "Introduzca los segundos del instante 2: ";
	cin >> segundos_2;
	cout << "Introduzca los minutos del instante 2: ";
	cin >> minutos_2;
	cout << "Introduzca las horas del instante 2: ";
	cin >> horas_2;
	
	// C�lculos
	
	segundos_totales_1 = (segundos_1+minutos_1*60+horas_1*3600);
	segundos_totales_2 = (segundos_2+minutos_2*60+horas_2*3600);
	diferencia_en_segundos = abs(segundos_totales_2-segundos_totales_1);
	
	// Salida de datos
	
	cout << endl;
	cout << "La diferencia en segundos entre esos dos instantes es de " 
	<< diferencia_en_segundos << " segundos";
	
	return 0;
}
	
	
