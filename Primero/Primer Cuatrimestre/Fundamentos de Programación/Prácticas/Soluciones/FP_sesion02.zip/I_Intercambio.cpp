/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa intercambia la cantidad de dinero que hay en el interior de dos 
cajas, estando una situada a la izquierda y la otra a la derecha.

La soluci�n propuesta en el gui�n de pr�cticas no funciona ya que en la primera
l�nea, al decir que "caja_izda = caja_dcha", le estamos asignando el dinero de 
la caja derecha a la caja izquierda, por lo que tras dicha orden el dinero de
ambas cajas es el mismo. Por ello, no tiene mucho sentido escribir en la 
siguiente l�nea la asignaci�n "caja_dcha = caja_izda". Le estar�amos asignando 
a la caja derecha su propio valor, pues en la anterior l�nea hab�amos cambiado
el valor de la caja izquierda por el de la derecha. As�, con esa soluci�n, al 
final del programa ambas cajas tendr�an el mismo valor, concretamente el que se
introdujo en la caja derecha.

En mi caso, he decidido declarar dos nuevos datos, que son caja_dcha_1 y 
caja_izda_1, a los cuales les he asignado los valores de los datos caja_dcha y
caja_izda respectivamente. De esta forma, puedo asignarles a caja_dcha y a
caja_izda los valores de los datos caja_izda_1 y caja_dcha_1 respectivamente,
logrando que al final del programa la caja derecha contenga el dinero inicial 
de la caja de la izquierda y que la caja de la izquierda contenga el dinero
inicial de la caja de la derecha.

Entradas: valores iniciales de las cajas derecha e izquierda (caja_dcha)
(caja_izda)
Salidas: valores finales (intercambiados) de las cajas derecha e izquierda
(caja_dcha)(caja_izda)
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de recursos de E/S

using namespace std;

int main() // Programa principal
{
	// Declaraci�n de datos
	
	double caja_dcha;
	double caja_izda;
	double caja_dcha_1;
	double caja_izda_1;
	
	// Entrada de datos 
	
	cout << "Introduzca el dinero de la caja derecha: ";
	cin >> caja_dcha;
	cout << "Introduzca el dinero de la caja izquierda: ";
	cin >> caja_izda;
	
	// Intercambio de dinero
	
	caja_dcha_1 = caja_dcha;
	caja_izda_1 = caja_izda;
	caja_dcha = caja_izda_1;
	caja_izda = caja_dcha_1;
	
	// Salida de datos
	
	cout << endl;
	cout << "La caja derecha vale " << caja_dcha << endl;
	cout << "La caja izquierda vale " << caja_izda << endl;
	
	return 0;
}
	
