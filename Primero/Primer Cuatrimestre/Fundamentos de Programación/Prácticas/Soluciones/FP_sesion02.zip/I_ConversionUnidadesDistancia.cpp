/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa se trata de un conversor de medidas. En �l se introduce una 
medida cualquiera en metros y este nos devuelve su equivalencia en yardas,
pulgadas, pies y millas.

Entradas: distancia en metros (metros)
Salidas: distancia introducida en yardas, pulgadas, pies y millas (yardas, 
pulgadas, pies y millas)

                   yardas = metros/yarda_en_metros
                   pulgadas = metros/pulgada_en_metros
                   pies = metros/pie_en_metros
                   millas = metros/milla_en_m
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de recursos de E/S

using namespace std;

int main() // Programa principal
{
	// Declaraci�n de datos
	
	double metros;
	double yardas;
	double pulgadas;
	double pies;
	double millas;
	const double yarda_en_metros = 0.9144;
	const double pulgada_en_metros = 25.4/1000; // Conversi�n de mm a m
	const double pie_en_metros = 30.48/100; // Conversi�n de cm a m
	const double milla_en_metros = 1.609344*1000; // Conversi�n de km a m
	
	// Entrada de datos
	
	cout << "Introduzca la distancia en metros a convertir: ";
	cin >> metros;
	
	// C�lculos
	
	yardas = metros/yarda_en_metros;
	pulgadas = metros/pulgada_en_metros;
	pies = metros/pie_en_metros;
	millas = metros/milla_en_metros;
	
	// Salida de datos
	
	cout << endl;
	cout << "Esos metros equivalen a " << yardas << " yardas " << endl;
	cout << "Esos metros equivalen a " << pulgadas << " pulgadas " << endl;
	cout << "Esos metros equivalen a " << pies << " pies " << endl;
	cout << "Esos metros equivalen a " << millas << " millas " << endl;
	
	return 0;
}
