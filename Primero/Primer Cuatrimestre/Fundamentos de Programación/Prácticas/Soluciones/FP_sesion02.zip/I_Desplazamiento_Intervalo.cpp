/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa nos permite desplazar un n�mero de veces a la derecha un entero 
que pertenece a un intervalo dado por un m�nimo y un m�ximo, los cuales los
especifica el usuario. En caso de que al realizar el desplazamiento, este 
entero se salga del intervalo, se volver� a empezar a contar por el m�nimo del
intervalo (por ejemplo, si tenemos el entero 67 en el intervalo [35,70] y lo
desplazamos 5 posiciones a la derecha, el resultado ser�a 36).

Entradas: las cotas del intervalo, el n�mero a desplazar y el desplazamiento
(minimo)(maximo)(a_desplazar)(desplazamiento)
Salidas: el n�mero desplazado (desplazado)

Para resolver este problema, he declarado algunos datos que me servir�n de 
ayuda para lograr lo pedido. Uno de ellos es la amplitud del intervalo dado, que
se calcula como:
                   amplitud = maximo - (minimo-1)
                   
El otro dato auxiliar es el n�mero que resulta de sumarle al n�mero a desplazar
el desplazamiento, y a este dato lo llamar� "desplazado":

                   desplazado = a_desplazar + desplazamiento
                   
Tras sumarle al n�mero a desplazar el desplazamiento, podemos tener un n�mero
dentro del intervalo o un n�mero mayor que el maximo. En cualquiera de los 
casos, si tomamos dicho n�mero (desplazado), le restamos el m�nimo y calculamos
el resto de la divisi�n en la que el dividendo es "desplazado" menos el m�nimo y 
el divisor el dato "amplitud". Esa amplitud queda definida como la diferencia 
entre el m�ximo y el m�nimo menos la unidad. De esta manera, sabremos la 
posici�n que ocupa el n�mero desplazado final dentro del intervalo. Eso se 
realiza con "%". Cabe destacar que en la amplitud del intervalo le hemos restado
una unidad al m�nimo para que se tenga en cuenta el m�nimo del intervalo como 
una posici�n a contar.

Finalmente, una vez sepamos la posici�n de nuestro desplazado final, le 
sumaremos el m�nimo, obteniendo el n�mero desplazado final que quer�amos. As�,
nos queda la siguiente expresi�n:

            desplazado_final = minimo + ((desplazado - minimo)%amplitud) 
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recursos de E/S

using namespace std;

int main() // Programa principal
{
	// Declaraci�n de datos
	
	int minimo;
	int maximo;
	int a_desplazar;
	int desplazamiento;
	int desplazado;
	int amplitud;
	int desplazado_final;
	
	// Entrada de datos
	
	cout << "Introduzca el m�nimo de su intervalo: ";
	cin >> minimo;
	cout << "Introduzca el m�ximo de su intervalo: ";
	cin >> maximo;
	cout << "Introduzca el n�mero de su intervalo que desea desplazar: ";
	cin >> a_desplazar;
	cout << "Introduzca el n�de veces que desea desplazar ese n�mero: ";
	cin >> desplazamiento;
	
	// C�lculos
	
	desplazado = a_desplazar + desplazamiento;
	amplitud = maximo - (minimo - 1);
	desplazado_final = minimo + ((desplazado - minimo)%amplitud);
	
	// Salida de datos
	
	cout << endl;
	cout << "El n�mero desplazado dentro del intervalo es " << desplazado_final;
	
	return 0;
}
	
