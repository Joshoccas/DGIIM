/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
En esta parte del programa, se convierte una velocidad dada en km/h en 
ritmo, que son los minutos y segundos que se tarda en recorrer un kil�metro. 
En este caso se le pide al usuario introducir una velocidad. Para saber los
minutos que se emplean para recorrer un kil�metro, se deben dividir los 60 
minutos que hay en una hora por la velocidad introducida. Los minutos que se
obtienen de la divisi�n tienen parte decimal, la cual ser�a igual a los segundos
al multiplicarla por 60. Es por eso que para poder dar los minutos y segundos 
por separado, he tenido que declarar dichos datos como enteros para que la parte
decimal de las operaciones quede truncada.

Entradas: velocidad en km/h del atleta (velocidad)
Salidas: minutos y segundos por kil�metro (minutos)(segundos)
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recursos de E/S

using namespace std;

int main() // Programa principal
{
	// Declaraci�n de datos
	
	double velocidad;
	double minutos_con_decimales_por_km;
	int minutos; 
	int segundos;
	
	// Entrada de datos
	
	cout << "Introduzca la velocidad que desea convertir en ritmo: ";
	cin >> velocidad;
	
	// C�lculos
	
	minutos_con_decimales_por_km = 60/velocidad; // Obtenemos los min/km
	minutos = minutos_con_decimales_por_km; // Me quedo con la parte entera
	segundos = (minutos_con_decimales_por_km-minutos)*60;
	// En la �ltima operaci�n, me quedo la parte decimal y hago un factor de
	// conversi�n para obtener los segundos 
	
	// Salida de datos
	
	cout << endl;
	cout << "El ritmo del atleta es de " << minutos << " minuto(s) y " 
	<< segundos << " segundo(s) " << endl;
	
	return 0;
}
