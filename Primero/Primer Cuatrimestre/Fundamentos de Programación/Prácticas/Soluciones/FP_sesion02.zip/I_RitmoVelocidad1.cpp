/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa nos dice la velocidad en kil�metros por hora a la que va un 
atleta que tiene un ritmo de unos determinados minutos y segundos por kil�metro.

Entradas: El tiempo en minutos y segundos empleado para recorrer un kil�metro
(minutos)(segundos).
Salidas: La velocidad en kil�metros por hora del atleta (velocidad).
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recursos de E/S

using namespace std;

int main() // Programa principal
{
	// Declaraci�n de datos
	
	int minutos;
	int segundos;
	double velocidad;
	double minutos_en_hrs = 1.0/60; // 1/60 horas es 1 minuto
	double segundos_en_hrs = 1.0/3600; // 1/3600 horas es 1 segundo
	
	// Entrada de datos
	
	cout << "Introduzca los minutos transcurridos: ";
	cin >> minutos;
	cout << "Introduzca los segundos transcurridos: ";
	cin >> segundos;
	
	// C�lculos
	
	velocidad = 1/(minutos_en_hrs*minutos+segundos_en_hrs*segundos);
	
	// Salida de datos
	
	cout << endl;
	cout << "El atleta va a una velocidad de " << velocidad << "km/h";
	
	return 0;
}
	
