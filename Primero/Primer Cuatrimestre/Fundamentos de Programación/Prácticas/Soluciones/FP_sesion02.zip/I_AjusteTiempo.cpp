/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// JOS� ALBERTO HOCES CASTRO
//
/* 
Este programa transforma una cantidad de horas, minutos y segundos fuera de sus 
rangos (es decir, introduciendo 76 minutos y 65 segundos) en las horas, minutos
y segundos correspondientes dentro de sus rangos. Si se obtienen m�s de 24 
horas, el prorama tambi�n nos mostrar� los d�as.

Entradas: las horas, minutos y segundos desajustados (horas_entrada)
(min_entrada)(seg_entrada)
Salidas: los d�as, horas, minutos y segundos ajustados (dias_salida)
(horas_salida)(minutos_salida)(segundos_salida)

Para poder resolverlo he hecho uso de %, con el fin de quedarme con cada medida
de tiempo ajustada (al utilizar % nos quedamos con el resto que resulta de 
dividir el dividendo por el divisor, siendo el divisor el valor m�ximo que puede
tomar cada medida de tiempo. Si el dividendo es menor que el divisor, nos 
quedamos con el dividendo). Tambi�n he hecho uso de / para quedarme la parte 
entera que resulta al hacer las divisiones anteriores, y dicha parte entera se 
la he sumado a la medida de tiempo superior (por ejemplo, si tengo 67 segundos y
los divido por su m�ximo valor, 60, tengo 1.1167, por lo que la parte entera 1 
se sumar�a a los minutos como 1 minuto m�s). He repetido el proceso hasta llegar
a d�as.
*/
/*****************************************************************************/

#include <iostream> // Inclusi�n de los recursos de E/S

using namespace std;

int main() // Programa principal
{
	// Declaraci�n de datos
	
	int horas_entrada;
	int min_entrada;
	int seg_entrada;
	int dias_salida;
	int horas_salida;
	int minutos_salida;
	int segundos_salida;
	
	
	// Entrada de datos
	
	cout << "Introduzca las horas: ";
	cin >> horas_entrada;
	cout << "Introduzca los minutos: ";
	cin >> min_entrada;
	cout << "Introduca los segundos: ";
	cin >> seg_entrada;
	
	// C�lculos
	
	segundos_salida = seg_entrada%60;
	minutos_salida = (min_entrada+(seg_entrada/60))%60;
	horas_salida = (horas_entrada+(min_entrada+(seg_entrada/60))/60)%24;
	dias_salida = (horas_entrada+(min_entrada+(seg_entrada/60))/60)/24;
	
	// Salida de datos
	
	cout << endl;
	cout << "Los datos introducidos equivalen a " << dias_salida << " d�as, "
	<< horas_salida << " horas, " << minutos_salida << " minutos y " 
	<< segundos_salida << " segundos";
	
	return 0;
}
