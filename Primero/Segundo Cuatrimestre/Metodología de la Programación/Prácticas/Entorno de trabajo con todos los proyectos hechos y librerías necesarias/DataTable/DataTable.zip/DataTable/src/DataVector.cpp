/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include <iostream>
#include <cassert>
#include "DataVector.h"
using namespace std;

DataVector::DataVector() {
    clear();
}

DataVector::DataVector(int ndata) {
    clear();
    alloc(ndata);
}

DataVector & DataVector::clear() {
    _title = "";
    _nData = 0;
    for (int i = 0; i < MAX_WIDTH; i++) {
        setValue(i, 0);
        setLabel(i, "");
    }
    return *this;
}

DataVector DataVector::alloc(int n) {
    clear();
    _nData = n;
    return *this;
}

int DataVector::size() const {
    return _nData;
}

double DataVector::get(int pos) const {
    assert(0 <= pos && pos < size());
    return _data[pos];
}

DataVector &DataVector::setValue(int pos, double data) {
    assert(0 <= pos && pos < size());
    _data[pos] = data;
    return *this;
}

DataVector &DataVector::setLabel(int pos, const string & label) {
    assert(0 <= pos && pos < size());
    _labels[pos] = label;
    return *this;
}

DataVector & DataVector::setValues(const int values[], int nvalues) {
    clear();
    alloc(nvalues);
    assert(nvalues < MAX_WIDTH);
    for (int i = 0; i < nvalues; i++)
        setValue(i, values[i]);
    return *this;
}

DataVector & DataVector::setValues(const double values[], int nvalues) {
    clear();
    alloc(nvalues);
    assert(nvalues < MAX_WIDTH);
    for (int i = 0; i < nvalues; i++)
        setValue(i, values[i]);
    return *this;
}

DataVector & DataVector::addLabels(const std::string labels[]) {
    for (int i = 0; i < size(); i++)
        setLabel(i, labels[i]);
    return *this;
}

DataVector & DataVector::addLabels(const char* const labels[]) {
    for (int i = 0; i < size(); i++)
        setLabel(i, labels[i]);
    return *this;
}

DataVector & DataVector::add(double data) {
    assert(_nData < MAX_WIDTH);
    _labels[_nData] = "";
    _data[_nData++] = data;
    return *this;
}

DataVector & DataVector::add(const string &label, double data) {
    assert(_nData < MAX_WIDTH);
    _labels[_nData] = label;
    _data[_nData++] = data;
    return *this;
}

DataVector & DataVector::setTitle(const string &title) {
    _title = title;
    return *this;
}

string DataVector::showPlainReportH(int decpos) const {
    string res = _title + "\n",
            fdata = (string) "%" + std::to_string(FIELD_WIDTH) + "." + std::to_string(decpos) + "f",
            flabel = (string) "%" + std::to_string(FIELD_WIDTH) + "s";
    double byrow;
    char aux [MAX_WIDTH];
    byrow = 0;
    for (int i = 0; i < size(); i++) {
        sprintf(aux, fdata.c_str(), get(i));
        res = res + aux;
        byrow += get(i);
    }
    sprintf(aux, fdata.c_str(), byrow);
    res = res + aux + "\n";
    for (int i = 0; i < size(); i++) {
        sprintf(aux, flabel.c_str(), _labels[i].c_str());
        res = res + aux;
    }
    res += "\n";
    return res;
}

string DataVector::showPlainReportV(int decpos) const {
    string res = _title + "\n",
            fdata = (string) "%" + std::to_string(FIELD_WIDTH) + "." + std::to_string(decpos) + "f",
            flabel = (string) "%" + std::to_string(FIELD_WIDTH) + "s",
            axis("-", FIELD_WIDTH);
    double byrow;
    char aux [MAX_WIDTH];
    int i;

    byrow = 0;
    for (int i = 0; i < size(); i++) {
        sprintf(aux, flabel.c_str(), _labels[i].c_str());
        res = res + aux;
        sprintf(aux, fdata.c_str(), get(i));
        res += aux;
        byrow += get(i);
        res += "\n";
    }
    sprintf(aux, fdata.c_str(), byrow);
    res = res + aux + "\n";
    return res;
}

//string DataVector::showFancyReport(int decpos) const {
//    string res = _title + "\n",
//            fdata = (string) "%" + std::to_string(FIELD_WIDTH) + "." + std::to_string(decpos) + "f",
//            flabel = (string) "%" + std::to_string(FIELD_WIDTH) + "s",
//            axis(FIELD_WIDTH, '-');
//    double byrow;
//    char aux [MAX_WIDTH];
//    res += "┌";
//    for (int i = 0; i < getWidth(); i++) {
//        res = res + axis;
//        if (i < getWidth() - 1)
//            res += "┬";
//    }
//    res += "┐\n";
//
//    for (int j = getHeight() - 1; j >= 0; j--) {
//        res += "│";
//        byrow = 0;
//        for (int i = 0; i < getWidth(); i++) {
//            sprintf(aux, fdata.c_str(), get(j, i));
//            res = res + aux + "│";
//            byrow += get(j, i);
//        }
//        sprintf(aux, fdata.c_str(), byrow);
//        res = res + aux + "\n";
//    }
//    res += "├";
//    for (int i = 0; i < getWidth(); i++) {
//        res = res + axis;
//        if (i < getWidth() - 1)
//            res += "┼";
//    }
//    res += "┤\n│";
//    for (int i = 0; i < getWidth(); i++) {
//        sprintf(aux, flabel.c_str(), _xlabels[i].c_str());
//        res = res + aux + "│";
//    }
//    res += "\n└";
//    for (int i = 0; i < getWidth(); i++) {
//        res = res + axis + "┘";
//    }
//    res += "\n";
//    return res;
//}