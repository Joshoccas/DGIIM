/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include <string>

#ifndef DATAVECTOR
#define DATAVECTOR

#define MAX_WIDTH 100
#define FIELD_WIDTH 10
#define ITEMS_PER_ROW 15
const std::string SPECIAL_CHARS[] = {"┌┐└┘─│┬┴┼┤├▄", "++++-|", "▁▂▃▄▅▆▇█", "▏▎▍▌▋▊▉█"};

/*
 *  int n
 *  int value[]; o double value[];
 *  string label[];
 * 
 * value[0]     value[1] ...    value[n]
 * ----------------------------------------
 * label[0]     label[1] ...    label[n]
 * 
 * cout << myReport.setTitle("Title").defReport(n, labels, value).showReport() << endl;
 */

class DataVector {
private:
    std::string _title, _labels[MAX_WIDTH];
    double _data[MAX_WIDTH];
    int _nData;

public:

    DataVector();
    DataVector(int ndata);

    DataVector & clear();
    DataVector alloc(int n);
    int size() const;
    // Setters
    DataVector & setTitle(const std::string &title);
    DataVector &setValue(int pos, double value);
    DataVector &setLabel(int pos, const std::string & label);
    DataVector & setValues(const int values[], int nvalues);
    DataVector & setValues(const double values[], int nvalues);
    // adder
    DataVector & add(double data);
    DataVector & add(const std::string & label, double data);
    DataVector & addLabels(const std::string labels[]);
    DataVector & addLabels(const char* const labels[]);
    // Getters
    double get(int pos) const;

    // Reports
    std::string showPlainReportH(int decpos = 0) const;
    std::string showPlainReportV(int decpos = 0) const;
    std::string showFancyReport(int decpos = 0) const;

    /**
     * @bried It serializes the data into a plain string
     * @return The serializatiion of the data contained
     */
    std::string to_string() const {
        std::string res = std::to_string(size()) + " ";
        for (int i = 0; i < size(); i++)
            res = res+ std::to_string(_data[i]) + " ";
        return res;
    }

    /**
     * @brief Shows the number of events in the EventSet and a numeric 
     * value that encodes the whole set of events
     * @return A string made up of the size of the EventSet and the
     * numeric code of its content
     * @warning please do not modify its implementation
     */
    std::string reportData() const {
        std::string result = "";
        result = std::to_string(std::hash<std::string>{}
        (to_string()));
        result = std::to_string(size()) + " " + result;
        return result;
    }

};



#endif /* DATAVECTOR */

