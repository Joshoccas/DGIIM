var searchData=
[
  ['read',['read',['../classPoint2D.html#ac13d12003e2da9afee19a6a3f526c660',1,'Point2D::read()'],['../classRectangle.html#af6973ed3094f9dbabeadb071772fa76d',1,'Rectangle::read()']]],
  ['rectangle',['Rectangle',['../classRectangle.html#a8a933e0ebd9e80ce91e61ffe87fd577e',1,'Rectangle::Rectangle()'],['../classRectangle.html#a1546993e9fc10b8d128f4a85ed68c653',1,'Rectangle::Rectangle(int x, int y, int w, int h)']]]
];
