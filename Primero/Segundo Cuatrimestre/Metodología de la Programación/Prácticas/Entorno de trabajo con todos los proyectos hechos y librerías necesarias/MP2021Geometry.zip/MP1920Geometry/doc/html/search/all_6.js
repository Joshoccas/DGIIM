var searchData=
[
  ['setgeometry',['setGeometry',['../classRectangle.html#a31c4b9fc0d1ddf912f114da494e50205',1,'Rectangle::setGeometry(int x, int y, int w, int h)'],['../classRectangle.html#af8d143717fa47878690b12705a687b38',1,'Rectangle::setGeometry(const Point2D &amp;tl, const Point2D &amp;br)']]],
  ['setx',['setX',['../classPoint2D.html#af268842e8f2e6072ffe345dc2f322046',1,'Point2D']]],
  ['sety',['setY',['../classPoint2D.html#a0e08240b54e6eaae92c979082da1c91c',1,'Point2D']]]
];
