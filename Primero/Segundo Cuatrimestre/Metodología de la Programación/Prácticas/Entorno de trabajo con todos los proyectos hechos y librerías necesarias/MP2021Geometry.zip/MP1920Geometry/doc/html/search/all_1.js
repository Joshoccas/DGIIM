var searchData=
[
  ['getbottomright',['getBottomRight',['../classRectangle.html#a5f30a92f3fc197dda50d9e59995d3ac1',1,'Rectangle']]],
  ['gettopleft',['getTopLeft',['../classRectangle.html#a812afd6deed0cdec0b4ad7b2bd93871d',1,'Rectangle']]],
  ['getx',['getX',['../classPoint2D.html#a5cb1c2584e5b2bada0226a3e32aa2b1a',1,'Point2D']]],
  ['gety',['getY',['../classPoint2D.html#a53d10f2e460c47a493a3fbadfbafbb64',1,'Point2D']]]
];
