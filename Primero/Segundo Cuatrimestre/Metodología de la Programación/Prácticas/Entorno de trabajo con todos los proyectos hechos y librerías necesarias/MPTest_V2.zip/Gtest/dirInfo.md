Biblioteca que compila y enlaza googletest. Esta biblioteca se enlaza con los subproyectos de test de cada proyecto de NetBeans
