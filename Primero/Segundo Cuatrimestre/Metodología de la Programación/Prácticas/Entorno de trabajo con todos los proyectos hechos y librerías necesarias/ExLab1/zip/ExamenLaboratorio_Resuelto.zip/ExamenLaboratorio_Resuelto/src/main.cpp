/**
 * @file main.cpp
 * @brief Examen de laboratorio 
 * Universidad de Granada
 * Metodología de la Programación 
 * @nombre_del_alumno:  
 * 
 * @warning Por favor, rellene las funciones que se indican
 * @warning Es obligatorio el uso de estas funciones
 */
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

/**
@brief Imprime el contenido de un vector de string
@param v 	Vector de string
@param n	Número de elementos que contiene @a v
 */
void imprimirVector(const string *v, const int n) {
    if (v != nullptr && n >= 0) {
        cout << n << " elementos" << endl;
        for (int i = 0; i < n; i++)
            cout << "[" << i << "] = " << v[i] << endl;
    }
}


void liberarMemoria(string *&v) {
    if (v != nullptr) {
        delete[] v;
        v = nullptr;
    }

}

void asignarMemoria(string *&v, int n) {
    if (v != nullptr) {
        liberarMemoria(v);        
    }
    if (n>=0) {
        v = new string[n];
    }
}

/**
 * @brief Implementa la función del enunciado 
 * @param v1 Primer vector
 * @param nv1 Número de elementos de @a v1
 * @param v2 Segundo vector
 * @param nv2 Número de elementos de @a v2
 * @param v3 Vector resultado. Debe reservarse memoria dentro de la función
 * @param nv3 Número de elementos de @a v3
 */
void funcion(string const *v1, int nv1, string *v2, int nv2, string * &v3, int &nv3) {
    nv3 = nv1 + nv2;
    asignarMemoria(v3,nv3);
    for (int i = 0; i < nv3; i++)
        if (i < nv1)
            v3[i] = v1[i];
        else
            v3[i] = v2[i-nv1];
}

int main() {
    int nv1 = 0, nv2 = 0, nv3 = 0;
    string *v1 = nullptr, *v2 = nullptr, *v3 = nullptr;
    string namefi1, namefi2, namefo;
    ifstream fi1, fi2;
    ofstream fo;
    int i;
    // Examen: Leer vector v1
    cout << "Please type the name of the first file (folder ./data/): ";
    cin >> namefi1;
    fi1.open(namefi1);
    if (!fi1) {
        cout << "Error abriendo fichero " + namefi1 << endl;
        return 1;
    }
    fi1 >> nv1;
    cout << "Leyendo " << nv1 << " datos de " << namefi1 << endl;
    asignarMemoria(v1,nv1);
    for (i = 0; i < nv1 && fi1; i++)
        fi1 >> v1[i];
    if (i < nv1) {
        cout << "Error de datos en " << namefi1 << endl;
        liberarMemoria(v1);
        return 1;
    }
    fi1.close();
    imprimirVector(v1, nv1);

    // Examen: Leer vector B
    cout << "Please type the name of the second file (folder ./data/): ";
    cin >> namefi2;
    fi2.open(namefi2);
    if (!fi2) {
        cout << "Error abriendo fichero " + namefi2 << endl;
        liberarMemoria(v1);
        return 1;
    }
    fi2 >> nv2;
    cout << "Leyendo " << nv2 << " datos de " << namefi2 << endl;
    asignarMemoria(v2,nv2);
    for (i = 0; i < nv2 && fi2; i++)
        fi2 >> v2[i];
    if (i < nv2) {
        cout << "Error de datos en " << namefi1 << endl;
        liberarMemoria(v1);
        liberarMemoria(v2);
        return 1;
    }
    fi2.close();
    imprimirVector(v2, nv2);

    // Examen: Calcular resultado
    funcion(v1, nv1, v2, nv2, v3, nv3);

    // Examen: Mostrar resultado
    imprimirVector(v3, nv3);
    
    // Guardar resultado
    cout << "Please type the name of the output file (folder ./data/): ";
    cin >> namefo;
    fo.open(namefo);
    if (!fo) {
        cout << "Error abriendo fichero " + namefo << endl;
        liberarMemoria(v1);
        liberarMemoria(v2);
        return 1;
    }
    fo << nv3<<endl;;
    cout << "escribiendo " << nv3 << " datos en " << namefo << endl;
    for (i = 0; i < nv3 && fo; i++)
        fo << v3[i]<< endl;
    if (!fo) {
        cout << "Error escribiendo datos en "<<namefo<<endl;
    }
    fo.close();
    // Examen: Terminación del programa
    liberarMemoria(v1);
    liberarMemoria(v2);
    liberarMemoria(v3);
    return 0;
}
